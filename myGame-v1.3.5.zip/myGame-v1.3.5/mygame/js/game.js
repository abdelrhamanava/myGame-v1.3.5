var id, player_id, data, amount, filesize_log = 0, count_start = 0, extra, special, stopper = 0, count_id, current_count = countdown-time_passed, file_game = 0, data_log, data_game, data_player;

/* Players */
var Player = 
{		
	'refresh': function(player_id)
	{
		$.get(WEB+'ajax/game/refresh_player.php?id='+player_id, function(data_player)
		{
			data_player = data_player.split('|N|');
			
			stamina = data_player[0].split('-');
			health = data_player[1].split('-');
						
			if(data_player[2])
			{
				items = data_player[2].split('-');	
				
				if(items[0])
				{
					$('#'+player_id+' #extra .item_wrap').addClass('highlight');
				}
				
				if(items[1])
				{
					$('#'+player_id+' #special .item_wrap').addClass('highlight');	
				}				
			}
		
			$('#'+player_id+' .stamina .right').html(stamina[0]);
			$('#'+player_id+' .stamina .fill').css('width', stamina[1]+'%');
			
			$('#'+player_id+' .health .right').html(health[0]);
			$('#'+player_id+' .health .fill').css('width', health[1]+'%');		
		});	
	},
	
	'load': function(seat_id)
	{
		$.get(WEB+'ajax/game/load_players.php?id='+id+'&seat='+seat_id, function(data_player)
		{
			$seat = $('#seat_'+seat_id);
			$seat.html(data_player);
		});			
	}
	
};

/* Clock */
var Countdown =
{
	'count': function()
	{		
		if(current_count > 0)
		{
			current_count = current_count - 1;
		
			$('#'+turn+' .time .right').html(current_count);	
		
			setTimeout(function(){ Countdown.count(); }, 1000);
		} else
		{
			Update.activity(turn);
		}
	},
	
	'change': function()
	{				
		current_count = countdown;

		$('.time .fill').css('width', '0');	
		$('.time .right').html('');
		
		$('#'+turn+' .time .fill').css('width', '100%');	
		$('#'+turn+' .time .fill').animate({"width": "-=100%"}, (countdown)*1000);
	},
	
	'stop': function(count_id)
	{
		$('#'+count_id+' .time .fill').clearQueue().stop();
	},
	
	'start': function()
	{
		$('.time .fill').css('width', '0');	
		$('.time .right').html('');
		
		$('#'+turn+' .time .fill').css('width', width_percent+'%');	
		$('#'+turn+' .time .fill').animate({"width": "-="+width_percent+"%"}, (countdown-time_passed)*1000);		
		
		Countdown.count();
		
		count_start = 1;
	}
};

/* Actions */
var Action =
{
	'ready': function()
	{
		$.get(WEB+'ajax/game/ready.php', function(data_action)
		{			
			//$("#inactive").hide();
			//$("#active").show();
		});	
	}, 
	
	'pass': function()
	{
		$.get(WEB+'ajax/game/pass.php', function(data_action)
		{
			if(data_action)
			{
				$('#'+player+' .errors').show();
				$('#'+player+' .errors').html(data_action).delay(5000).fadeOut(500);
			}
		});	
	},
	
	'surrender': function()
	{
		$.get(WEB+'ajax/game/surrender.php', function(data_action)
		{
			if(data_action)
			{
				$('#'+player+' .errors').show();
				$('#'+player+' .errors').html(data_action).delay(5000).fadeOut(500);
			}
		});	
	},
	
	'attack': function(id)
	{
		$.get(WEB+'ajax/game/attack.php?id='+id, function(data_action)
		{
			if(data_action)
			{
				$('#'+player+' .errors').show();
				$('#'+player+' .errors').html(data_action).delay(5000).fadeOut(500);
			}
			
			if(!data_action)
			{
				$("#"+id+" .player").effect("shake", { direction:'up', distance:10 });
				
				Player.refresh(id);				
			}
		});	
	},

	'special_attack': function(id)
	{
		$.get(WEB+'ajax/game/special_attack.php?id='+id, function(data_action)
		{
			if(data_action)
			{
				$('#'+player+' .errors').show();
				$('#'+player+' .errors').html(data_action).delay(5000).fadeOut(500);
			}
			
			if(!data_action)
			{
				$("#"+id+" .player").effect("shake", { direction:'up', distance:10 });
				Player.refresh(id);	
			}
		});	
	},	

	'extra': function(id)
	{
		$.get(WEB+'ajax/game/extra.php?id='+id, function(data_action)
		{
			if(data_action)
			{
				$('#'+player+' .errors').show();
				$('#'+player+' .errors').html(data_action).delay(5000).fadeOut(500);
			}
			
			if(!data_action)
			{
				$("#"+id+" .player").effect("shake", { direction:'up', distance:10 });
				Player.refresh(id);	
			}
		});	
	}				
};
	
/* Read logs */
var Log = 
{		
	'read': function(id)
	{
		$.get(WEB+'ajax/logs/read.php?id='+id, function(data_log)
		{
			$('#log').html(data_log);
		});	
	},
		
	'cache': function(id)
	{
		$.get(WEB+'ajax/logs/filesize.php?id='+id+'&='+$.now(), function(data_log)
		{
			if(data_log != filesize_log)
			{
				Log.read(id);
			}
			
			filesize_log = data_log;	
		}); 
	}
};	

/* Update game field */
var Update = 
{		
	'read': function(id)
	{
		$.get(WEB+'ajax/game/read.php?id='+id+'&turn='+turn+'&current_players='+current_players, function(data_game)
		{
			if(isNaN(data_game))
			{			
				message = data_game.split('-');
				
				if(message[0] == 'start' && !active)
				{
					$("#active").show();	
					$(".badges").hide();	
					$("#"+player+" .items").show();
					$(".gamestats").show();		
					$(".prestats").hide();
					$("#inactive").hide();
					$('.actions_opponent').show();

					active = 1;
					
					turn = message[1];
					Countdown.start(turn);
				}
								
				if(message[0] == 'load_players' && !active)
				{
					current_players = message[1];
										
					for(var seat = 1; seat <= seats; seat++)
					{						
						if(player_seat != seat)
						{
							Player.load(seat);
						}
					}
				}	

				if(message[0] == 'finish' && active)
				{		
					finished = 1;
					
					finish();
								
					$('.actions').addClass('disabled');
					$('.actions .a_button').attr('onclick', '#');

					$('.actions_opponent').addClass('disabled');
					$('.actions_opponent .a_button').attr('onclick', '#');
					
					Countdown.stop(turn);
				}								
			}

			if(!isNaN(data_game) && active)
			{
				if(current_players <= 2)
				{
					Player.refresh(data_game);
					Player.refresh(player);
				} else
				{
					for(var i = 1; i <= 4; i++)
					{
						Player.refresh(i);
					}
				}
				
				if(data_game != player)
				{
					$('.actions_opponent .a_button').addClass('disabled');
					$('.actions .a_button').addClass('disabled');					
				}
				
				Countdown.stop(turn);
				turn = data_game;
				
				$(".player").removeClass('highlight');
				$("#"+turn+" .player").addClass('highlight');
				
				if(turn == player)
				{
					$('.actions .a_button').removeClass('disabled');
					$('.actions_opponent .a_button').removeClass('disabled');
				}				
				
				if(!count_start)
				{
					Countdown.start();	
				} else 
				{
					Countdown.change();
				}
			}

		});	
	},

	'activity': function(id)
	{
		$.get(WEB+'ajax/game/activity.php?id='+id, function(data_game)
		{
			if(data_game == 1 && active)
			{
				finished = 1;
				
				Popup.open('finish');				
				
				$('.actions_opponent').addClass('disabled');
				$('.actions_opponent .a_button').attr('onclick', '#');
				
				$('.actions').addClass('disabled');
				$('.actions .a_button').attr('onclick', '#');	

				Countdown.stop(id);				
			}
		}); 
	},
	
	'cache': function(id)
	{
		$.get(WEB+'ajax/game/filesize.php?id='+id+'&='+$.now(), function(data_game)
		{
			if(data_game != file_game)
			{
				Update.read(id);
			}
			
			file_game = data_game;	
		}); 
	}
};	

function finish()
{
	$.get(WEB+'ajax/game/finish_popup.php', function(finish_data)
	{
		$("#finish_popup #data").html(finish_data);
		Popup.open('finish');				
	});
}	