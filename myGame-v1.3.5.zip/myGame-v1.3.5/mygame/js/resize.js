$(function()
{
	var $window = $(window);
	
	$window.resize(function()
	{
		var current = $window.width() - 60;
		var max = Math.floor((current+30)/330);

		$('#page').css('width', max*330-30);
		
		$('#content div.review').removeClass('right');
		$('div.review:nth-child('+max+'n)', $('#content')).addClass('right');
		
		var width = max*330-30-330;
		
		$('#featured .image').css('width', 330);
		$('#featured .intro').css('width', width);
		
		
		var width_review = max*330-30-560;
		
		$('.sidebar-left').css('width', 300);
		$('.sidebar-left').css('padding-right', 30);
		$('.sidebar-right').css('width', 200);
		$('.sidebar-right').css('padding-left', 30);
		$('.content').css('width', width_review);
		$('.content img').css('max-width', width_review);
		$('.content iframe').css('width', width_review);
		
		var search = max*330-30-62;
		
		$('#search input').css('width', search);
		$('#search .button').css('width', 40);	

		$('.comments .entry').css('width', width_review-50);
	}).resize();
});
