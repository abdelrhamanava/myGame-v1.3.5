var Popup =
{
	'is_open': false,
	
	'resize': function()
	{
		var $window = $(window);
		
		var top = ($window.height() - this.$div.outerHeight())/2;
		
		if(top < 0 && this.absolute !== true) top = -$window.scrollTop();
		
		if(this.absolute === true)
		{
			top += $window.scrollTop();
		}
		
		this.$div.css(
		{
			'top': top,
			'left': ($window.width() - this.$div.outerWidth())/2
		});
	},
	
	'open': function(div, is_link, on_close, absolute)
	{
		if(this.is_open)
		{
			this.close();
		}
		
		this.is_open = true;
		this.is_link = is_link;
		this.on_close = on_close;
		this.absolute = absolute;
		
		this.$div = $('#'+div+'_popup').show();
		this.$block = $('#block').show();
		
		if(is_link !== false)
		{
			this.$current = $('#navigation a.current').removeClass('current');
			this.$button = $('#'+div+'_button').addClass('current');
		}
		
		$(window).unbind('resize').resize(function()
		{
			Popup.resize();
		}).unbind('scroll').scroll(function()
		{
			Popup.resize();
		}).keyup(function(e)
		{
			if(e.keyCode === 27)
			{
				Popup.close();
			}
		});
		
		this.resize();
		
		$('.close', this.$div).unbind('click').click(function()
		{
			Popup.close();
		});
	},
	
	'close': function()
	{
		this.$div.hide();
		this.$block.hide();
		
		if(this.is_link !== false)
		{
			this.$button.removeClass('current');
			this.$current.addClass('current');
		}
		
		if(typeof(this.on_close) === 'function')
		{
			this.on_close();
		}
		
		this.is_open = false;
	}
};