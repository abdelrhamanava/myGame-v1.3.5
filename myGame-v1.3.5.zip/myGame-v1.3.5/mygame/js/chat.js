var filesize = 0, message, id, data;

/* Chat */
var Chat = 
{		
	'read': function(id)
	{
		$.get(WEB+'ajax/chat/read.php?id='+id+'', function(data)
		{
			$('#chat').html(data);
		});	
	},
	
	'post': function(message)
	{
		if(message)
		{
			$.get(WEB+'ajax/chat/post.php?message='+message+'', function(data)
			{
				$('input[name="content"]').attr('value', '');
				$('#notice').html(data);
			});	
		}
	},
	
	'cache': function(id)
	{
		$.get(WEB+'ajax/chat/filesize.php?id='+id+'&='+$.now(), function(data)
		{
			if(data != filesize)
			{
				Chat.read(id);
			}
			
			filesize = data;	
		}); 
	}
}