var username, password, response;

function login()
{	
	username = encodeURIComponent($('input[name="username"]').val());
	password = encodeURIComponent($('input[name="password"]').val());
	
	$.get(CONST_WEB+'ajax/login.php?username='+username+'&password='+password, function(response)
	{
		if(response == '1')
		{
			$("#admin_popup #notice").html(LANG_LOGIN_ERROR);		
			$("#admin_popup #notice").show();
		}
		
		else if(response == '2')
		{
			$("#admin_popup #notice").html('<a href="'+CONST_WEB+'a_view_reviews">'+LANG_GO_ADMIN+'</a>');
			$("#admin_popup #notice").show();
		}
	});
}
