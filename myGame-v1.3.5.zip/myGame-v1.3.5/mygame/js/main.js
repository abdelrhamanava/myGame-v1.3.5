var id, code, location, reply, type, category, notice;

/* Insert BB code */
function insert(code, location)
{
	$('textarea[name="'+location+'"]').val($('textarea[name="'+location+'"]').val()+code);
	$('textarea[name="'+location+'"]').focus();
};

/* View images popup */
function view(location)
{		
	
		var $img = $('<img alt="image" class="close" src="'+location+'" style="display: block; margin: auto;"/>');
		var $body = $('body');
		var $popup = $('<div id="image_popup" class="popup no-border"/>').html($img);
		
		$img.load(function()
		{
			$body.addClass('zoom-out').unbind('click').click(function()
			{
				Popup.close();
			});
			
			Popup.open('image', false, function()
			{				
				$body.unbind('click').removeClass('zoom-out');
			});
		});
		
		$body.prepend($popup);	
};

/* Register contract viewing check */
var Contract = 
{		
	'open': function()
	{
		Popup.open('contract');
	},
	
	'agree': function(form)
	{
		Popup.close('contract');
		$("input[name='"+form+"']").parent('form').attr('action', '');
	}
};

/* Buy items from store */
function store_buy(id, category)
{		
	$response = $("#response");
	$money = $("#sidebar #money");
	
	$.get(CONST_WEB+'ajax/store.php?id='+id+'&category='+category, function(response)
	{
		notice = response.split('|N|');   
			
		$response.html(notice[0]);
		
		if(notice[1])
		{
			$money.html(notice[1]);
		}
	});
};

/* Inventory actions */
var Inventory =
{
	'equip': function(id)
	{
		$.get(CONST_WEB+'ajax/equip.php?id='+id, function(response)
		{	
			if(!isNaN(response))
			{
				$element = $("#"+id);
				$("#equipped").prepend( $element );
				
				$("#"+id+" .equip").hide();
				$("#"+id+" .unequip").show();			
			
				$element = $("#"+response);
				
				$("#"+response+" .equip").show();
				$("#"+response+" .unequip").hide();
				
				$("#unequipped").prepend( $element );
			} else
			{
				$("#response").html('<div class="errors">'+LANG_LEVEL+'</div>').delay(10000).hide(500);
			}
		});
	},
	
	'unequip': function(id)
	{
		$.get(CONST_WEB+'ajax/unequip.php?id='+id, function(response)
		{	
			$element = $("#"+id);
			$("#unequipped").prepend( $element );
			
			$("#"+id+" .equip").show();
			$("#"+id+" .unequip").hide();			
		});
	}	
};

/* Work */
var Work =
{
	'calculate': function(answer)
	{
		if(answer)
		{
			$.get(CONST_WEB+'ajax/work.php?answer='+answer, function(response)
			{
				if(response != '1')
				{
					$("#calculation").html(response);
				} else if(response == '1')
				{
					var current_stamina = parseInt($("#current_stamina").html());
					var max_stamina = parseInt($("#max_stamina").html());
					var new_stamina = current_stamina-1;
															
					var stamina_width = Math.round(new_stamina/max_stamina*100, 2);

					$("#current_stamina").html(new_stamina);					
					$("#stamina .fill").css("width", stamina_width+"%");
					
					Work.start();
				}
			});
		}
	},
		
	'count': function()
	{
		var seconds = $("#working .seconds").html();
		var minutes = $("#working .minutes").html();
		
		var time = minutes*60+seconds;
		
		if(time > 0)
		{
			seconds--;
			time--;
			
			if(seconds <= 0 && minutes > 0)
			{
				minutes--;
				seconds = 59;
			}
			
			$("#working .seconds").html(seconds);
			$("#working .minutes").html(minutes);
		
			setTimeout(function(){ Work.count(); }, 1000);
		} else
		{
			$("#working #time").hide();
			$("#working #done").show();
		}
	},
	
	'start': function()
	{
		$("#calculation").html(LANG_WORK_STARTED);
		
		$.get(CONST_WEB+'ajax/working.php', function(response)
		{
			if(response)
			{
				$("#header #working").html(response);
				Work.count();
			}
		});	
	}	
};

/* Quests */
var Quest =
{		
	'count': function()
	{
		var seconds = $("#quest .seconds").html();
		var minutes = $("#quest .minutes").html();
		
		var time = minutes*60+seconds;
				
		if(time > 0)
		{
			seconds--;
			time--;
			
			if(seconds <= 0 && minutes > 0)
			{
				minutes--;
				seconds = 59;
			}
			
			$("#quest .seconds").html(seconds);
			$("#quest .minutes").html(minutes);
		
			setTimeout(function(){ Quest.count(); }, 1000);
		} else
		{
			$("#quest #quest_time").hide();
			$("#quest #quest_done").show();
		}
	},
};

/* Add points */
var Points =
{
	'add': function(type)
	{
		var points = $("#"+type).html();
		points++;
		
		var free_points = $("#free_points").html();
		free_points--;
		
		if(free_points <= 0)
		{
			$(".attribute a").hide();
		}
		
		var total_points = $("#total_points").html();
		total_points++;
		
		$points_wrapper = $("#"+type);
		$free_points_wrapper = $("#free_points");
		$total_points_wrapper = $("#total_points");
		
		$attack_bar = $("#attack_bar");
		$defense_bar = $("#defense_bar");
		$endurance_bar = $("#endurance_bar");
		
		var attack = $("#attack").html();
		if(type == 'attack') attack++;
		
		var defense = $("#defense").html();
		if(type == 'defense') defense++;
		
		var endurance = $("#endurance").html();
		if(type == 'endurance')
		{
			endurance++;
		}
		
		var attack_width = Math.round(attack/total_points*100, 2);
		var defense_width = Math.round(defense/total_points*100, 2);
		var endurance_width = Math.round(endurance/total_points*100, 2);
	
		$.get(CONST_WEB+'ajax/points.php?add='+type, function(response)
		{	
			$points_wrapper.html(points);
			$free_points_wrapper.html(free_points);
			$total_points_wrapper.html(total_points);
			
			$attack_bar.css('width', attack_width+'%');
			$defense_bar.css('width', defense_width+'%');
			$endurance_bar.css('width', endurance_width+'%');
			
			if(type == 'endurance' && !isNaN(response))
			{
				var boost = parseInt(response);
				var current_health = parseInt($("#current_health").html());
				var max_health = parseInt($("#max_health").html());
						
				max_health = max_health+boost;
								
				var health_width = Math.round(current_health/max_health*100, 2);
			
				$("#health .fill").css("width", health_width+"%");
				$("#max_health").html(max_health);
			}
		});
	}
};

/* Sell items */
var Item =
{
	'sell_box': function(id, price, name)
	{
		$("#sell_box input[name='item']").attr('value', id);
		$("#sell_box input[name='price']").attr('value', price);
		$("#sell_box .name").html(name);

		$("#sell_box").show();
	},

	'sell': function(id, price)
	{
		$response = $("#response");
		
		$.get(CONST_WEB+'ajax/sell.php?id='+id+'&price='+price, function(response)
		{	
			$element = $("#"+id);

			if(response)
			{				
				$response.html(response).delay(10000).hide(500);
			
				if(!$response.children('.errors').html())
				{
					$element.hide();
				}
			}
		});
	},
	
	'buy': function(id)
	{
		$response = $("#response");
		$money = $("#sidebar #money");
		
		$.get(CONST_WEB+'ajax/buy.php?id='+id, function(response)
		{	
			
			$element = $("#"+id);

			if(response)
			{	
				notice = response.split('|N|');   
					
				$response.html(notice[0]).delay(10000).hide(500);
				
				if(notice[1])
				{
					$money.html(notice[1]);
				}
						
				if(!$response.children('.errors').html())
				{
					$element.hide();
				}
			}
		});	
	},
	
	'remove': function(id)
	{
		$response = $("#response");
		
		$.get(CONST_WEB+'ajax/remove.php?id='+id, function(response)
		{	
			$element = $("#"+id);

			if(response)
			{				
				$response.html(response).delay(10000).hide(500);
			
				if(!$response.children('.errors').html())
				{
					$element.hide();
				}
			}
		});
	}	
};

var User =
{
	'ban': function()
	{
		$("#ban").show();
		$("#mute").hide();
	},
	
	'mute': function()
	{
		$("#mute").show();
		$("#ban").hide();
	},
};
