<?php 
$_GET['request'] = '';

require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'/fw/user.php';

fw::lang(array('main'));

$errors = array();

if(is_numeric($_GET['id']) && $_GET['category'])
{
	switch($_GET['category'])
	{
		case 'weapons':
			$category = 'weapons';
		break;
		
		case 'special':
			$category = 'special';
		break;
		
		case 'extra':
			$category = 'extra';
		break;
		
		case 'defense':
			$category = 'defense';
		break;
	}
	
	$item = db::query("SELECT * FROM items_".$category." WHERE id = ? AND special = 0", array($_GET['id']))->fetch();
	
	if(user::data('money') < $item['price']) $errors[] = 'e_price';
	if(user::data('level') < $item['level']) $errors[] = 'e_level';
	
	if(empty($errors) && $item['id'])
	{
		$equip = 0;
		
		if(!db::count("items WHERE user = ? AND category = ? AND equip = 1", array(user::data('id'), $category)))
		{
			$equip = 1;
		}
	
		db::insert('items', array('user' => user::data('id'), 'item' => $item['id'], 'category' => $category, 'equip' => $equip));
		
		user::badge('items', 1);
		
		user::money(-$item['price']);
		
		$echo = lang('item_bought', array('item' => $item['name'], 'price' => $item['price']));
	}
}

if(!empty($errors))
{
	echo '<div class="errors">';
	
	foreach($errors as $error)
	{
		echo '<span>'.lang($error).'</span>';
	}
	
	echo '</div>|N|';
} else
{
	echo '<div class="success">'.$echo.'</div>|N|';
	echo format_numbers(user::data('money'));
}