<?php 
$_GET['request'] = '';

require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'/fw/user.php';

fw::lang(array('main'));

if(is_numeric($_GET['id']) && !user::data('room'))
{	
	$item = db::query("SELECT * FROM items WHERE id = ? AND user = ? AND equip = 1", array($_GET['id'], user::data('id')))->fetch();
		
	if(!empty($item))
	{	
		db::query("UPDATE items SET equip = 0 WHERE id = ?", array($item['id']));
	}
}