<?php 
$_GET['request'] = '';

require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'/fw/user.php';
require_once CWEB.'config/main.php';

fw::lang(array('main'));

if(($_GET['add'] == 'attack' || $_GET['add'] == 'defense' || $_GET['add'] == 'endurance') && user::data('points'))
{	
	if($_GET['add'] == 'endurance')
	{
		$health_increase = fw::config('health_increase');
		
		echo $health_increase;
		
		db::query("UPDATE users SET max_health = max_health + ? WHERE id = ?", array($health_increase, user::data('id')));
	}

	db::query("UPDATE users SET points = points - 1, ".$_GET['add']." = ".$_GET['add']." + 1 WHERE id = ?", array(user::data('id')));
}