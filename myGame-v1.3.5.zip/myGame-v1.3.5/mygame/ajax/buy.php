<?php 
$_GET['request'] = '';

require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'/fw/user.php';
require_once CWEB.'/fw/profile.php';

fw::lang(array('main'));

$errors = array();

if(is_numeric($_GET['id']) && user::online())
{	
	$item_entry = db::query("SELECT * FROM market WHERE id = ?", array($_GET['id']))->fetch();
	$item = db::query("SELECT * FROM items_".$item_entry['category']." WHERE id = ?", array($item_entry['item']))->fetch();
	
	if(user::data('money') < $item_entry['price']) $errors[] = 'e_price';
	if(user::data('id') == $item_entry['user']) $errors[] = 'e_item_owner';
	if(user::data('room')) $errors[] = 'You are not allowed to be in a room to do this.';
	
	if(empty($errors) && $item['id'])
	{
		$equip = 0;
		
		if($item['level'] <= user::data('level'))
		{			
			if(!db::count("items WHERE user = ? AND category = ? AND equip = 1", array(user::data('id'), $item_entry['category'])))
			{
				$equip = 1;
			}
		}
	
		db::insert('items', array('user' => user::data('id'), 'item' => $item['id'], 'category' => $item_entry['category'], 'equip' => $equip));
		
		db::query("DELETE FROM market WHERE id = ?", array($item_entry['id']));
		
		user::badge('items', 1);
		
		user::money(-$item_entry['price']);
		
		db::query("UPDATE users SET money = money + ?, money_gained_day = money_gained_day + ? WHERE id = ?", array($item_entry['price'], $item_entry['price'], $item_entry['user']));
		
		profile::log($item_entry['user'], 'item_bought|VALUES|item='.$item['name'].';user='.user::data('username').';price='.format_numbers($item_entry['price']).'');
		
		$echo = lang('item_bought', array('item' => $item['name'], 'price' => $item_entry['price']));
	}
}

if(!empty($errors))
{
	echo '<div class="errors">';
	
	foreach($errors as $error)
	{
		echo '<span>'.lang($error).'</span>';
	}
	
	echo '</div>|N|';
} else
{
	echo '<div class="success">'.$echo.'</div>|N|';
	echo format_numbers(user::data('money'));	
}