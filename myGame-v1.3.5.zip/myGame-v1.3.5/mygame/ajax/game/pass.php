<?php 
// Config
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require(CWEB.'config/main.php');
require(CWEB.'fw/user.php');
require(CWEB.'fw/profile.php');

// Proceed
if(file_exists(CWEB.'temp/rooms/'.user::data('room').'.temp'))
{	
	$player_file = fopen(CWEB.'temp/players/'.user::data('id').'.temp', 'r+');
	$player = fread($player_file, filesize(CWEB.'temp/players/'.user::data('id').'.temp'));
	
	$game_file = fopen(CWEB.'temp/rooms/'.user::data('room').'.temp', 'r+');
	$game = fread($game_file, filesize(CWEB.'temp/rooms/'.user::data('room').'.temp'));
			
	$player = json_decode($player, true);
	$game = json_decode($game, true);	
		
	if($player['turn'] && $game['turn'] == user::data('id') && (fw::config('interval')+$player['time']) >= time())
	{
		// Update user player
		$player['turn'] = 0;
		$player['time'] = 0;
		
		if($player['stamina'] < $player['max_stamina'])
		{
			$player['stamina']++;
		}
		
		// Set next player
		$next_player = db::query("SELECT * FROM players WHERE room = ? AND finished = 0 AND `seat` > ? ORDER BY `seat` ASC LIMIT 1", array(user::data('room'), $player['seat']))->fetch();
		if(!isset($next_player['id'])) $next_player = db::query("SELECT * FROM players WHERE room = ? AND finished = 0 ORDER BY `seat` ASC LIMIT 1", array(user::data('room')))->fetch();

		$next_player_file = fopen(CWEB.'temp/players/'.$next_player['user'].'.temp', 'r+');
		$next_player_data = fread($next_player_file, filesize(CWEB.'temp/players/'.$next_player['user'].'.temp'));	
		$next_player_data = json_decode($next_player_data, true);
				
		$next_player_data['turn'] = 1;
		$next_player_data['time'] = time();
		
		$game['turn'] = $next_player['user'];
		$game['time'] = time();
		
		// Log entry
		$content = "|NM|".user::data('username')." passed this turn.";
		
		// Add data	
		rewind($game_file);
		rewind($player_file);
		rewind($next_player_file);
		
		ftruncate($game_file, 0);
		ftruncate($player_file, 0);
		ftruncate($next_player_file, 0);
		
		fwrite($game_file, json_encode($game));
		fwrite($player_file, json_encode($player));
		fwrite($next_player_file, json_encode($next_player_data));
		
		fclose($game_file);		
		fclose($player_file);		
		fclose($next_player_file);		
		
		// Add log entry
		$filename = CWEB.'temp/logs/'.$player['room'].'.temp';

		$fp = fopen($filename, 'a');
				
		fwrite($fp, $content);
		
		fclose($fp);

		$fp = fopen($filename, 'r+');

		if(filesize($filename) >= 1000)
		{

			rewind($fp);

			$tmp = '';

			fgets($fp);

			while($line = fgets($fp)) $tmp .= $line;

			rewind($fp);

			ftruncate($fp, 0);

			fwrite($fp, $tmp);	
			
			fclose($fp);
			
		}		
	} else
	{
		if($game['turn'] != user::data('id'))
		{
			$error = '<span>It is not your turn.</span>';
		}
		
		if(!$game['active'] || $game['finished'])
		{
			$error = '<span>This game is not active.</span>';
		}
		
		echo $error;
	}
}