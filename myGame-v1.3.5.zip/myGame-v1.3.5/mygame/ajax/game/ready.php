<?php 
// Config
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require(CWEB.'fw/user.php');
require(CWEB.'fw/profile.php');

// Proceed
if(file_exists(CWEB.'temp/players/'.user::data('id').'.temp'))
{	
	$player_file = fopen(CWEB.'temp/players/'.user::data('id').'.temp', 'r+');
	$player = fread($player_file, filesize(CWEB.'temp/players/'.user::data('id').'.temp'));
	
	$game_file = fopen(CWEB.'temp/rooms/'.user::data('room').'.temp', 'r+');
	$game = fread($game_file, filesize(CWEB.'temp/rooms/'.user::data('room').'.temp'));
			
	$player = json_decode($player, true);
	$game = json_decode($game, true);	

	if(!$player['ready'] && !$game['active'])
	{	
		// Update user player
		$player['ready'] = 1;
		$content = "\r\n|NM|".user::data('username')." is ready.";
		
		db::query("UPDATE players SET ready = 1 WHERE user = ?", array(user::data('id')));		
		
		// Start game
		if($game['players'] == db::count("players WHERE room = ? AND ready = 1", array(user::data('room'))))
		{	
			$content .= "\r\n|NM|Game has started.";
		
			$game['active'] = 1;
			$game['time'] = time();
			
			// Select first player
			$first_player = db::query("SELECT * FROM players WHERE room = ? AND ready = 1 ORDER BY RAND() LIMIT 1", array(user::data('room')))->fetch();			
			$game['turn'] = $first_player['user'];

			$first_player_file = fopen(CWEB.'temp/players/'.$first_player['user'].'.temp', 'r+');
			$first_player_data = fread($first_player_file, filesize(CWEB.'temp/players/'.$first_player['user'].'.temp'));	
			$first_player_data = json_decode($first_player_data, true);
			
			$first_player_data['time'] = time();
			$first_player_data['turn'] = 1;
						
			db::query("UPDATE rooms SET active = 1 WHERE id = ?", array(user::data('room')));
		}
				
		// Add data
		rewind($game_file);
		rewind($player_file);
		rewind($first_player_file);
		
		ftruncate($game_file, 0);
		ftruncate($player_file, 0);
		ftruncate($first_player_file, 0);
		
		fwrite($game_file, json_encode($game));
		fwrite($player_file, json_encode($player));
		fwrite($first_player_file, json_encode($first_player_data));
		
		fclose($game_file);		
		fclose($player_file);		
		fclose($first_player_file);		
		
		// Add log entry
		$filename = CWEB.'temp/logs/'.$player['room'].'.temp';

		$fp = fopen($filename, 'a');
				
		fwrite($fp, $content);
		
		fclose($fp);

		$fp = fopen($filename, 'r+');

		if(filesize($filename) >= 1000)
		{

			rewind($fp);

			$tmp = '';

			fgets($fp);

			while($line = fgets($fp)) $tmp .= $line;

			rewind($fp);

			ftruncate($fp, 0);

			fwrite($fp, $tmp);	
			
			fclose($fp);
			
		}
	}
}