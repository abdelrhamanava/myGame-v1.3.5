<?php 
if(is_numeric($_GET['id']))
{	
	if(file_exists('../../temp/rooms/'.$_GET['id'].'.temp'))
	{
		clearstatcache();
		echo filemtime('../../temp/rooms/'.$_GET['id'].'.temp');
	}
}