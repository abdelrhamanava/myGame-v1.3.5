<?php 
if(is_numeric($_GET['id']))
{
	$id = $_GET['id'];
	
	if(file_exists('../../temp/players/'.$id.'.temp'))
	{
		$data = json_decode(file_get_contents('../../temp/players/'.$id.'.temp'), true);
		
		// Stats
		$return = $data['stamina'].' / '.$data['max_stamina'].'-'.@round($data['stamina']/$data['max_stamina']*100, 2);
		
		$return .= '|N|'.$data['health'].' / '.$data['max_health'].'-'.@round($data['health']/$data['max_health']*100, 2);
		
		// Items
		if($data['extra'])
		{
			$return .= '|N|'.$data['extra'];
		}
		
		if($data['special'])
		{
			$return .= '-'.$data['special'];
		}
		
		echo $return;
	}
}