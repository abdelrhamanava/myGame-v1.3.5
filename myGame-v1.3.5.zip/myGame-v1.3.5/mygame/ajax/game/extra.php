<?php 
// Config
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require(CWEB.'config/main.php');
require(CWEB.'fw/user.php');
require(CWEB.'fw/profile.php');

// Proceed
if(file_exists(CWEB.'temp/rooms/'.user::data('room').'.temp') && is_numeric($_GET['id']))
{	
	$player_file = fopen(CWEB.'temp/players/'.user::data('id').'.temp', 'r+');
	$player = fread($player_file, filesize(CWEB.'temp/players/'.user::data('id').'.temp'));
	$player = json_decode($player, true);
	
	$game_file = fopen(CWEB.'temp/rooms/'.user::data('room').'.temp', 'r+');
	$game = fread($game_file, filesize(CWEB.'temp/rooms/'.user::data('room').'.temp'));
	$game = json_decode($game, true);	

	if(user::data('id') != $_GET['id'])
	{
		$target_file = fopen(CWEB.'temp/players/'.$_GET['id'].'.temp', 'r+');
		$target = fread($target_file, filesize(CWEB.'temp/players/'.$_GET['id'].'.temp'));
		$target = json_decode($target, true);
	}
	
	$item = @db::query("SELECT * FROM items WHERE user = ? AND category = 'special' AND equip = 1", array(user::data('id')))->fetch();
	$item = @db::query("SELECT * FROM items_special WHERE id = ?", array($item['item']))->fetch();	

	if($player['turn'] && !empty($item) && (@$item['type'] == 'health' || @$item['type'] == 'stamina') && db::count("items WHERE user = ? AND category = 'special' AND equip = 1", array(user::data('id'))) && !$player['special'] && $player['stamina'] > 0 && $game['turn'] == user::data('id') && (fw::config('interval')+$player['time']) >= time() && $player['health'] > 0)
	{		
		if(($game['type'] == 'team_deathmatch' || $game['type'] == 'deathmatch') && ($player['health'] > 0 && $_GET['id'] == $player['user']))
		{
			// Update user player
			$player['turn'] = 0;
			$player['time'] = 0;
			$player['special'] = 1;
			
			if($player['stamina'] > 0)
			{
				$player['stamina']--;
			}
			
			// Calculate effect
			$item = db::query("SELECT * FROM items WHERE user = ? AND category = 'special' AND equip = 1", array(user::data('id')))->fetch();
			db::query("UPDATE items SET duration = duration - 1 WHERE id = ?", array($item['id']));

			$item = db::query("SELECT * FROM items_special WHERE id = ?", array($item['item']))->fetch();
			$effect = $item['effect'];
						
			if($item['type'] == 'health')
			{
				$player['health'] = round($player['health']+$player['max_health']*$item['effect']);
				
				if($player['health'] > $player['max_health'])
				{
					$player['health'] = $player['max_health'];
				}
				
				$type = 'Health';
			} 
			
			if($item['type'] == 'stamina')
			{
				$player['stamina'] = round($player['stamina']+$player['max_stamina']*$item['effect']);
				
				if($player['stamina'] > $player['max_stamina'])
				{
					$player['stamina'] = $player['max_stamina'];
				}
				
				$type = 'Stamina';
			}
			
			
			// Set next player
			$next_player = db::query("SELECT * FROM players WHERE room = ? AND finished = 0 AND `seat` > ?", array(user::data('room'), $player['seat']))->fetch();
			if(!isset($next_player['id'])) $next_player = db::query("SELECT * FROM players WHERE room = ? AND finished = 0 ORDER BY `seat` ASC LIMIT 1", array(user::data('room')))->fetch();

			$next_player_file = fopen(CWEB.'temp/players/'.$next_player['user'].'.temp', 'r+');
			$next_player_data = fread($next_player_file, filesize(CWEB.'temp/players/'.$next_player['user'].'.temp'));	
			$next_player_data = json_decode($next_player_data, true);
					
			$next_player_data['turn'] = 1;
			$next_player_data['time'] = time();
			
			$game['turn'] = $next_player['user'];
			$game['time'] = time();
		
			// Log entry
			$content = "|NM|".user::data('username')." used special item. (".$type." +".format_numbers($effect*100)."%).";
			
			// Add data	
			rewind($game_file);		
			ftruncate($game_file, 0);		
			fwrite($game_file, json_encode($game));

			rewind($player_file);
			ftruncate($player_file, 0);		
			fwrite($player_file, json_encode($player));

			rewind($next_player_file);
			ftruncate($next_player_file, 0);
			fwrite($next_player_file, json_encode($next_player_data));
			fclose($next_player_file);		
			
			// Add log entry
			$filename = CWEB.'temp/logs/'.$player['room'].'.temp';

			$fp = fopen($filename, 'a');
					
			fwrite($fp, $content);
			
			fclose($fp);

			$fp = fopen($filename, 'r+');

			if(filesize($filename) >= 1000)
			{

				rewind($fp);

				$tmp = '';

				fgets($fp);

				while($line = fgets($fp)) $tmp .= $line;

				rewind($fp);

				ftruncate($fp, 0);

				fwrite($fp, $tmp);	
				
				fclose($fp);
				
			}	
			
		} else if($game['type'] == 'team_deathmatch' && $player['health'] > 0 && $_GET['id'] != user::data('id') && $target['health'] > 0 && $target['team'] == $player['team'])
		{
			// Update user player
			$player['turn'] = 0;
			$player['time'] = 0;
			$player['special'] = 1;
			
			if($player['stamina'] > 0)
			{
				$player['stamina']--;
			}
			
			// Calculate effect
			$item = db::query("SELECT * FROM items WHERE user = ? AND category = 'special' AND equip = 1", array(user::data('id')))->fetch();
			$item = db::query("SELECT * FROM items_special WHERE id = ?", array($item['item']))->fetch();
			$effect = $item['effect'];
			
			if($item['type'] == 'health')
			{
				$target['health'] = round($target['health']+$target['max_health']*$item['effect']);
				
				if($target['health'] > $target['max_health'])
				{
					$target['health'] = $target['max_health'];
				}
				
				$type = 'Health';
			}
			
			if($item['type'] == 'stamina')
			{
				$target['stamina'] = round($target['stamina']+$target['max_stamina']*$item['effect']);
				
				if($target['stamina'] > $target['max_stamina'])
				{
					$target['stamina'] = $target['max_stamina'];
				}
				
				$type = 'Stamina';
			}			
			
			// Set next player
			$next_player = db::query("SELECT * FROM players WHERE room = ? AND finished = 0 AND `seat` > ? ORDER BY `seat` ASC LIMIT 1", array(user::data('room'), $player['seat']))->fetch();
			if(!isset($next_player['id'])) $next_player = db::query("SELECT * FROM players WHERE room = ? AND finished = 0 ORDER BY `seat` ASC LIMIT 1", array(user::data('room')))->fetch();

			
			if($next_player['user'] != $target['user'])
			{
				$next_player_file = fopen(CWEB.'temp/players/'.$next_player['user'].'.temp', 'r+');
				$next_player_data = fread($next_player_file, filesize(CWEB.'temp/players/'.$next_player['user'].'.temp'));	
				$next_player_data = json_decode($next_player_data, true);
						
				$next_player_data['turn'] = 1;
				$next_player_data['time'] = time();
				
				$game['turn'] = $next_player['user'];
				$game['time'] = time();
			} else
			{
				$game['turn'] = $target['user'];
				$game['time'] = time();	

				$target['turn'] = 1;
				$target['time'] = time();						
			}
		
			// Log entry
			$content = "|NM|".user::data('username')." used special item on ".profile::data($target['user'], 'username').". (".$type." +".format_numbers($effect*100).").";
			
			// Add data	
			rewind($game_file);		
			ftruncate($game_file, 0);		
			fwrite($game_file, json_encode($game));

			rewind($player_file);
			ftruncate($player_file, 0);		
			fwrite($player_file, json_encode($player));

			if($next_player['user'] != $target['user'])
			{
				rewind($next_player_file);
				ftruncate($next_player_file, 0);
				fwrite($next_player_file, json_encode($next_player_data));
				fclose($next_player_file);	
			}
			
			rewind($target_file);
			ftruncate($target_file, 0);		
			fwrite($target_file, json_encode($target));			
			
			// Add log entry
			$filename = CWEB.'temp/logs/'.$player['room'].'.temp';

			$fp = fopen($filename, 'a');
					
			fwrite($fp, $content);
			
			fclose($fp);

			$fp = fopen($filename, 'r+');

			if(filesize($filename) >= 1000)
			{

				rewind($fp);

				$tmp = '';

				fgets($fp);

				while($line = fgets($fp)) $tmp .= $line;

				rewind($fp);

				ftruncate($fp, 0);

				fwrite($fp, $tmp);	
				
				fclose($fp);
				
			}				
		} else
		{
			if($game['type'] == 'team_deathmatch' && $target['team'] != $player['team'])
			{
				$error = '<span>This player is in your team.</span>';
			}	
			
			if($game['type'] == 'deathmatch' && $player['user'] != $_GET['id'])
			{
				$error = '<span>You may only use this item on yourself.</span>';
			}

			if(!empty($error))
			{
				echo $error;
			}
		}

	fclose($game_file);		

	fclose($player_file);	

	if(user::data('id') != $_GET['id'])
	{
		fclose($target_file);
	}	
	
	} else
	{	
		if($game['turn'] != user::data('id'))
		{
			$error = '<span>It is not your turn.</span>';
		}
	
		if(!db::count('items WHERE user = ? AND category = "special" AND equip = 1', array(user::data('id'))))
		{
			$error = '<span>You do not have a special item equipped to your character.</span>';
		}
	
		if(!$game['active'] || $game['finished'])
		{
			$error = '<span>This game is not active.</span>';
		}
			
		if(!empty($item) || (@$item['type'] != 'health' && @$item['type'] != 'stamina'))
		{
			$error = '<span>Your special item is not designed for battle.</span>';
		}
		
		if($player['health'] <= 0)
		{
			$error = '<span>You are dead.</span>';
		}
		
		if($player['special'])
		{
			$error = '<span>You have already used your special item in this fight.</span>';
		}		
		
		if($player['stamina'] <= 0)
		{
			$error = '<span>You are out of stamina, pass a turn to gain stamina.</span>';
		}		
		
		if(!empty($error))
		{
			echo $error;
		}
	}
}