<?php 
if(is_numeric($_GET['id']))
{
	$id = $_GET['id'];
	
	if(file_exists('../../temp/rooms/'.$id.'.temp'))
	{
		$game_file = fopen('../../temp/rooms/'.$_GET['id'].'.temp', 'r+');
		$game = fread($game_file, filesize('../../temp/rooms/'.$_GET['id'].'.temp'));
		$game = json_decode($game, true);	

		$return = $game['turn'];
		
		if($game['active'] && empty($_GET['turn']))
		{
			$return = 'start-'.$game['turn'];
		}
		
		if(!$game['active'] && empty($_GET['turn']) && !empty($_GET['current_players']))
		{
			if($_GET['current_players'] != $game['current_players'])
			{
				$return = 'load_players-'.$game['current_players'];
			}
		}		
		
		if(($game['type'] == 'deathmatch' && $game['current_players'] <= 1 && !$game['finished'] && $game['active']))
		{		
			$game['finished'] = 1;
			$game['time'] = time();
			$game['active'] = 0;
			
			rewind($game_file);
			ftruncate($game_file, 0);
			fwrite($game_file, json_encode($game));
			
			$content = '|NM|Game over.';

			// Add log entry
			$filename = '../../temp/logs/'.$_GET['id'].'.temp';

			$fp = fopen($filename, 'a');
					
			fwrite($fp, $content);
			
			fclose($fp);

			$fp = fopen($filename, 'r+');

			if(filesize($filename) >= 1000)
			{

				rewind($fp);

				$tmp = '';

				fgets($fp);

				while($line = fgets($fp)) $tmp .= $line;

				rewind($fp);

				ftruncate($fp, 0);

				fwrite($fp, $tmp);	
				
				fclose($fp);
				
			}
				
			$return = 'finish';
		}
		
		if(($game['type'] == 'team_deathmatch' && $game['current_players'] <= 2 && !$game['finished'] && $game['active']) && ($game['team_1'] <= 0 || $game['team_2'] <= 0))
		{
			$game['finished'] = 1;
			$game['time'] = time();
			$game['active'] = 0;
			
			rewind($game_file);
			ftruncate($game_file, 0);
			fwrite($game_file, json_encode($game));
			
			$content = '|NM|Game over.';

			// Add log entry
			$filename = '../../temp/logs/'.$_GET['id'].'.temp';

			$fp = fopen($filename, 'a');
					
			fwrite($fp, $content);
			
			fclose($fp);

			$fp = fopen($filename, 'r+');

			if(filesize($filename) >= 1000)
			{

				rewind($fp);

				$tmp = '';

				fgets($fp);

				while($line = fgets($fp)) $tmp .= $line;

				rewind($fp);

				ftruncate($fp, 0);

				fwrite($fp, $tmp);	
				
				fclose($fp);
				
			}
				
			$return = 'finish';
		}
		
		if($game['finished'])
		{
			$return = 'finish';
		}
		
		fclose($game_file);		
	
		echo $return;
	}
}