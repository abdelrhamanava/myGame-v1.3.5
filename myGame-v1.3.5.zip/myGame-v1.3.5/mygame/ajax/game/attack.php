<?php 
// Config
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require(CWEB.'config/main.php');
require(CWEB.'fw/user.php');
require(CWEB.'fw/profile.php');

// Proceed
if(file_exists(CWEB.'temp/rooms/'.user::data('room').'.temp') && is_numeric($_GET['id']))
{	
	$player_file = fopen(CWEB.'temp/players/'.user::data('id').'.temp', 'r+');
	$player = fread($player_file, filesize(CWEB.'temp/players/'.user::data('id').'.temp'));
	$player = json_decode($player, true);
	
	$game_file = fopen(CWEB.'temp/rooms/'.user::data('room').'.temp', 'r+');
	$game = fread($game_file, filesize(CWEB.'temp/rooms/'.user::data('room').'.temp'));
	$game = json_decode($game, true);	

	$victim_file = fopen(CWEB.'temp/players/'.$_GET['id'].'.temp', 'r+');
	$victim = fread($victim_file, filesize(CWEB.'temp/players/'.$_GET['id'].'.temp'));
	$victim = json_decode($victim, true);
	
	if(($player['turn'] && $player['stamina'] > 0 && $game['turn'] == user::data('id') && (fw::config('interval')+$player['time']) >= time() && $player['health'] > 0 && $victim['health'] > 0 && $victim['room'] == $player['room']))
	{
		if(($player['team'] != $victim['team'] && $game['type'] == 'deathmatch') || ($player['team'] == $victim['team'] && $game['type'] == 'deathmatch') || ($player['team'] != $victim['team'] && $game['type'] == 'team_deathmatch'))
		{
			// Update user player
			$player['turn'] = 0;
			$player['time'] = 0;
			
			if($player['stamina'] > 0)
			{
				$player['stamina']--;
			}
			
			// Calculate damage
			$attack = db::query("SELECT * FROM items WHERE user = ? AND category = 'weapons' AND equip = 1", array(user::data('id')))->fetch();
			$attack = db::query("SELECT * FROM items_weapons WHERE id = ?", array($attack['item']))->fetch();
			$attack = $attack['effect']+user::data('attack');
			
			$defense = db::query("SELECT * FROM items WHERE user = ? AND category = 'weapons' AND equip = 1", array($victim['user']))->fetch();
			$defense = db::query("SELECT * FROM items_defense WHERE id = ?", array($defense['item']))->fetch();
			$defense = $defense['effect']+profile::data($victim['user'], 'defense');
			
			$damage = @round($attack-($defense*mt_rand(1.00, 1.15)))+mt_rand(5, 8);

			if($damage <= 0) $damage = mt_rand(3, 5);
			
			$experience = @round($damage/mt_rand(0.050, 0.300))+1;			

			$item = @db::query("SELECT * FROM items WHERE user = ? AND category = 'special' AND equip = 1", array(user::data('id')))->fetch();
			$item = @db::query("SELECT * FROM items_special WHERE id = ? AND type = ?", array($item['item'], 'experience'))->fetch();	
			
			if(!empty($item))
			{
				$experience = round($experience+($experience*$item['effect']));
			}
			
			if($victim['health']-$damage < 0)
			{
				$damage = $victim['health'];
				$experience = @round($damage/mt_rand(0.250, 0.400))+1;
				
				db::query("UPDATE players SET finished = 1 WHERE user = ?", array($victim['user']));
			}

			if($damage <= 0) $damage = mt_rand(3, 5);
			
			$victim['health'] = $victim['health']-$damage;
			$player['experience'] = $player['experience']+$experience;
			
			// Check if victim is dead
			if($victim['health'] <= 0)
			{
				$victim['finished'] = 1;
				$game['current_players'] = $game['current_players'] - 1;
				
				// Check team status
				$game['team_'.$victim['team']]--;				
			}
			
			// Set next player
			$next_player = db::query("SELECT * FROM players WHERE room = ? AND finished = 0 AND `seat` > ? ORDER BY `seat` ASC LIMIT 1", array(user::data('room'), $player['seat']))->fetch();
			if(empty($next_player)) $next_player = db::query("SELECT * FROM players WHERE room = ? AND finished = 0 ORDER BY `seat` ASC LIMIT 1", array(user::data('room')))->fetch();
			
			if($next_player['user'] != $victim['user'])
			{
				$next_player_file = fopen(CWEB.'temp/players/'.$next_player['user'].'.temp', 'r+');
				$next_player_data = fread($next_player_file, filesize(CWEB.'temp/players/'.$next_player['user'].'.temp'));	
				$next_player_data = json_decode($next_player_data, true);
						
				$next_player_data['turn'] = 1;
				$next_player_data['time'] = time();
				
				$game['turn'] = $next_player['user'];
				$game['time'] = time();
			} else
			{
				$game['turn'] = $victim['user'];
				$game['time'] = time();	

				$victim['turn'] = 1;
				$victim['time'] = time();			
			}
			
			// Log entry
			$content = "|NM|".user::data('username')." attacked ".profile::data($victim['user'], 'username')." (Health -".format_numbers($damage).").";
			
			// Add data	
			rewind($game_file);		
			ftruncate($game_file, 0);		
			fwrite($game_file, json_encode($game));

			rewind($player_file);
			ftruncate($player_file, 0);		
			fwrite($player_file, json_encode($player));

			if($next_player['user'] != $victim['user'])
			{
				rewind($next_player_file);
				ftruncate($next_player_file, 0);
				fwrite($next_player_file, json_encode($next_player_data));
				fclose($next_player_file);		
			}
			
			rewind($victim_file);
			ftruncate($victim_file, 0);		
			fwrite($victim_file, json_encode($victim));

			// Add log entry
			$filename = CWEB.'temp/logs/'.$player['room'].'.temp';

			$fp = fopen($filename, 'a');
					
			fwrite($fp, $content);
			
			fclose($fp);

			$fp = fopen($filename, 'r+');

			if(filesize($filename) >= 1000)
			{

				rewind($fp);

				$tmp = '';

				fgets($fp);

				while($line = fgets($fp)) $tmp .= $line;

				rewind($fp);

				ftruncate($fp, 0);

				fwrite($fp, $tmp);	
				
				fclose($fp);
				
			}	
			
		} else
		{
			if($game['type'] == 'team_deathmatch' && $victim['team'] == $player['team'])
			{
				$error = '<span>This player is in your team.</span>';
			}	
			
			echo $error;
		}

	fclose($game_file);		

	fclose($player_file);		
		
	fclose($victim_file);		
		
	} else
	{	
		if($game['turn'] != user::data('id'))
		{
			$error = '<span>It is not your turn.</span>';
		}
		
		if(!$game['active'] || $game['finished'])
		{
			$error = '<span>This game is not active.</span>';
		}
		
		if($player['health'] <= 0)
		{
			$error = '<span>You are dead.</span>';
		}
		
		if($player['stamina'] <= 0)
		{
			$error = '<span>You are out of stamina, pass a turn to gain stamina.</span>';
		}		
		
		if($victim['health'] <= 0)
		{
			$error = '<span>Target is dead.</span>';
		}
		
		if(!empty($error))
		{
			echo $error;
		}
	}
}