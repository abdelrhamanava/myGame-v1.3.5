<?php 
// Config
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require(CWEB.'config/main.php');
require(CWEB.'fw/user.php');
require(CWEB.'fw/profile.php');

fw::lang(array('main'));

if(user::online())
{
	$player = json_decode(file_get_contents('../../temp/players/'.user::data('id').'.temp'), true);
	$game = json_decode(file_get_contents('../../temp/rooms/'.user::data('room').'.temp'), true);

	echo '
		<div class="box avatar_wrap left" style="overflow: auto;">
	';
	
	if(file_exists(CWEB.'upload/avatar/'.user::data('id').'.png'))
	{
		echo '<div class="avatar"><img alt="avatar" src="../upload/avatar/'.user::data('id').'.png"></div>';
	} else
	{
		echo '<div class="avatar"><img alt="avatar" src="../upload/avatar/0.png"></div>';
	}
	
	echo '
		</div>
		
		<div class="box right">
	';
	
	if($player['health'] && !$player['finished']){
		echo '<span class="right"><img alt="winner" src="../style/'.fw::config('style').'/icons/game/winner.png"> Winner</span>';
	}
	
	echo '
		'.profile::link(user::data('id')).'
		</div>
	';
	
	if($game['bet'])
	{
		echo '
			<div class="box right">
				<span class="left"><img alt="money" src="../style/'.fw::config('style').'/icons/main/money.png"> '.lang('money').'</span>
				<span class="right">
				';
				if(!$player['finished'] && $player['health'])
				{ 
					echo '+'.format_numbers($game['bet']*($game['players']-1));
				} else
				{ 
					echo '-'.format_numbers($game['bet']); 
				} 
				echo '
				</span>
			</div>
		';
	}
	
	echo '
		<div class="box right">
			<span class="left"><img alt="experience" src="../style/'.fw::config('style').'/icons/main/experience.png"> '.lang('experience').'</span>
			<span class="right">+ ';
			
			if(!$player['finished'] && $player['health'])
			{
				echo format_numbers(round($player['experience']*1.5));
			} else
			{
				echo format_numbers($player['experience']);
			}
			
	echo '		
			</span>
		</div>
		
		<div class="box right">
			<span class="left"><a href="?finish=1">'.lang('finish').'</a></span>
		</div>
	';
}