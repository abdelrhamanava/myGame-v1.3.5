<?php 
// Config
$_GET['request'] = '';

require_once '../../fw/main.php';
require_once CWEB.'fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'config/main.php';
require_once CWEB.'fw/user.php';
require_once CWEB.'fw/profile.php';

fw::lang(array('main', 'room'));

if(is_numeric($_GET['seat']))
{
	$id = user::data('room');
	$seat = $_GET['seat'];
	
	foreach(db::query("SELECT * FROM players WHERE room = ? AND seat = ?", array($id, $seat)) as $player)
	{
	
		if(file_exists('../../temp/players/'.$player['user'].'.temp'))
		{
			$player = json_decode(file_get_contents('../../temp/players/'.$player['user'].'.temp'), true);
			$room = json_decode(file_get_contents('../../temp/rooms/'.$player['room'].'.temp'), true);
								
			echo '
				<div id="'.$player['user'].'" style="overflow: auto;">
			
					<h1 class="player">'.profile::link($player['user']).'<span class="right">'.lang('level').' '.profile::data($player['user'], 'level').'</span></h1>
					<div class="box player" style="overflow: auto;">
			
			';
			
			if(file_exists(CWEB.'upload/avatar/'.$player['user'].'.png'))
			{
				echo '<div class="avatar"><img alt="avatar" src="../upload/avatar/'.$player['user'].'.png"></div>';
			} else
			{
				echo '<div class="avatar"><img alt="avatar" src="../upload/avatar/0.png"></div>';
			}
						
			echo '
						<table '.(($room['active'] && !$room['finished'])?'style="display: none;"':"").' class="data prestats">
							<tr>
								<td><img class="icon" src="../style/'.fw::config('style').'/icons/main/reputation.png"> '.lang('reputation').'</td>
								<td id="reputation">'.format_numbers(profile::data($player['user'], 'reputation')).'</td>
							</tr>
							<tr>
								<td><img class="icon" src="../style/'.fw::config('style').'/icons/main/money.png"> '.lang('money').'</td>
								<td id="money">'.format_numbers(profile::data($player['user'], 'money')).'</td>
							</tr>
						</table>
						
						<div '.(($room['active'] && !$room['finished'])?'style="display: none;"':"").' class="badges">';
							foreach(db::query("SELECT * FROM user_badges WHERE user = ? ORDER BY id DESC LIMIT 5", array($player['user'])) as $badge):
							$badge = db::query("SELECT * FROM badges WHERE id = ?", array($badge['badge']))->fetch();
							
						echo '
							<div class="badge">
								<img alt="'.$badge['title'].'" title="'.$badge['title'].'" src="../images/badges/'.$badge['id'].'.png">
							</div>';
							endforeach;
							
						echo '
							<div class="clear"><!-- Clear !--></div>					
						</div>
						
						<div '.((!$room['active'] || $room['finished'])?'style="display: none;"':"").' class="gamestats">
						
							<div class="status stamina">
								<p class="left">'.lang('stamina').'</p>
								<p class="right">'.format_numbers($player['stamina']).' / '.format_numbers($player['max_stamina']).'</p>
								
								<div class="clear"><!-- Clear !--></div>
								
								<div class="bar">
									<div class="fill" style="width: '.round($player['stamina']/$player['max_stamina']*100, 2).'%;"><!-- Fill !--></div>
								</div>
							</div>
							
							<div class="status health">
								<p class="left">'.lang('health').'</p>
								<p class="right">'.format_numbers($player['health']).' / '.format_numbers($player['max_health']).'</p>
								
								<div class="clear"><!-- Clear !--></div>
								
								<div class="bar">
									<div class="fill" style="width: '.round($player['health']/$player['max_health']*100, 2).'%;"><!-- Fill !--></div>
								</div>
							</div>

							<div class="status time">
								<p class="left">'.lang('time_left').'</p>
								<p class="right"></p>
								
								<div class="clear"><!-- Clear !--></div>
								
								<div class="bar">
									<div class="fill" style="width: 0%;"><!-- Fill !--></div>
								</div>
							</div>				
							
							<div class="clear"><!-- Clear !--></div>

						</div>
										
					</div>	
					
					<div style="display: none;" class="errors"><!-- Clear !--></div>	
				';
				
				if(user::data('id') != $player['user'])
				{
					
					echo '
						<div '.((!$room['active'] || $room['finished'])?'style="display: none;"':"").' class="box actions_opponent">		
							<a class="a_button attack" href="Javascript: void(0);" onclick="Action.attack('.$player['user'].');">'.lang('attack').'</a>
							<a class="a_button special_attack" href="Javascript: void(0);" onclick="Action.special_attack('.$player['user'].');">'.lang('special_attack').'</a>
						</div>
					';
				
				}
			
				echo '
						<div class="clear"><!-- Clear !--></div>
					
					</div>
				';
					
		}		
	}
	
	if(!db::count("players WHERE room = ? AND seat = ?", array($id, $seat)))
	{
		echo '
			<div class="box empty" style="overflow: auto;">
				'.lang('empty').'
			</div>			
		';
	}
}