<?php 
// Config
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require(CWEB.'fw/user.php');
require(CWEB.'fw/profile.php');

// Proceed
if(file_exists(CWEB.'temp/players/'.user::data('id').'.temp'))
{	
	$player_file = fopen(CWEB.'temp/players/'.user::data('id').'.temp', 'r+');
	$player = fread($player_file, filesize(CWEB.'temp/players/'.user::data('id').'.temp'));
	
	$game_file = fopen(CWEB.'temp/rooms/'.user::data('room').'.temp', 'r+');
	$game = fread($game_file, filesize(CWEB.'temp/rooms/'.user::data('room').'.temp'));
			
	$player = json_decode($player, true);
	$game = json_decode($game, true);	

	if(!$player['finished'] && $game['active'])
	{
		// Update user player
		$player['finished'] = 1;
		$player['health'] = 0;
		$content = "|NM|".user::data('username')." surrendered.";
		
		db::query("UPDATE players SET finished = 1 WHERE user = ?", array($player['user']));
		
		// Switch turns	
		if($game['active'] && $game['current_players'] > 1)
		{
			$next_player = @db::query("SELECT * FROM players WHERE room = ? AND `seat` > ? AND user != ".user::data('id')." ORDER BY `seat` ASC LIMIT 1", array(user::data('room'), $player['seat']))->fetch();
			if(empty($next_player)) $next_player = @db::query("SELECT * FROM players WHERE room = ? AND user != ".user::data('id')." ORDER BY `seat` ASC LIMIT 1", array(user::data('room')))->fetch();

			$next_player_file = fopen(CWEB.'temp/players/'.$next_player['user'].'.temp', 'r+');
			$next_player_data = fread($next_player_file, filesize(CWEB.'temp/players/'.$next_player['user'].'.temp'));	
			$next_player_data = json_decode($next_player_data, true);
			
			$next_player_data['turn'] = 1;
			$next_player_data['time'] = time();
		
			$game['turn'] = $next_player['user'];
			
			$game['current_players']--;
			
			$game['team_'.$player['team']]--;
		}
		
		// Add data
		rewind($game_file);
		ftruncate($game_file, 0);
		fwrite($game_file, json_encode($game));

		rewind($player_file);
		ftruncate($player_file, 0);
		fwrite($player_file, json_encode($player));

		rewind($next_player_file);
		ftruncate($next_player_file, 0);
		fwrite($next_player_file, json_encode($next_player_data));
		fclose($next_player_file);			
								
		// Add log entry
		$filename = CWEB.'temp/logs/'.$player['room'].'.temp';

		$fp = fopen($filename, 'a');
				
		fwrite($fp, $content);
		
		fclose($fp);

		$fp = fopen($filename, 'r+');

		if(filesize($filename) >= 1000)
		{

			rewind($fp);

			$tmp = '';

			fgets($fp);

			while($line = fgets($fp)) $tmp .= $line;

			rewind($fp);

			ftruncate($fp, 0);

			fwrite($fp, $tmp);	
			
			fclose($fp);
			
		}
		
		db::query("UPDATE players SET finished = 1 WHERE user = ?", array(user::data('id')));
	} else
	{
		echo '<span>Game is inactive.</span>';
	}
	
	fclose($game_file);		
	fclose($player_file);		
}