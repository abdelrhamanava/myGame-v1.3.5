<?php 
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require(CWEB.'fw/user.php');
require(CWEB.'fw/profile.php');

if($_GET['message'] && user::data('mute') < time())
{	
	$filename = CWEB.'temp/chat/'.user::data('room').'.temp';
	$content = "\r\n|NM|".user::data('username').": ".$_GET['message'];

	$fp = fopen($filename, 'a');
			
	fwrite($fp, $content);
	
	fclose($fp);

	$fp = fopen($filename, 'r+');

	if(filesize($filename) >= 1000)
	{

		rewind($fp);

		$tmp = '';

		fgets($fp);

		while($line = fgets($fp)) $tmp .= $line;

		rewind($fp);

		ftruncate($fp, 0);

		fwrite($fp, $tmp);	
		
		fclose($fp);
		
	}
}