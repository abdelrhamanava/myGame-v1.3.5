<?php 
if(is_numeric($_GET['id']))
{
	$chat = $_GET['id'];
	
	if(file_exists('../../temp/chat/'.$chat.'.temp'))
	{
		clearstatcache();
		echo filemtime('../../temp/chat/'.$_GET['id'].'.temp');
	}
}