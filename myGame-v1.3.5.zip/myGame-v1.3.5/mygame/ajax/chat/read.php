<?php 
if(is_numeric($_GET['id']))
{
	$chat = $_GET['id'];
	
	if(file_exists('../../temp/chat/'.$chat.'.temp'))
	{
		$posts = explode('|NM|', file_get_contents('../../temp/chat/'.$chat.'.temp'));
					
		$i = 0;
		foreach(array_reverse($posts) as $post)
		{
			$i++;
		
			if($i <= 5)
			{
				$r = Array
				(
					'<' => '&lt;',
					'>' => '&gt;',
					'"' => '&quot;',
					'(' => '&#40;',
					')' => '&#41;',
					'õ' => '&otilde;',
					'ä' => '&auml;',
					'ö' => '&ouml;',
					'ü' => '&uuml;',
					'Õ' => '&Otilde;',
					'Ä' => '&Auml;',
					'Ö' => '&Ouml;',
					'Ü' => '&Uuml;',
					'\\' => '',
					'!' => '&#33;',
					"'" => '&#39;'
				);
				
				$post = str_replace(array_keys($r), $r, $post);
			
				$display[] = '<div class="message">'.$post.'</div>';
			}
		}
		
		foreach(array_reverse($display) as $show)
		{
			echo $show;
		}
	}
}