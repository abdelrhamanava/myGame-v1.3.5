<?php 
$_GET['request'] = '';

require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'/fw/user.php';

fw::lang(array('main'));

if(is_numeric($_GET['id']) && !user::data('room'))
{	
	$item = db::query("SELECT * FROM items WHERE id = ? AND user = ?", array($_GET['id'], user::data('id')))->fetch();
		
	if(!empty($item) && user::data('level') >= db::query("SELECT level FROM items_".$item['category']." WHERE id = ?", array($item['item']))->fetchColumn())
	{	
		if(db::count("items WHERE equip = 1 AND user = ? AND category = ?", array(user::data('id'), $item['category'])))
		{
			$unequip = db::query("SELECT * FROM items WHERE user = ? AND equip = 1 AND category = ?", array(user::data('id'), $item['category']))->fetch();
			
			echo $unequip['id'];
			
			db::query("UPDATE items SET equip = 0 WHERE id = ?", array($unequip['id']));
		}

		db::query("UPDATE items SET equip = 1 WHERE id = ?", array($item['id']));
	} else
	{
		echo 'failed';
	}
}