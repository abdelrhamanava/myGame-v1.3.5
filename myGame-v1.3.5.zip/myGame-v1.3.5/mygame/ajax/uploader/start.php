<?php
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

$id = $_GET['id'];

if(strlen($id) != 13) exit();

db::insert('upload', array('id' => $id));