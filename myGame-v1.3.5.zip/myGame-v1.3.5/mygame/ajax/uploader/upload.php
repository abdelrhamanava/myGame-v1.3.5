<?php
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Configuration
foreach(db::query('SELECT `key`, `value` FROM configuration ORDER BY `key` DESC') as $element)
{
	$configuration[$element['key']] = $element['value'];
}

fw::set_config(array
(
	'dimensions'	=>	$configuration['dimensions'],
	'file_limit'	=>	$configuration['file_limit'],
	'upload_limit' 	=>	$configuration['upload_limit']	
));

$extensions = array('image/jpeg'=>'jpg', 'image/png'=>'png', 'image/gif'=>'gif', 'image/wbmp'=>'wbmp');

$dimensions = explode('x', fw::config('dimensions'));
$max_width = (int) $dimensions[0];
$max_height = (int) $dimensions[1];

// Upload
function upload($id, $mime, $size, $title)
{
	global $extensions;
	
	$id = $id;
	
	if(strlen($id) == 13 && db::count('upload WHERE `id`=?', array($id)))
	{
		db::insert('image', array('upload_id' => $id, 'extension' => $extensions[$mime], 'size' => $size, 'title' => $title));
		
		return CWEB.'upload/original/'.db::last_id().'.'.$extensions[$mime];
	}
	
	return false;
}

// File API
if(isset($_SERVER['HTTP_ID']))
{
	// Validate
	$data = @getimagesize('php://input');
	
	if(!$data) die();
	
	if(!isset($extensions[$data['mime']])) die();
	
	$contents = file_get_contents('php://input');
	
	$size = strlen($contents);
	
	if($size > fw::config('file_limit')*1024) die();
	
	if($max_width || $max_height)
	{
		list($width, $height) = getimagesize('php://input');
		
		if(($max_width && $width > $max_width) || ($max_height && $height > $max_height)) die();
	}
	
	// Upload
	if($path = upload($_SERVER['HTTP_ID'], $data['mime'], $size, isset($_SERVER['HTTP_TITLE'])?$_SERVER['HTTP_TITLE']:''))
	{
		file_put_contents($path, $contents);
	}
} else

// Web
if(isset($_POST['id']))
{
	# Validate
	$file = @fopen($_POST['url'], 'rb');
	
	if(!$file) die('0');
	
	$type = false;
	$size = false;
	
	$headers = stream_get_meta_data($file);
	
	foreach($headers['wrapper_data'] as $header)
	{
		if(!$type && substr($header, 0, 12) == 'Content-Type') $type = substr($header, 14);
		if(!$size && substr($header, 0, 14) == 'Content-Length') $size = (int) substr($header, 16);
		
		if($type && $size) break;
	}
	
	if(!$type || !$size) die('0');
	
	if(!isset($extensions[$type])) die('1');
	if($size > fw::config('file_limit')*1024) die('2');
	
	if($max_width || $max_height)
	{
		list($width, $height) = getimagesize($_POST['url']);
		
		if(($max_width && $width > $max_width) || ($max_height && $height > $max_height)) die('4');
	}
	
	// Upload
	if($path = upload($_POST['id'], $type, $size, isset($_POST['title'])?$_POST['title']:''))
	{
		file_put_contents($path, stream_get_contents($file));
	} else
	{
		echo ' '.$size;
	}
} else

// Iframe
if(isset($_GET['id']))
{
	// Validate
	if(!isset($_FILES['image'])) die('2');
	
	$file = $_FILES['image'];
	
	if($file['error'] == 1 || $file['size'] > fw::config('file_limit')*1024) die('2');
	if($file['error'] || !isset($extensions[$file['type']])) die('1');
	
	if($max_width || $max_height)
	{
		list($width, $height) = getimagesize($file['tmp_name']);
		
		if(($max_width && $width > $max_width) || ($max_height && $height > $max_height)) die('4');
	}
	
	// Upload
	if($path = upload($_GET['id'], $file['type'], $file['size'], $file['name']))
	{
		move_uploaded_file($file['tmp_name'], $path);
	} else
	{
		echo ' '.$file['size'];
	}
}