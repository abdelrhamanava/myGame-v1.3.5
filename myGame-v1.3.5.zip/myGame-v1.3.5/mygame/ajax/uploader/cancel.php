<?php
$_GET['request'] = '';

require('../../fw/main.php');
require(CWEB.'fw/mysql.php');
require(CWEB.'config/db.php');

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

$id = $_GET['id'];

if(strlen($id) != 13) exit();

db::query('DELETE FROM `upload` WHERE `id`=?', array($id));

foreach(db::query("SELECT * FROM `image` WHERE `upload_id`=?", array($id)) as $image)
{
	db::query("DELETE FROM `image` WHERE id=?", array($image['id']));
	
	unlink(CWEB.'upload/original/'.$image['id'].'.'.$image['extension']);
}