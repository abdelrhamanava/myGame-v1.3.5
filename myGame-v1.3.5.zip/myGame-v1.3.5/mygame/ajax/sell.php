<?php 
$_GET['request'] = '';

require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'/fw/user.php';

fw::lang(array('main'));

$errors = array();

if(is_numeric($_GET['id']) && is_numeric($_GET['price']))
{	
	$item_entry = db::query("SELECT * FROM items WHERE user = ? AND id = ?", array(user::data('id'), $_GET['id']))->fetch();
	$item = db::query("SELECT * FROM items_".$item_entry['category']." WHERE id = ?", array($item_entry['item']))->fetch();
	
	if(user::data('room')) $errors[] = 'You are not allowed to be in a room to do this.';
	if($_GET['price'] > $item['price']) $errors[] = 'e_selling_price';
	if($_GET['price'] <= 0) $errors[] = 'e_price_negative';
	
	if(empty($errors) && $item['id'])
	{
		db::insert('market', array('user' => user::data('id'), 'duration' => $item_entry['duration'], 'time' => time(), 'item' => $item['id'], 'category' => $item_entry['category'], 'price' => $_GET['price']));
		db::query("DELETE FROM items WHERE user = ? AND id = ?", array(user::data('id'), $item_entry['id']));
		
		user::badge('items_market', 1);
				
		$echo = lang('item_put_to_market', array('item' => $item['name'], 'price' => format_numbers($item['price'])));
	}
}

if(!empty($errors))
{
	echo '<div class="errors">';
	
	foreach($errors as $error)
	{
		echo '<span>'.lang($error).'</span>';
	}
	
	echo '</div>';
} else
{
	echo '<div class="success">'.$echo.'</div>';
}