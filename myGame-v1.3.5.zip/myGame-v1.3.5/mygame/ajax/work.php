<?php 
$_GET['request'] = '';

require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'/fw/user.php';
require_once CWEB.'config/main.php';

fw::lang(array('main'));

if(is_numeric($_GET['answer']))
{	
	if($_GET['answer'] == user::data('work_calculation') && user::data('stamina') > 0 && user::data('health') > 0 && time()-user::data('working') > fw::config('working_time')*60 && !user::data('working_payment'))
	{
		db::query("UPDATE users SET working = ?, working_payment = 1, stamina = stamina - 1 WHERE id = ?", array(time(), user::data('id')));
		
		echo 1;
	} else if(user::data('stamina') <= 0)
	{
		echo lang('You do not have enough stamina!');
	} else if(user::data('health') <= 0)
	{ 
		echo lang('You do not have enough health!');
	} else
	{
		$calculations = array('*', '-', '+', '/');

		$number_1 = mt_rand(4, 9);
		$number_2 = mt_rand(1, 4);

		$action = $calculations[mt_rand(0, 3)];

		switch($number_1)
		{
			case 0:
				$number_1_word = 'zero';
			break;
			
			case 1: 
				$number_1_word = 'one';
			break;
			
			case 2:
				$number_1_word = 'two';
			break;
			
			case 3:
				$number_1_word = 'three';
			break;
			
			case 4:
				$number_1_word = 'four';
			break;
			
			case 5:
				$number_1_word = 'five';
			break;
			
			case 6:
				$number_1_word = 'six';
			break;
			
			case 7:
				$number_1_word = 'seven';
			break;
			
			case 8:
				$number_1_word = 'eight';
			break;
			
			case 9:
				$number_1_word = 'nine';
			break;
		}

		switch($number_2)
		{
			case 0:
				$number_2_word = 'zero';
			break;
			
			case 1: 
				$number_2_word = 'one';
			break;
			
			case 2:
				$number_2_word = 'two';
			break;
			
			case 3:
				$number_2_word = 'three';
			break;
			
			case 4:
				$number_2_word = 'four';
			break;
			
			case 5:
				$number_2_word = 'five';
			break;
			
			case 6:
				$number_2_word = 'six';
			break;
			
			case 7:
				$number_2_word = 'seven';
			break;
			
			case 8:
				$number_2_word = 'eight';
			break;
			
			case 9:
				$number_2_word = 'nine';
			break;
		}

		switch($action)
		{
			case '*':
				$action_word = 'times';
				$answer = $number_1*$number_2;
			break;
			
			case '-':
				$action_word = 'minus';
				$answer = $number_1-$number_2;
			break;
			
			case '+':
				$action_word = 'plus';
				$answer = $number_1+$number_2;
			break;
			
			case '/':
				$action_word = 'divided by';
				$answer = $number_1/$number_2;
			break;
		}

		foreach($calculations as $action)
		{	
			$calculation[] = lang($number_1_word).' '.lang($action_word).' '.lang($number_2_word);
		}

		$calculation = $calculation[mt_rand(0, 3)];
	
		db::query("UPDATE users SET work_calculation = ? WHERE id = ?", array($answer, user::data('id')));		
		
		echo lang('what_is').' '.$calculation.'?';
	}
}