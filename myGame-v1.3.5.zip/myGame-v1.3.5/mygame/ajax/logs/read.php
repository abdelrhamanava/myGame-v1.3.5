<?php 
if(is_numeric($_GET['id']))
{
	$log = $_GET['id'];
	
	if(file_exists('../../temp/logs/'.$log.'.temp'))
	{
		$posts = explode('|NM|', file_get_contents('../../temp/logs/'.$log.'.temp'));
					
		$i = 0;
		foreach(array_reverse($posts) as $post)
		{
			$i++;
		
			if($i <= 5)
			{
				echo '<p>'.$post.'</p>';
			}
		}
	}
}