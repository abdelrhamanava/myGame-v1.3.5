<?php 
if(is_numeric($_GET['id']))
{
	$log = $_GET['id'];
	
	if(file_exists('../../temp/logs/'.$log.'.temp'))
	{
		clearstatcache();
		echo filemtime('../../temp/logs/'.$_GET['id'].'.temp');
	}
}