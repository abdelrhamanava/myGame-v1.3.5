<?php 
$_GET['request'] = '';

require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'config/main.php';
require_once CWEB.'/fw/user.php';

fw::lang(array('main'));

if(time()-user::data('working') <= fw::config('working_time')*60)
{	
	$remaining = (fw::config('working_time')*60)-(time()-user::data('working'));
	
	$minutes = floor($remaining/60);
	$seconds = $remaining-($minutes*60);

	echo '<span id="time"><span class="minutes">'.$minutes.'</span> '.lang('minutes').' <span class="seconds">'.$seconds.'</span> '.lang('seconds').' '.lang('remaining').'</span>';
	echo '<span style="display: none;" id="done">'.lang('working_done').'</span>';
}