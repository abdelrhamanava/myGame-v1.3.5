<?php
// Framework
require 'fw/main.php';
require 'fw/mysql.php';
require 'fw/form.php';

// Installation
if(!file_get_contents(CWEB.'config/db.php'))
{
	require CWEB.'controller/install.php';
} else
{
	require CWEB.'config/db.php';
}

// Connection
db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Configuration
require 'config/main.php';

require 'fw/user.php';
require 'fw/profile.php';
require 'fw/images.php';

// Language
if(isset($_GET['lang'])) 
{
	if($_GET['lang'] && strlen($_GET['lang']) == 2)
	{
		$lang = $_GET['lang'];
		
		if(!is_dir(CWEB.'lang/'.$lang)) $lang = fw::config('lang');
		
		set_cookie('lang', $lang, 366);
	}
}

// Menu
fw::set_menu(array(
	'not_available' => 'main/not_available',
	
	'0' => 'home',
	'home'	=>	'home',
	
	'contact'	=>	'contact',
	'about'	=>	'about',
	'profile' => 'profile',
	'leaderboard' => 'leaderboard',
	'reminder' => 'reminder',
	'online' => 'online',
	'group' => 'game/groups/group',	
));

if(user::online())
{
	if(!db::count("players WHERE user = ? AND finished = 0 AND game_over = 0", array(user::data('id'))))
	{
		// Public menu
		fw::set_menu(array(		
			'0' => 'game/home',
			'home'	=>	'game/home',
			
			'store' => 'game/store',
			'items' => 'game/items',
			
			'rooms' => 'game/rooms/rooms',
			'create_room' => 'game/rooms/create',
			'room' => 'game/rooms/game',

			'recover' => 'game/recover',	
			'market'	=>	'game/market',

			'messages' => 'user/messages',
			'sent_messages' => 'user/sent_messages',
			'send_message' => 'user/send_message',
			'message' => 'user/message',
			
			'settings' => 'user/settings',
			'password' => 'user/password',
			
			'services' => 'services',	
		));
		
		if(fw::config('work'))
		{
			fw::set_menu(array(		
				'work' => 'work'
			));
		}
		
		if(fw::config('quests'))
		{
			fw::set_menu(array(		
				'quests' => 'quests'
			));
		}		
		
		if(fw::config('allow_groups'))
		{
			fw::set_menu(array(		
				'create_group' => 'game/groups/create',
				'edit_group' => 'game/groups/edit',	
				'groups' => 'game/groups/groups',
			));
		}				
		
	} else 
	{
		// In fight menu
		fw::set_menu(array(		
			'room' => 'game/rooms/game',
			'not_available' => 'game/rooms/game',
			
			'0' => 'game/rooms/game',
			'home' => 'game/rooms/game',
		));	
	}
	
	if(user::data('admin') == 1)
	{
		// Admin menu
		fw::set_menu(array(
			'a_home'		=>	'administration/administration',

			'a_view_users'		=>	'administration/view_users',	
			'a_edit_users'		=>	'administration/edit_users',

			'a_view_items'	=>	'administration/view_items',	
			'a_add_item'	=>	'administration/add_item',
			'a_edit_item'	=>	'administration/edit_item',

			'a_add_badge'		=>	'administration/add_badge',
			'a_view_badges'		=>	'administration/view_badges',
			'a_edit_badge'	=>	'administration/edit_badge',

			'a_add_quest'		=>	'administration/add_quest',
			'a_view_quests'		=>	'administration/view_quests',			
			
			'a_add_users'		=>	'administration/add_users',	
			'a_view_users'		=>	'administration/view_users',	
			'a_edit_users'		=>	'administration/edit_users',
			
			'a_add_service'		=>	'administration/add_service',	
			'a_view_services'		=>	'administration/view_services',		

			'a_set_sms'		=>	'administration/set_sms',	
			'a_view_sms'		=>	'administration/view_sms',	

			'a_add_news'		=>	'administration/add_news',							
			'a_view_news'		=>	'administration/view_news',										
		));
	}
}

fw::check_menu();

// User hijacking
user::authentication();

if(!user::online())
{
	require CWEB.'fw/authentication.php';

	authentication::register();
	authentication::login();
	authentication::password_recovery();
}

// Contents
fw::set_contents(array(
	'Jquery'	=>	array('location' => 'jquery', 'type' => 'js'),
	'Jquery UI'	=>	array('location' => 'jquery-ui', 'type' => 'js'),
	'Popup'	=>	array('location' => 'popup', 'type' => 'js'),			
	'Main'	=>	array('location' => 'main', 'type' => 'js'),	
	'Chat'	=>	array('location' => 'chat', 'type' => 'js'),	
	'Game'	=>	array('location' => 'game', 'type' => 'js'),
	
	'Html'	=>	array('location' => fw::route(0), 'type' => 'html'),
	'Php'	=>	array('location' => fw::route(0), 'type' => 'php')
));

fw::lang(array('main', fw::$pages[fw::route(0)]));

fw::script_var('LANG_LEVEL', lang('e_level'));
fw::script_var('LANG_WORK_STARTED', lang('work_started'));

foreach(fw::$php as $controller) 
{
	require $controller;
}

// Exit
if(isset($_GET['exit']))
{
	user::leave(); 
	go('home');
}

// Search
if(isset($_POST['search']))
{
	go(fw::route(0).'/'.fw::route(1).'/'.fw::route(2).'/'.fw::route(3).'/'.urlencode($_POST['tag']));
}

// Working count
if(time()-user::data('working') <= fw::config('working_time')*60 && time()-user::data('working') > 0)
{
	fw::script_line('
		$(function(){
			Work.start();
		});
	');
}

// Quest count
if(user::data('quest') && user::data('quest_count') > time())
{
	fw::script_line('
		$(function(){
			Quest.count();
		});
	');
}

if(db::count("players WHERE user = ? AND finished = 0 AND game_over = 0", array(user::data('id'))) && fw::route(0) != 'room')
{
	if(db::count("players WHERE user = ? AND room = 0", array(user::data('id')))) db::query("DELETE FROM players WHERE user = ?", array(user::data('id')));

	go('room/'.user::data('room'));
}

require CWEB.'view/layout.html';
