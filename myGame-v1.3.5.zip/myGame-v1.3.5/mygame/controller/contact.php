<?php
// Content
$contact = new form;
$contact->create(array(
			'subject' => array(
				'class' => 'input',
				'input' => 'long_text',
				'type' => 'text',
				'name' => 'subject',
				'max_length' => '30',
				'value' => ''
			),
			
			'mail' => array(
				'class' => 'input',
				'input' => 'long_text',
				'type' => 'text',
				'name' => 'mail',
				'max_length' => '100', 
				'value' => ''
			),
			
			'message' => array(
				'class' => 'textarea',
				'type' => 'text',
				'name' => 'message',
				'input' => 'long_text',
				'max_length' => '3000',
				'value' => ''
			)
		), 'send', fw::route(0));
		
if($contact->submitted)
{
		if(!preg_match('/^\S+@\S+\.\S+$/', $_POST['mail'])) $contact->error[] = 'e_invalid_email';
		
		if(get_cookie('mail_count')) $contact->error[] = 'e_mail_spam';
		
		if(!$contact->error)
		{
			$header = '';
			$header .= "Reply-To:".$_POST['mail']." <".$_POST['mail'].">\r\n"; 
			$header .= "Return-Path: ".$_POST['mail']." <".$_POST['mail'].">\r\n"; 
			$header .= "From: ".$_POST['mail']." <".$_POST['mail'].">\r\n"; 	  

			mail(fw::config('mail'), $_POST['subject'], $_POST['message'], $header);
			
			set_cookie('mail_count', 1, 1);
			
			$contact->success = 'mail_sent';
		}
}