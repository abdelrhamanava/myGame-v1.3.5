<?php
foreach(db::query('SELECT `key`, `value` FROM configuration ORDER BY `key` DESC') as $element)
{
	$configuration[$element['key']] = $element['value'];
}

$total = db::count("news");
$show = 5;

$begin = fw::route(1)*$show;

if(!isset($begin) 
	|| $begin == 'index' 
	|| !is_numeric($begin)
) $begin = 0;

$current = fw::route(1);

if(!isset($current) 
	|| $current == 0
	|| !is_numeric($begin)
) $current = 0;
