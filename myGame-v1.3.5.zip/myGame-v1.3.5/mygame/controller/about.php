<?php
foreach(db::query('SELECT `key`, `value` FROM configuration ORDER BY `key` DESC') as $element)
{
	$configuration[$element['key']] = $element['value'];
}
