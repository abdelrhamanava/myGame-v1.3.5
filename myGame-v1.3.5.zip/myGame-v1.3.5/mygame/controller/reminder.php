<?php
// Content
$value = '';
$mail = '';

if(fw::route(1) && fw::route(2))
{
	$value = fw::route(1);
	$mail = fw::route(2);
}

$password = new form;
$password->create(array(
		'mail' => array('class' => 'input', 'type' => 'text', 'name' => 'mail', 'input' => 'long_text', 'max_length' => '100', 'value' => $mail),
		'code' => array('class' => 'input', 'type' => 'text', 'name' => 'code', 'input' => 'long_text', 'max_length' => '100', 'value' => $value),

		'new_password' => array('class' => 'input', 'type' => 'password', 'input' => 'long_text', 'voluntary' => 1, 'name' => 'new_pw'),
		'repeat_new_password' => array('class' => 'input', 'type' => 'password', 'voluntary' => 1, 'input' => 'long_text', 'name' => 'repeat_pw'),

		), 'change_pw', fw::route(0));
		
if($password->submitted)
{
	if(!db::count("users WHERE password_request = ? AND ".time()."-password_request_time < 86400 AND email = ?", array($_POST['code'], $_POST['mail']))) $password->error[] = 'e_invalid_code';	
	
	if($_POST['new_pw'] != $_POST['repeat_pw']) $password->error[] = 'e_password_match';
	
	if(strlen($_POST['new_pw']) < 6) $register->error['new_pw'] = 'e_password_length';
	if(ctype_alpha($_POST['new_pw'])) $register->error['new_pw'] = 'e_password_alpha';
	if(strtolower($_POST['new_pw']) == $_POST['new_pw']) $register->error['password'] = 'e_password_all_lowercase';	
	
	if(!$password->error)
	{
		$user = db::query("SELECT * FROM users WHERE password_request = ? AND email = ?", array($_POST['code'], $_POST['mail']))->fetch();
		
		db::query("UPDATE users SET password = ? WHERE id = ?", array(md5($_POST['new_pw'].SECRET1), $user['id']));
	
		$password->success = 'password_set';
	}
}