<?php
// User list
$show = 25;

$begin = fw::route(2)*$show;
if(!isset($begin) || $begin == 0 || !is_numeric($begin)) $begin = 0;

$current = fw::route(2);
if(!isset($current) || $current == 0|| !is_numeric($current)) $current = 0;

$category = 'level';
$type = 'users';

switch(fw::route(1))
{
	case 'level': $category = 'level'; break;
	case 'money': $category = 'money'; break;
	case 'reputation': $category = 'reputation'; break;
	case 'winratio': $category = 'win_ratio'; break;
	case 'groups': $category = 'level'; $type = 'groups'; break;	
}

$total = db::count($type." WHERE ".$category." > 0");