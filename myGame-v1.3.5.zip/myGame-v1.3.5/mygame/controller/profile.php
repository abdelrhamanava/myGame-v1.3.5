<?php
// Content
if(is_numeric(fw::route(1)))
{
	$user = db::query("SELECT * FROM users WHERE id = ?", array(fw::route(1)))->fetch();
}

if(user::data('admin') && !empty($user))
{
	// Ban
	$ban = new form;
	$ban->create(array(
			'time' => array(
				'class' => 'input',
				'type' => 'text',
				'name' => 'time',
				'input' => 'numbers',
				'max_length' => '100'
			),
			
			'reason' => array(
				'class' => 'input',
				'type' => 'text',
				'name' => 'reason',
				'input' => 'long_text',
				'max_length' => '300'
			),

		), 'ban', fw::route(0).'/'.fw::route(1));
		
	if($ban->submitted)
	{
		fw::script_line('
			$(function(){
				User.ban();
			});
		');

		if($user['admin']) $ban->error[] = 'e_admin_user';
		
		if(empty($ban->error))
		{			
			db::query("UPDATE users SET ban = ?, ban_reason = ? WHERE id = ?", array(time()+($_POST['time']*86400), $_POST['reason'], $user['id']));
			db::insert("admin_logs", array('time' => time(), 'period' => $_POST['time'], 'user' => user::data('id'), 'type' => 'ban', 'reason' => $_POST['reason'], 'target' => $user['id']));
		
			$ban->success = 'user_banned';
			
			$user['ban'] = time()+($_POST['time']*86400);
		}
	}	
	
	// Unban
	if(!empty($_GET['unban']) && $user['ban'] >= time())
	{
		db::query("UPDATE users SET ban = 0, ban_reason = ? WHERE id = ?", array('', $user['id']));
		db::insert("admin_logs", array('time' => time(), 'period' => 0, 'user' => user::data('id'), 'type' => 'unban', 'target' => $user['id']));
		
		$user['ban'] = 0;
	}
	
	// Mute
	$mute = new form;
	$mute->create(array(
			'time' => array(
				'class' => 'input',
				'type' => 'text',
				'name' => 'time',
				'input' => 'numbers',
				'max_length' => '100'
			),
			
			'reason' => array(
				'class' => 'input',
				'type' => 'text',
				'name' => 'reason',
				'input' => 'long_text',
				'max_length' => '300'
			),

		), 'mute', fw::route(0).'/'.fw::route(1));
			
	if($mute->submitted)
	{
		fw::script_line('
			$(function(){
				User.mute();
			});
		');
		
		if($user['admin']) $mute->error[] = 'e_admin_user';
		
		if(empty($mute->error))
		{			
			db::query("UPDATE users SET mute = ?, mute_reason = ? WHERE id = ?", array(time()+($_POST['time']*86400), $_POST['reason'], $user['id']));
			db::insert("admin_logs", array('time' => time(), 'period' => $_POST['time'], 'user' => user::data('id'), 'type' => 'mute', 'reason' => $_POST['reason'], 'target' => $user['id']));
		
			$mute->success = 'user_muted';
			
			$user['mute'] = time()+($_POST['time']*86400);			
		}
	}	

	// Unban
	if(!empty($_GET['unmute']) && $user['mute'] >= time())
	{
		db::query("UPDATE users SET mute = 0, mute_reason = ? WHERE id = ?", array('', $user['id']));
		db::insert("admin_logs", array('time' => time(), 'period' => 0, 'user' => user::data('id'), 'type' => 'unmute', 'target' => $user['id']));
		
		$user['mute'] = 0;
	}	
}