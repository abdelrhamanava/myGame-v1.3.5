<?php
// Fortumo API
fw::set_config(array(
	'head'	=>	fw::config('head').'<script src="http://fortumo.com/javascripts/fortumopay.js" type="text/javascript"></script>',
));

// Use a service
if(is_numeric(fw::route(1)) && fw::route(1))
{
	$order = db::query("SELECT * FROM services WHERE id = ? AND visible = 1", array(fw::route(1)))->fetch();
	
	if(empty($order)) $error[] = 'e_service';
	if(user::data('credit') < $order['price']) $error[] = 'e_credit';
	
	if(empty($error))
	{
		if($order['type'] == 'money')
		{
			user::money($order['amount']);
			db::query("UPDATE users SET credit = credit - ? WHERE id = ?", array($order['price'], user::data('id')));
		}
		
		if($order['type'] == 'level')
		{
			db::query("UPDATE users SET level = level + ?, points = points + ?, credit = credit - ? WHERE id = ?", array($order['amount'], fw::config('earning_points'), $order['price'], user::data('id')));
		}
		
		if($order['type'] == 'stamina')
		{
			db::query("UPDATE users SET stamina = max_stamina, credit = credit - ? WHERE id = ?", array($order['price'], user::data('id')));
		}	

		if($order['type'] == 'health')
		{
			db::query("UPDATE users SET health = max_health, credit = credit - ? WHERE id = ?", array($order['price'], user::data('id')));
		}				
	}
}