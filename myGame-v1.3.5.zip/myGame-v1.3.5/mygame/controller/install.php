<?php
fw::set_config(array(
	'title'		=>	'Setup',
	'style' 	=>	'administration'
));

$install = new form;
$install->create(array(
	'Database host' => array(
		'class' => 'input',
		'type' => 'text',
		'name' => 'host',
		'max_length' => '50'
	),

	'Database user' => array(
		'class' => 'input',
		'type' => 'text',
		'name' => 'user',
		'max_length' => '30'
	),

	'Database user password' => array(
		'class' => 'input',
		'type' => 'password',
		'name' => 'pass'
	),

	'Database name' => array(
		'class' => 'input',
		'type' => 'text',
		'name' => 'database'
	),

), 'Install', fw::route(0));

@chmod(CWEB."config/db.php", 0777);		
		
if(!is_writable(CWEB.'config'))
{
	die('
		Please make the <strong>db</strong> file in directory <strong>config</strong> in the main application directory writable for PHP (chmod to 755) 
		to continue with the installation of the system.<br/>
		You may reset the folder\'s permissions after completing the installation.
	');
		
	exit();
}

if($install->submitted)
{
	# Database
	$adapter = 'mysql';
	$host = $_POST['host'];
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	$database = $_POST['database'];
		
	if(empty($user)) $install->error[] = 'Please enter a username.';
	if(empty($database)) $install->error[] = 'Please enter the name of a database.';
	
	if(empty($host))
	{
		$install->error[] = 'Please enter a host.';
	} else if(!count($install->error))
	{
		try {
			$dbh = @new PDO('mysql:host='.$host.';dbname='.$database, $user, $pass);
			$dbh = null;
		} catch (PDOException $e) {
			$error = explode('[', $e->getMessage());
			$error = explode(']', $error[2]);
		}
		
		if($error[0] != '1049' && $error[0]) $install->error[] = 'User can not access database';
		if($error[0] == '2002') $install->error[] = 'Unable to connect host address';
	}
		
	# Install
	if(!count($install->error))
	{		
		try {
			$dbh = new PDO("mysql:host=$host", $user, $pass);

			$dbh->exec("
					CREATE DATABASE IF NOT EXISTS `$database`;
					GRANT ALL ON `$database`.* TO '$user'@'$host';
					FLUSH PRIVILEGES;
					");
			
			$db = new PDO("mysql:host=".$host.";dbname=".$database, $user, $pass);			
			
			$db->exec("
				CREATE TABLE IF NOT EXISTS `admin_logs` (
				  `id` int(11) NOT NULL auto_increment,
				  `type` text NOT NULL,
				  `target` int(11) NOT NULL,
				  `period` int(11) NOT NULL,
				  `reason` text NOT NULL,
				  `user` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `badges` (
				  `id` int(11) NOT NULL auto_increment,
				  `title` text NOT NULL,
				  `type` text NOT NULL,
				  `count` int(11) NOT NULL,
				  `reputation` int(11) NOT NULL,
				  `period` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

				CREATE TABLE IF NOT EXISTS `badge_cache` (
				  `id` int(11) NOT NULL auto_increment,
				  `type` text NOT NULL,
				  `user` int(11) NOT NULL,
				  `amount` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `configuration` (
				  `key` tinytext NOT NULL,
				  `value` text NOT NULL
				) ENGINE=MyISAM DEFAULT CHARSET=latin1;

				CREATE TABLE IF NOT EXISTS `groups` (
				  `id` int(11) NOT NULL auto_increment,
				  `name` text NOT NULL,
				  `description` text NOT NULL,
				  `user` int(11) NOT NULL,
				  `exp` int(11) NOT NULL,
				  `level` int(11) NOT NULL default '1',
				  `points` int(11) NOT NULL default '1',
				  `attack` int(11) NOT NULL,
				  `defense` int(11) NOT NULL,
				  `endurance` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `group_applicants` (
				  `id` int(11) NOT NULL auto_increment,
				  `group` int(11) NOT NULL,
				  `user` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `group_members` (
				  `id` int(11) NOT NULL auto_increment,
				  `user` int(11) NOT NULL,
				  `group` int(11) NOT NULL,
				  `exp` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `image` (
				  `id` int(10) unsigned NOT NULL auto_increment,
				  `upload_id` char(13) default NULL,
				  `title` varchar(25) default NULL,
				  `description` varchar(255) default NULL,
				  `extension` enum('jpg','png','gif','wbmp') default NULL,
				  `size` int(10) unsigned default NULL,
				  `views` int(10) unsigned default NULL,
				  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
				  `user` int(10) unsigned default NULL,
				  `private` tinyint(1) unsigned default NULL,
				  `thumb` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `items` (
				  `id` int(11) NOT NULL auto_increment,
				  `item` int(11) NOT NULL,
				  `category` text NOT NULL,
				  `user` int(11) NOT NULL,
				  `equip` int(11) NOT NULL,
				  `duration` int(11) NOT NULL default '100',
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `items_defense` (
				  `id` bigint(20) NOT NULL auto_increment,
				  `price` int(11) NOT NULL,
				  `name` text NOT NULL,
				  `effect` float NOT NULL,
				  `level` int(11) NOT NULL,
				  `special` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

				CREATE TABLE IF NOT EXISTS `items_extra` (
				  `id` float NOT NULL auto_increment,
				  `name` text NOT NULL,
				  `price` int(11) NOT NULL,
				  `level` int(11) NOT NULL,
				  `effect` int(11) NOT NULL,
				  `special` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

				CREATE TABLE IF NOT EXISTS `items_special` (
				  `id` int(11) NOT NULL auto_increment,
				  `name` text NOT NULL,
				  `effect` float NOT NULL,
				  `level` int(11) NOT NULL,
				  `price` int(11) NOT NULL,
				  `type` text NOT NULL,
				  `special` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

				CREATE TABLE IF NOT EXISTS `items_weapons` (
				  `id` bigint(20) NOT NULL auto_increment,
				  `name` text NOT NULL,
				  `price` int(11) NOT NULL,
				  `level` int(11) NOT NULL,
				  `effect` int(11) NOT NULL,
				  `special` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

				CREATE TABLE IF NOT EXISTS `logins` (
				  `id` int(11) NOT NULL auto_increment,
				  `user` int(11) NOT NULL,
				  `ip` text NOT NULL,
				  `time` int(11) NOT NULL,
				  `browser` text NOT NULL,
				  `lang` text NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `logs` (
				  `id` int(11) NOT NULL auto_increment,
				  `user` int(11) NOT NULL,
				  `content` text NOT NULL,
				  `time` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `market` (
				  `id` int(11) NOT NULL auto_increment,
				  `item` int(11) NOT NULL,
				  `user` int(11) NOT NULL,
				  `price` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  `category` text NOT NULL,
				  `duration` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `messages` (
				  `id` int(11) NOT NULL auto_increment,
				  `subject` text NOT NULL,
				  `message` text NOT NULL,
				  `user` int(11) NOT NULL,
				  `sender` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  `status` int(11) NOT NULL,
				  `type` tinytext NOT NULL,
				  `type_id` int(11) NOT NULL,
				  `time_read` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `news` (
				  `id` int(11) NOT NULL auto_increment,
				  `title` text NOT NULL,
				  `content` text NOT NULL,
				  `time` int(11) NOT NULL,
				  `user` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `players` (
				  `id` int(11) NOT NULL auto_increment,
				  `room` int(11) NOT NULL,
				  `user` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  `seat` int(11) NOT NULL,
				  `ready` int(11) NOT NULL,
				  `finished` int(11) NOT NULL,
				  `game_over` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `quests` (
				  `id` int(11) NOT NULL auto_increment,
				  `title` text NOT NULL,
				  `experience_gained` double NOT NULL,
				  `money_gained` int(11) NOT NULL,
				  `count` int(11) NOT NULL,
				  `completion_time` int(11) NOT NULL,
				  `resource` text NOT NULL,
				  `resource_amount` int(11) NOT NULL,
				  `level_required` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

				CREATE TABLE IF NOT EXISTS `quest_log` (
				  `id` int(11) NOT NULL auto_increment,
				  `user` int(11) NOT NULL,
				  `quest` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `rooms` (
				  `id` int(11) NOT NULL auto_increment,
				  `name` text NOT NULL,
				  `user` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  `seats` int(11) NOT NULL,
				  `active` int(11) NOT NULL,
				  `finished` int(11) NOT NULL,
				  `type` text NOT NULL,
				  `bet` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `services` (
				  `id` int(11) NOT NULL auto_increment,
				  `type` text NOT NULL,
				  `amount` int(11) NOT NULL,
				  `price` int(11) NOT NULL,
				  `name` text NOT NULL,
				  `visible` int(11) NOT NULL default '1',
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

				CREATE TABLE IF NOT EXISTS `sms` (
				  `id` int(11) NOT NULL auto_increment,
				  `number` text NOT NULL,
				  `user` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  `amount` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `spam_control` (
				  `id` int(11) NOT NULL auto_increment,
				  `time` int(11) NOT NULL,
				  `ip` text NOT NULL,
				  `type` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `upload` (
				  `id` char(13) NOT NULL default '',
				  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM DEFAULT CHARSET=latin1;

				CREATE TABLE IF NOT EXISTS `users` (
				  `id` int(11) NOT NULL auto_increment,
				  `time` int(11) NOT NULL,
				  `username` tinytext NOT NULL,
				  `password` mediumtext NOT NULL,
				  `description` text NOT NULL,
				  `admin` tinyint(4) NOT NULL,
				  `ip` mediumtext NOT NULL,
				  `email` tinytext NOT NULL,
				  `last_active` int(11) NOT NULL,
				  `ban` int(11) NOT NULL,
				  `ban_reason` text NOT NULL,
				  `mute` int(11) NOT NULL,
				  `mute_reason` text NOT NULL,
				  `language` tinytext NOT NULL,
				  `activation_code` text NOT NULL,
				  `money` bigint(20) NOT NULL,
				  `level` int(11) NOT NULL default '1',
				  `exp` bigint(20) NOT NULL,
				  `reputation` int(11) NOT NULL default '0',
				  `health` int(11) NOT NULL default '100',
				  `max_health` int(11) NOT NULL default '100',
				  `attack` int(11) NOT NULL default '1',
				  `defense` int(11) NOT NULL default '1',
				  `endurance` int(11) NOT NULL default '1',
				  `stamina` int(11) NOT NULL default '10',
				  `max_stamina` int(11) NOT NULL default '10',
				  `room` int(11) NOT NULL,
				  `win_ratio` int(11) NOT NULL,
				  `points` int(11) NOT NULL,
				  `work_calculation` double NOT NULL,
				  `working` int(11) NOT NULL,
				  `working_payment` int(11) NOT NULL,
				  `credit` int(11) NOT NULL,
				  `password_request` text NOT NULL,
				  `password_request_time` int(11) NOT NULL,
				  `finished_quests` int(11) NOT NULL,
				  `quest` int(11) NOT NULL,
				  `quest_count` int(11) NOT NULL,
				  `money_gained_day` int(11) NOT NULL,
				  `exp_gained_day` int(11) NOT NULL,
				  `levels_gained_day` int(11) NOT NULL,
				  `cache_time` int(11) NOT NULL,
				  `group_attack` int(11) NOT NULL,
				  `group_defense` int(11) NOT NULL,
				  `group_endurance` int(11) NOT NULL,
				  PRIMARY KEY  (`id`),
				  KEY `time` (`time`),
				  KEY `time_2` (`time`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;

				CREATE TABLE IF NOT EXISTS `user_badges` (
				  `id` int(11) NOT NULL auto_increment,
				  `badge` int(11) NOT NULL,
				  `user` int(11) NOT NULL,
				  `type` text NOT NULL,
				  `count` int(11) NOT NULL,
				  `time` int(11) NOT NULL,
				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=0 ;
				
				INSERT INTO `badges` (`id`, `title`, `type`, `count`, `reputation`, `period`) VALUES
				(23, 'Finish 10 quests', 'finished_quests', 10, 10, 0),
				(22, 'Finish 3 quests', 'finished_quests', 3, 5, 0),
				(21, 'Work 25 times', 'work', 25, 10, 0),
				(20, 'Win at least 10 deathmatch battles', 'deathmatch', 10, 10, 0),
				(19, 'Own at least 3 items', 'items', 3, 5, 0),
				(18, 'Reach level 6', 'level', 6, 20, 0),
				(17, 'Reach level 3', 'level', 3, 15, 0),
				(16, 'Own at least 100 000 money', 'money', 100000, 10, 0);

				INSERT INTO `configuration` (`key`, `value`) VALUES
				('title', 'myGame'),
				('url', 'http://www.urlhere.com'),
				('mail', 'kairo.kybard@gmail.com'),
				('description', 'Make your own browser based game!'),
				('tags', 'tags,go,in,here'),
				('style', 'default'),
				('ad', ''),
				('lang', 'en'),
				('head', ''),
				('dimensions', '1920x1200'),
				('file_limit', '1048576'),
				('about', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\r\n'),
				('fortumo_api', ''),
				('sms_info', 'Ordering credit will take up to few minutes.'),
				('failed_logins', '15'),
				('interval', '60'),
				('starting_points', '5'),
				('earning_points', '3'),
				('health_cost', '1'),
				('stamina_cost', '3'),
				('starting_money', '10000'),
				('health_increase', '15'),
				('work', '1'),
				('working_time', '3'),
				('working_payment', '300'),
				('luck', '30'),
				('front_page', 'myGame is a browser based game that you can fully configure trough an administrator panel. Some of the main features in game are: turn-based fighting (up to 4 players with team deathmatch), buying items, selling items trough market & working. \r\n\r\nFor more information I advise you to look at the item documentation.\r\n\r\n[b]Features[/b]\r\nTurn based PVP fighting, up to 4 players with team deathmatch.\r\nAdding, deleting & editing items.\r\nAdding, deleting & editing badges (achievements).\r\nBan & mute users.\r\nEdit preferences like â€œTurn length in pvpâ€ etc.\r\nContact page.\r\nAbout page.\r\nEditing site information.\r\nPlayers are allowed to work for money.\r\nLeaderboard.\r\nSet up an SMS service trough Fortumo API.\r\nJavascript / AJAX features â€“ fighting, chat, fight log, buying items, selling items, equipping/unequipping items & updating character points.'),
				('rules', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\r\n'),
				('credit', '10'),
				('fortumo_secret', ''),
				('quests', '1'),
				('allow_groups', '1'),
				('group_creating_tax', '15000'),
				('group_creating_level', '1'),
				('group_exp_interest', '0.2');

				INSERT INTO `items_defense` (`id`, `price`, `name`, `effect`, `level`, `special`) VALUES
				(1, 1200, 'Gloves', 1, 1, 0),
				(2, 2500, 'Boots', 2, 2, 0),
				(3, 4000, 'Helmet', 4, 4, 0),
				(4, 5000, 'Bulletproof vest', 5, 3, 1),
				(5, 7000, 'Tactical shield', 6, 4, 1);

				INSERT INTO `items_extra` (`id`, `name`, `price`, `level`, `effect`, `special`) VALUES
				(1, 'Flashlight', 1000, 1, 1, 0),
				(2, 'Silencer', 3000, 1, 2, 1),
				(3, 'Bipod', 4000, 3, 3, 0),
				(4, 'Flashbang', 5000, 5, 5, 0),
				(5, 'Molotov coctail', 8000, 8, 8, 0);

				INSERT INTO `items_special` (`id`, `name`, `effect`, `level`, `price`, `type`, `special`) VALUES
				(1, 'Medkit', 0.1, 1, 4500, 'health', 0),
				(2, 'Adrenaline shot', 0.1, 1, 6000, 'stamina', 0);

				INSERT INTO `items_weapons` (`id`, `name`, `price`, `level`, `effect`, `special`) VALUES
				(3, 'Knife', 1200, 1, 2, 0),
				(4, 'Colt 45', 3100, 2, 4, 0),
				(5, 'Desert Eagle', 5000, 3, 6, 1),
				(6, 'MP5', 8000, 5, 8, 1),
				(7, 'Shotgun', 10000, 8, 10, 0),
				(8, 'Ninja star', 4000, 1, 3, 1),
				(9, 'Ninja sword', 6000, 3, 4, 1),
				(10, 'Uzi', 7000, 8, 10, 0);

				INSERT INTO `quests` (`id`, `title`, `experience_gained`, `money_gained`, `count`, `completion_time`, `resource`, `resource_amount`, `level_required`) VALUES
				(1, 'Quest for reputation', 25, 1000, 1, 0, 'reputation', 10, 1),
				(2, 'Experience for money', 30, 0, 1, 0, 'money', 5000, 1),
				(3, 'Quest for endurance', 20, 1000, 3, 3, 'endurance', 3, 1),
				(5, 'Complimentary attack test', 15, 2500, 1, 0, 'attack', 3, 1),
				(6, 'The defender', 10, 1000, 2, 10, 'defense', 3, 2),
				(7, 'Trade money for experience', 25, 0, 1, 3, 'money', 10000, 2),
				(8, 'Trade credit for experience', 30, 0, 1, 0, 'credit', 2, 3),
				(9, 'Win ratio quest', 25, 2500, 1, 2, 'win_ratio', 10, 4),
				(10, 'Quest for endurance', 25, 3000, 1, 0, 'endurance', 10, 5),
				(11, 'Reputation quest', 10, 0, 1, 0, 'reputation', 25, 2);

				INSERT INTO `services` (`id`, `type`, `amount`, `price`, `name`, `visible`) VALUES
				(1, 'level', 1, 5, 'Order +1 level', 1),
				(2, 'health', 0, 1, 'Order health refill', 1),
				(3, 'stamina', 0, 1, 'Order stamina refill', 1),
				(4, 'money', 10000, 3, 'Order + 10 000 money', 1);
			");							
		} catch(PDOException $e)
		{
			die("DB ERROR: ". $e->getMessage());
		}
				
		@chmod(CWEB."temp/chat", 0777);		
		@chmod(CWEB."temp/logs", 0777);		
		@chmod(CWEB."temp/players", 0777);		
		@chmod(CWEB."temp/rooms", 0777);		

		@chmod(CWEB."upload/original", 0777);		
		@chmod(CWEB."upload/avatar", 0777);		
		@chmod(CWEB."upload/group_avatar", 0777);		

		@chmod(CWEB."images/badges", 0777);		
		@chmod(CWEB."images/items/weapons", 0777);		
		@chmod(CWEB."images/items/defense", 0777);		
		@chmod(CWEB."images/items/extra", 0777);		
		@chmod(CWEB."images/items/special", 0777);		
		
		# Configuration file
		$secret_ingredients = 'abcdefghijklmnopqrstuvxyABCDEFGHIJKLMNOPQRSTUVXY1234567890';
		$secret_ingredients = str_split($secret_ingredients);
		
		$secret1 = '';
		$secret2 = '';
		$secret3 = '';
		
		for($i = 0; $i <= 15; $i++)
		{
			$secret1 .= $secret_ingredients[mt_rand(0, count($secret_ingredients))];
			$secret2 .= $secret_ingredients[mt_rand(0, count($secret_ingredients))];
			$secret3 .= $secret_ingredients[mt_rand(0, count($secret_ingredients))];
		}
		
		file_put_contents(CWEB.'config/db.php', "<?php\ndefine('DB_ADAPTER', '".$adapter."');\ndefine('DB_HOST', '".$host."');\ndefine('DB_USER', '".$user."');\ndefine('DB_PASS', '".$pass."');\ndefine('DB_NAME', '".$database."');\ndefine('SECRET1', '".$secret1."');\ndefine('SECRET2', '".$secret2."');\ndefine('SECRET3', '".$secret3."');");
		
		header('Location: '.WEB.'home');
		
		exit();
	}
}

require_once CWEB.'view/install.html';

exit();