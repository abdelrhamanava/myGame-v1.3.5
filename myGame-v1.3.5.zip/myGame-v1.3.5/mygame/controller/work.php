<?php
$calculations = array('*', '-', '+', '/');

$number_1 = mt_rand(4, 9);
$number_2 = mt_rand(1, 4);

$action = $calculations[mt_rand(0, 3)];

switch($number_1)
{
	case 0:
		$number_1_word = 'zero';
	break;
	
	case 1: 
		$number_1_word = 'one';
	break;
	
	case 2:
		$number_1_word = 'two';
	break;
	
	case 3:
		$number_1_word = 'three';
	break;
	
	case 4:
		$number_1_word = 'four';
	break;
	
	case 5:
		$number_1_word = 'five';
	break;
	
	case 6:
		$number_1_word = 'six';
	break;
	
	case 7:
		$number_1_word = 'seven';
	break;
	
	case 8:
		$number_1_word = 'eight';
	break;
	
	case 9:
		$number_1_word = 'nine';
	break;
}

switch($number_2)
{
	case 0:
		$number_2_word = 'zero';
	break;
	
	case 1: 
		$number_2_word = 'one';
	break;
	
	case 2:
		$number_2_word = 'two';
	break;
	
	case 3:
		$number_2_word = 'three';
	break;
	
	case 4:
		$number_2_word = 'four';
	break;
	
	case 5:
		$number_2_word = 'five';
	break;
	
	case 6:
		$number_2_word = 'six';
	break;
	
	case 7:
		$number_2_word = 'seven';
	break;
	
	case 8:
		$number_2_word = 'eight';
	break;
	
	case 9:
		$number_2_word = 'nine';
	break;
}

switch($action)
{
	case '*':
		$action_word = 'times';
		$answer = $number_1*$number_2;
	break;
	
	case '-':
		$action_word = 'minus';
		$answer = $number_1-$number_2;
	break;
	
	case '+':
		$action_word = 'plus';
		$answer = $number_1+$number_2;
	break;
	
	case '/':
		$action_word = 'divided by';
		$answer = $number_1/$number_2;
	break;
}

foreach($calculations as $action)
{	
	$calculation[] = lang($number_1_word).' '.lang($action_word).' '.lang($number_2_word);
}

$calculation = $calculation[mt_rand(0, 3)];

db::query("UPDATE users SET work_calculation = ? WHERE id = ?", array($answer, user::data('id')));

$amount = user::data('level')*fw::config('working_payment');

if(!empty($_GET['collect']) && user::data('working_payment') && time()-user::data('working') >= fw::config('working_time')*60)
{
	user::money($amount);
	
	user::badge('work', 1);
	
	db::query("UPDATE users SET working_payment = 0 WHERE id = ?", array(user::data('id')));
}