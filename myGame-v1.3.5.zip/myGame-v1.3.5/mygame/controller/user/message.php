<?php
$message = db::query("SELECT * FROM messages WHERE id = ? AND (user = ? OR sender = ?)", array(fw::route(1), user::data('id'), user::data('id')))->fetch();

if($message['status'] == 0 && $message['user'] == user::data('id'))
{
	db::query("UPDATE messages SET status = 1, time_read = ".time()." WHERE id = ?", array($message['id']));
}

$message = db::query("SELECT * FROM messages WHERE id = ? AND (user = ? OR sender = ?)", array(fw::route(1), user::data('id'), user::data('id')))->fetch();

fw::script_line('
	$(function(){
		$("#sidebar:first-child").remove();
	});
');