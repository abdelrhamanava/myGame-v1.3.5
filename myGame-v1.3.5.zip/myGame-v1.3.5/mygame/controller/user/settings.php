<?php
fw::set_contents(array
(
	'Uploader'	=>	array('location' => 'uploader', 'type' => 'js')
));		

$dimensions = explode('x', fw::config('dimensions'));

fw::script_var('IMG', WEB.'style/'.fw::config('style').'/image/img.png');
fw::script_var('UPLOADED', WEB.'style/'.fw::config('style').'/image/uploaded.png');
fw::script_var('LOADING', WEB.'style/'.fw::config('style').'/image/loading.gif');
fw::script_var('UPLOAD_ID', uniqid());
fw::script_var('WEB', WEB);
fw::script_var('FILE_LIMIT', (int) (fw::config('file_limit')));
fw::script_var('CONST_AMOUNT', (int) (db::count("image WHERE upload_id = ?", array(@$_POST['image']))));
fw::script_var('MAX_WIDTH', (int) $dimensions[0]);
fw::script_var('MAX_HEIGHT', (int) $dimensions[1]);
fw::script_var('UPLOAD_LIMIT', (int) fw::config('upload_limit'));
fw::script_var('info', lang('notification', array('size'=>round(fw::config('file_limit')/1024/1024, 1))));
fw::script_var('error', array
(
	lang('error_url'),
	lang('error_type'),
	lang('error_size', array('size'=>round(fw::config('file_limit')/1024/1024, 1))),
	lang('error_amount', array('amount' => fw::config('upload_limit'))),
	lang('error_dim', array('dimensions'=>fw::config('dimensions')))
));		

fw::script_line('$(function(){ $("#upload").insertBefore( $("input[name=\'image\']") ); } );');

$edit = new form;
$edit->create(array(
		'avatar' => array(
			'class' => 'header'
		),

		'image' => array(
			'class' => 'input',
			'type' => 'hidden',
			'name' => 'image',
			'voluntary' => 1
		),

		'info' => array(
			'class' => 'header'
		),

		'description' => array(
			'class' => 'textarea',
			'type' => 'bbcode',
			'input' => 'long_text',
			'name' => 'description',
			'max_length' => '1000',
			'value' => user::data('description'),
			'voluntary' => 1,
		),
		
		'email' => array(
			'class' => 'input',
			'type' => 'text',
			'input' => 'long_text',
			'name' => 'email',
			'max_length' => '25',
			'value' => user::data('email')
		),
		
	), 'edit', fw::route(0));
	
if($edit->submitted)
{			
	if(!preg_match('/^\S+@\S+\.\S+$/', $_POST['email'])) $edit->error['email'] = 'e_invalid_email';
	
	if(!$edit->error)
	{						
		if(!empty($_POST['image']))
		{			
			foreach(db::query("SELECT * FROM `image` WHERE `upload_id`=?", array($_POST['image'])) as $image)
			{
				if($image)
				{
					create_thumbnail(CWEB.'upload/original/'.$image['id'].'.'.$image['extension'], CWEB.'upload/avatar/'.user::data('id').'.png', 100, 100);
				}
			}			
		}
	
		db::query("UPDATE users SET description = ?, email=? WHERE id=?", array($_POST['description'], $_POST['email'], user::data('id')));
	}
}
