<?php
$total = db::count("messages WHERE `user`=?", array(user::data('id')));
$show = 30;

$begin = fw::route(2)*$show;
if(!isset($begin) || !is_numeric($begin)) $begin = 0;

$current = fw::route(2);
if(!isset($current) || !is_numeric($begin)) $current = 0;

$order = 'id';
switch(fw::route(1))
{
	case 'date':
		$order = 'id';
	break;
}

switch(fw::route(3))
{
	default:
		$order_type = 'DESC';
	break;
	
	case 'asc':
		$order_type = 'ASC';
	break;
}

$order_type_url = 'desc';
if(fw::route(3) == $order_type_url) $order_type_url = 'asc';