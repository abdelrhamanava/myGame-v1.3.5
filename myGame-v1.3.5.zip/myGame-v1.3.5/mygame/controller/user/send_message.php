<?php
# Set recipient attributes
$to = '';

if(is_numeric(fw::route(1)))
{
	$user = db::query("SELECT * FROM users WHERE id = ?", array(fw::route(1)))->fetch();
	
	if($user['id'])
	{
		$to = $user['username'];
	}
}

# Set reply attributes
$subject = '';

if(is_numeric(fw::route(2)))
{
	$reply = db::query("SELECT * FROM messages WHERE id = ? AND user = ?", array(fw::route(2), user::data('id')))->fetch();
	
	if(isset($reply['id']))
	{
		$subject = $reply['subject'];
	}
}

# Send message
$send = new form;
$send->create(array(
		'subject' => array('class' => 'input', 'type' => 'text', 'input' => 'long_text', 'name' => 'subject', 'max_length' => '40', 'value' => $subject),
		'username' => array('class' => 'input', 'type' => 'text', 'input' => 'long_text', 'name' => 'to', 'max_length' => '40', 'value' => $to),
		'message' => array('class' => 'textarea', 'type' => 'text', 'input' => 'long_text', 'name' => 'message', 'max_length' => '5000', 'value' => ''),
		), 'send', fw::route(0).'/'.fw::route(1));

if($send->submitted)
{
	$user = db::query("SELECT * FROM users WHERE username = ?", array($_POST['to']))->fetch();
	
	if($user['id'] == user::data('id')) $send->error[] = 'e_sender';
	if(!isset($user['id'])) $send->error[] = 'e_to';
	if(user::data('mute') > time()) $send->error[] = 'e_mute';
	
	if(!count($send->error))
	{
		db::insert("messages", array('subject' => $_POST['subject'], 'message' => $_POST['message'], 'user' => $user['id'], 'sender' => user::data('id'), 'time' => time()));
		go('sent_messages');
	}
}