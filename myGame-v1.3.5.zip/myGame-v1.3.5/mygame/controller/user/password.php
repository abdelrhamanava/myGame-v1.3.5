<?php
$password = new form;
$password->create(array(
		'current_password' => array('class' => 'input', 'type' => 'password', 'input' => 'long_text', 'name' => 'current_pw'),
		'new_password' => array('class' => 'input', 'type' => 'password', 'input' => 'long_text', 'voluntary' => 1, 'name' => 'new_pw'),
		'repeat_new_password' => array('class' => 'input', 'type' => 'password', 'voluntary' => 1, 'input' => 'long_text', 'name' => 'repeat_pw'),
		
		), 'edit', fw::route(0));
	
if($password->submitted)
{	
	if($_POST['new_pw'] && ($_POST['new_pw'] != $_POST['repeat_pw'])) $password->error['new_pw'] = 'e_password_match';
	if((md5($_POST['current_pw'].SECRET1) != user::data('password'))) $password->error['current_pw'] = 'e_current_password';
		
	if(!$password->error)
	{	
		$password = user::data('password');
		if($_POST['new_pw']) $password = md5($_POST['new_pw'].SECRET1);
		$_POST['current_pw'] = '';
			
		db::query("UPDATE users SET password=? WHERE id=?", array($password, user::data('id')));
		
		user::login(user::data('id'));
	}
}
