<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('sms_service'),
	'style' 	=>	'administration'
));

// Form
$configuration = new form;
$configuration->create(array(
			'fortumo_api' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'api',
				'value' => fw::config('fortumo_api')
			),

			'fortumo_secret' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'secret',
				'value' => fw::config('fortumo_secret')
			),			
						
			'sms_info' => array(
				'class' => 'textarea',
				'type' 	=> 'text',
				'voluntary' => 1,
				'name' 	=> 'sms_info',
				'value' => fw::$config['sms_info']
			)
						
		), 'configuration', fw::route(0));

if($configuration->submitted)
{	
	if(user::data('admin') != 1) $configuration->error[] = 'e_user_not_main_admin';
	
	if(!$configuration->error)
	{
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['api'], 'fortumo_api'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['secret'], 'fortumo_secret'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['sms_info'], 'sms_info'));
	
		$configuration->success = 'Edited';
	}
}