<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('add_news'),
	'style' 	=>	'administration'
));

// Form
$add = new form;
$add->create(array(
			'title' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'title',
				'input' => 'long_text',
			),			
						
			'content' => array(
				'class' => 'textarea',
				'type' 	=> 'bbcode',
				'name' 	=> 'content',
				'input' => 'long_text',
			)
						
		), 'add', fw::route(0));

if($add->submitted)
{	
	if(user::data('admin') != 1) $add->error[] = 'e_user_not_main_admin';
	
	if(!$add->error)
	{
		db::insert('news', array('user' => user::data('id'), 'time' => time(), 'title' => $_POST['title'], 'content' => $_POST['content']));
	
		$add->success = 'added';
	}
}