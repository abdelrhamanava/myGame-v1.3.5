<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('add_item'),
	'style' 	=>	'administration'
));

fw::set_contents(array
(
	'Uploader'	=>	array('location' => 'uploader', 'type' => 'js')
));		

$dimensions = explode('x', fw::config('dimensions'));

fw::script_var('IMG', WEB.'style/'.fw::config('style').'/image/img.png');
fw::script_var('UPLOADED', WEB.'style/'.fw::config('style').'/image/uploaded.png');
fw::script_var('LOADING', WEB.'style/'.fw::config('style').'/image/loading.gif');
fw::script_var('UPLOAD_ID', uniqid());
fw::script_var('WEB', WEB);
fw::script_var('FILE_LIMIT', (int) (fw::config('file_limit')));
fw::script_var('CONST_AMOUNT', (int) (db::count("image WHERE upload_id = ?", array(@$_POST['image']))));
fw::script_var('MAX_WIDTH', (int) $dimensions[0]);
fw::script_var('MAX_HEIGHT', (int) $dimensions[1]);
fw::script_var('UPLOAD_LIMIT', (int) fw::config('upload_limit'));
fw::script_var('info', lang('notification', array('size'=>round(fw::config('file_limit')/1024/1024, 1))));
fw::script_var('error', array
(
	lang('error_url'),
	lang('error_type'),
	lang('error_size', array('size'=>round(fw::config('file_limit')/1024/1024, 1))),
	lang('error_amount', array('amount' => fw::config('upload_limit'))),
	lang('error_dim', array('dimensions'=>fw::config('dimensions')))
));		

fw::script_line('
	function reveal()
	{
		if($("select[name=\'category\'] option:selected").attr("value") != "special")
		{
			$("select[name=\'type\']").closest("p").hide(); 
			$("select[name=\'type\']").hide(); 
		} 
		
		if($("select[name=\'category\'] option:selected").attr("value") == "special")
		{
			$("select[name=\'type\']").closest(" p ").show(); 
			$("select[name=\'type\']").show(); 
		}
	}

	$(function(){
		$("#upload").insertBefore( $("input[name=\'image\']") );

		$("select[name=\'type\']").closest("p").hide(); 		
		$("select[name=\'type\']").hide(); 
		
		reveal();
		$("form").attr("onsubmit", "reveal(); return true;");
		$("select[name=\'category\']").change(function(){ reveal(); });
	});
');

// Adding items
$add_item = new form;
$add_item->create(array(
		'image' => array(
			'class' => 'input',
			'type' => 'hidden',
			'name' => 'image',
		),

		'name'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'name',
		),

		'price'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'price',
		),				
		
		'effect'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'effect',
		),		
		
		'required_level'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'level',
			'input' => 'numbers',
			'max_length' => 50,			
		),
		
		'category' => array(
			'class' => 'select',
			'name' => 'category',
			'options' => array('weapons' => lang('weapons'), 'defense' => lang('defense'), 'extra' => lang('extra'), 'special' => lang('special')),
			'value' => 'weapons'
		),	

		'type' => array(
			'class' => 'select',
			'name' => 'type',
			'options' => array('stamina' => lang('stamina'), 'health' => lang('health'), 'experience' => lang('experience')),
			'value' => 'stamina',
			'voluntary' => 1,
		),				
		
		'special' => array(
			'class' => 'select',
			'name' => 'special',
			'options' => array(0=> lang('no'), 1 => lang('yes')),
			'value' => 0
		),		

	), 'add_item', fw::route(0));

if($add_item->submitted)
{		
	if(!$_POST['image']) $add_item->error[] = 'e_image';
	if($_POST['category'] == 'special' && !$_POST['type']) $add_item->error[] = 'e_type';
	
	if(empty($add_item->error))
	{
		$effect = $_POST['effect'];
		if($_POST['category'] == 'special')
		{
			$effect = round($_POST['effect']/100, 2);
		}
	
		$insert = array('price'=>$_POST['price'], 'name'=>$_POST['name'], 'level'=>$_POST['level'], '`effect`'=>$effect, '`special`'=>$_POST['special']);

		$type = '';
		if(!empty($_POST['type']) && $_POST['category'] == 'special')
		{
			$insert = array_merge(array('`type`' => $_POST['type']), $insert);
		}
		
		db::insert('items_'.$_POST['category'], $insert);

		// Images
		if($_POST['image'])
		{
			db::query("UPDATE `image` SET user=? WHERE `upload_id`=?", array(user::data('id'), $_POST['image']));
			
			foreach(db::query("SELECT * FROM `image` WHERE `upload_id`=?", array($_POST['image'])) as $image)
			{
				if($image)
				{
					$last_item = db::query("SELECT * FROM items_".$_POST['category']." ORDER BY id DESC LIMIT 1")->fetch();
					
					create_thumbnail(CWEB.'upload/original/'.$image['id'].'.'.$image['extension'], CWEB.'images/items/'.$_POST['category'].'/'.($last_item['id']).'.jpg', 50, 50);
				}
			}
		}		
		
		$add_item->success = 'item_has_been_added';
	}
}
