<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('edit_item'),
	'style' 	=>	'administration'
));

if(is_numeric(fw::route(1)) && fw::route(2))
{
	$item = db::query("SELECT * FROM items_".fw::route(2)." WHERE id = ?", array(fw::route(1)))->fetch();
}

if(!empty($item))
{
	// Adding items
	$edit_item = new form;
	$edit_item->create(array(
			'name'	=> array(
				'class'=>'input',
				'type'=>'text',
				'name'=>'name',
				'value'=>$item['name']
			),

			'price'	=> array(
				'class'=>'input',
				'type'=>'text',
				'input' => 'numbers',
				'max_length' => 50,
				'name'=>'price',
				'value'=>$item['price']
			),				
			
			'effect'	=> array(
				'class'=>'input',
				'type'=>'text',
				'input' => 'numbers',
				'max_length' => 50,
				'name'=>'effect',
				'value'=>$item['effect']
			),		
			
			'required_level'	=> array(
				'class'=>'input',
				'type'=>'text',
				'name'=>'level',
				'input' => 'numbers',
				'max_length' => 50,	
				'value' => $item['level']
			),
			
			'type' => array(
				'class' => 'select',
				'name' => 'type',
				'options' => array('stamina' => lang('stamina'), 'health' => lang('health'), 'experience' => lang('experience')),
				'value' => 'stamina',
				'voluntary' => 1,
				'value' => @$item['type']
			),				
			
			'special' => array(
				'class' => 'select',
				'name' => 'special',
				'options' => array(0=> lang('no'), 1 => lang('yes')),
				'value' => $item['special']
			),	

			'delete' => array(
				'class' => 'select',
				'name' => 'delete',
				'options' => array(0=> lang('no'), 1 => lang('yes')),
				'value' => 0
			),					

		), 'edit_item', fw::route(0).'/'.fw::route(1).'/'.fw::route(2));

	if($edit_item->submitted)
	{		
		if(fw::route(2) == 'special' && !$_POST['type']) $edit_item->error[] = 'e_type';
		
		if(empty($edit_item->error))
		{
			$type = '';
			if(!empty($_POST['type']) && fw::route(2) == 'special')
			{
				$type = '`type` = "'.@$_POST['type'].'",';
			}

			$effect = $_POST['effect'];
			if(fw::route(2) == 'special')
			{
				$effect = round($_POST['effect']/100, 2);
			}
			
			if($_POST['delete'])
			{
				db::query("DELETE FROM items_".fw::route(2)." WHERE id = ?", array(fw::route(1)));
				
				$edit_item->success = 'item_has_been_deleted';
			} else
			{
			
			db::query('UPDATE items_'.fw::route(2).' SET price='.$_POST['price'].', name="'.$_POST['name'].'", level='.$_POST['level'].','.$type.' `effect`='.$effect.', `special`='.$_POST['special'].' WHERE id = ?', array(fw::route(1)));
			
			$edit_item->success = 'item_has_been_edited';
			}
		}
	}
}
