<?php
// Configuration
fw::set_config(array(
	'title'	=>	TITLE.' / '.lang('view_quests'),
	'style' 	=>	'administration'
));

// User list
$search = "";
$search_url = '';

if(fw::route(4))
{
	$search = urldecode(fw::route(4));

	$clause = "WHERE";
	
	$search = " ".$clause." (`title` LIKE '%".$search."%')";
	
	$search_url = '/'.urlencode($search);
}

$total = db::count("quests".$search);
$show = 30;

$begin = fw::route(1)*$show;

if(!isset($begin) 
	|| $begin == '0' 
	|| !is_numeric($begin)
) $begin = 0;

$current = fw::route(1);

if(!isset($current) 
	|| $current == '0'
	|| !is_numeric($begin)
) $current = 0;

switch(fw::route(2))
{
	default:
		$order = 'id';
	break;
	
	case 'level':
		$order = 'level_required';
	break;
	
	case 'money_gained':
		$order = 'money_gained';
	break;

	case 'experience_gained':
		$order = 'experience_gained';
	break;
	
	case 'completion_time':
		$order = 'completion_time';
	break;
	
	case 'title':
		$order = 'title';
	break;		
}

switch(fw::route(3))
{
	default:
		$order_type = 'DESC';
		break;
	case 'asc':
		$order_type = 'ASC';
	break;
}

$order_type_url = 'desc';
if(fw::route(3) == $order_type_url) $order_type_url = 'asc';

if(is_numeric(fw::route(5)))
{
	db::query("DELETE FROM quest_log WHERE quest = ?", array(fw::route(5)));
	db::query("UPDATE users SET quest = 0, quest_count = 0 WHERE quest = ?", array(fw::route(5)));
	db::query("DELETE FROM quests WHERE id = ?", array(fw::route(5)));
}
