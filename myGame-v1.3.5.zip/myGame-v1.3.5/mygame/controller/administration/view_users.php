<?php
// Configuration
fw::set_config(array(
	'title'	=>	TITLE.' / '.lang('view_users'),
	'style' 	=>	'administration'
));

// User list
$search = "";
$search_url = '';

if(fw::route(4))
{
	$search = urldecode(fw::route(4));

	$clause = "WHERE";
	
	$search = " ".$clause." (`username` LIKE '%".$search."%' OR `email` LIKE '%".$search."%')";
	
	$search_url = '/'.urlencode($search);
}

$total = db::count("users".$search);
$show = 30;

$begin = fw::route(1)*$show;

if(!isset($begin) 
	|| $begin == 'index' 
	|| !is_numeric($begin)
) $begin = 0;

$current = fw::route(1);

if(!isset($current) 
	|| $current == 'index'
	|| !is_numeric($begin)
) $current = 0;

switch(fw::route(2))
{
	default:
		$order = 'id';
	break;
	
	case 'ip':
		$order = 'ip';
	break;
	
	case 'level':
		$order = 'level';
	break;
}

switch(fw::route(3))
{
	default:
		$order_type = 'DESC';
	break;
	
	case 'asc':
		$order_type = 'ASC';
	break;
}

$order_type_url = 'desc';
if(fw::route(3) == $order_type_url) $order_type_url = 'asc';