<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('setup'),
	'style' 	=>	'administration'
));

// Languages
$languages = scandir(CWEB.'lang');
foreach($languages as $language)
{
	if($language != '.' && $language != '..') $language_a[$language] = $language;
}

// Styles
$styles = scandir(CWEB.'style');
foreach($styles as $style)
{
	if($style != '.' && $style != '..' && $style != 'administration') $style_a[$style] = $style;
}

foreach(db::query('SELECT `key`, `value` FROM configuration ORDER BY `key` DESC') as $element)
{
	$config[$element['key']] = $element['value'];
}

// Form
$configuration = new form;
$configuration->create(array(
			'page'	=>	array(
				'class'	=>	'header',
			),

			'title' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'title',
				'value' => TITLE
			),
			
			'description' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'description',
				'value' => fw::$config['description']
			),
			
			'url' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'url',
				'value' => fw::$config['url']
			),
			
			'mail' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'mail',
				'value' => fw::$config['mail']
			),
			
			'tags' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'tags',
				'value' => fw::$config['tags']
			),
			
			'language' => array(
				'class' 	=> 	'select',
				'name' 		=> 	'language',
				'options' 	=> 	$language_a,
				'value'		=>	fw::$config['lang']
			),
			
			'template' => array(
				'class' => 'select',
				'name' 	=> 'style',
				'options' => $style_a,
				'value'	=>	fw::$config['style']
			),	
			
			'head_elements' => array(
				'class' => 'textarea',
				'type' 	=> 'text',
				'voluntary' => 1,
				'name' 	=> 'head',
				'value' => fw::$config['head']
			),
			
			'ad' => array(
				'class' => 'textarea',
				'type' 	=> 'text',
				'voluntary' => 1,
				'name' 	=> 'ad',
				'value' => fw::$config['ad']
			),
			
			'about_info' => array(
				'class' => 'textarea',
				'type' 	=> 'bbcode',
				'name' 	=> 'about',
				'value' => $config['about']
			),
			
			'rules' => array(
				'class' => 'textarea',
				'type' 	=> 'bbcode',
				'name' 	=> 'rules',
				'value' => $config['rules']
			),			

			'front_page' => array(
				'class' => 'textarea',
				'type' 	=> 'bbcode',
				'name' 	=> 'front_page',
				'value' => $config['front_page']
			),						
			
			'game'	=>	array(
				'class'	=>	'header',
			),	
			
			'allow_working' => array(
				'class' => 'select',
				'name' 	=> 'working',
				'options' => array('1' => lang('yes'), '0' => lang('no')),
				'value'	=>	$config['work']
			),	

			'allow_quests' => array(
				'class' => 'select',
				'name' 	=> 'quests',
				'options' => array('1' => lang('yes'), '0' => lang('no')),
				'value'	=> $config['quests']
			),	

			'allow_groups' => array(
				'class' => 'select',
				'name' 	=> 'allow_groups',
				'options' => array('1' => lang('yes'), '0' => lang('no')),
				'value'	=> $config['allow_groups']
			),	
			
			'failed_logins' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'failed_logins',
				'value' => fw::$config['failed_logins']
			),			

			'interval' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'interval',
				'value' => fw::$config['interval']
			),						

			'starting_points' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'starting_points',
				'value' => fw::$config['starting_points']
			),						

			'earning_points' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'earning_points',
				'value' => fw::$config['earning_points']
			),						

			'health_cost' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'health_cost',
				'value' => fw::$config['health_cost']
			),						

			'stamina_cost' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'stamina_cost',
				'value' => fw::$config['stamina_cost']
			),

			'starting_money' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'starting_money',
				'value' => fw::$config['starting_money']
			),		
			
			'health_increase' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'health_increase',
				'value' => fw::$config['health_increase']
			),									

			'working_time' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'working_time',
				'value' => fw::$config['working_time']
			),									

			'working_payment' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'working_payment',
				'value' => fw::$config['working_payment']
			),									

			'group_creating_tax' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'group_creating_tax',
				'value' => fw::$config['group_creating_tax']
			),												

			'group_creating_level' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'group_creating_level',
				'value' => fw::$config['group_creating_level']
			),												

			'group_exp_interest' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'group_exp_interest',
				'value' => round(fw::$config['group_exp_interest']*100)
			),												
			
			'luck' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'luck',
				'value' => fw::$config['luck']
			),									
			
			'uploads' => array(
				'class' => 'header'
			),
						
			'dimensions' => array(
				'class' => 'input',
				'type' => 'text',
				'name' => 'dimensions',
				'value' => fw::$config['dimensions']
			),		
			
			'file_limit' => array(
				'class' => 'input',
				'type' => 'text',
				'name' => 'file_limit',
				'value' => round(fw::$config['file_limit']/1024/1024, 1)
			),		
			
		), 'configuration', fw::route(0));

if($configuration->submitted)
{	
	if(user::data('admin') != 1) $configuration->error[] = 'e_user_not_main_admin';
	if($_POST['luck'] < 0 || $_POST['luck'] > 100) $configuration->error[] = 'e_luck';
	if($_POST['group_exp_interest'] < 1 || $_POST['group_exp_interest'] > 100) $configuration->error[] = 'e_group_exp_interest';
	
	if(!$configuration->error)
	{
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['title'], 'title'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['description'], 'description'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['url'], 'url'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['mail'], 'mail'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['tags'], 'tags'));

		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['language'], 'lang'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['head'], 'head'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['style'], 'style'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['ad'], 'ad'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['about'], 'about'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['rules'], 'rules'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['front_page'], 'front_page'));		

		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['failed_logins'], 'failed_logins'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['interval'], 'interval'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['starting_points'], 'starting_points'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['earning_points'], 'earning_points'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['health_cost'], 'health_cost'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['stamina_cost'], 'stamina_cost'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['starting_money'], 'starting_money'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['health_increase'], 'health_increase'));	
		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['working'], 'work'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['working_time'], 'working_time'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['luck'], 'luck'));		

		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['quests'], 'quests'));		

		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['allow_groups'], 'allow_groups'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['group_creating_tax'], 'group_creating_tax'));		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array(round($_POST['group_exp_interest']/100, 2), 'group_exp_interest'));				
		
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['dimensions'], 'dimensions'));
		db::query("UPDATE `configuration` SET `value`=? WHERE `key`=?", array($_POST['file_limit']*1024*1024, 'file_limit'));		
	
		$configuration->success = 'Edited';
	}
}
