<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('add_badge'),
	'style' 	=>	'administration'
));

fw::set_contents(array
(
	'Uploader'	=>	array('location' => 'uploader', 'type' => 'js')
));		

$dimensions = explode('x', fw::config('dimensions'));

fw::script_var('IMG', WEB.'style/'.fw::config('style').'/image/img.png');
fw::script_var('UPLOADED', WEB.'style/'.fw::config('style').'/image/uploaded.png');
fw::script_var('LOADING', WEB.'style/'.fw::config('style').'/image/loading.gif');
fw::script_var('UPLOAD_ID', uniqid());
fw::script_var('WEB', WEB);
fw::script_var('FILE_LIMIT', (int) (fw::config('file_limit')));
fw::script_var('CONST_AMOUNT', (int) (db::count("image WHERE upload_id = ?", array(@$_POST['image']))));
fw::script_var('MAX_WIDTH', (int) $dimensions[0]);
fw::script_var('MAX_HEIGHT', (int) $dimensions[1]);
fw::script_var('UPLOAD_LIMIT', (int) fw::config('upload_limit'));
fw::script_var('info', lang('notification', array('size'=>round(fw::config('file_limit')/1024/1024, 1))));
fw::script_var('error', array
(
	lang('error_url'),
	lang('error_type'),
	lang('error_size', array('size'=>round(fw::config('file_limit')/1024/1024, 1))),
	lang('error_amount', array('amount' => fw::config('upload_limit'))),
	lang('error_dim', array('dimensions'=>fw::config('dimensions')))
));		

fw::script_line('
	$(function(){
		$("#upload").insertBefore( $("input[name=\'image\']") );
	});
');

// Adding items
$add_badge = new form;
$add_badge->create(array(
		'image' => array(
			'class' => 'input',
			'type' => 'hidden',
			'name' => 'image',
		),

		'name'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'name',
		),

		'count'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'count',
		),				
		
		'reputation'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'reputation',
		),		
		
		'period'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'period',
			'input' => 'numbers',
			'max_length' => 50,	
			'voluntary' => 1
		),
		
		'type' => array(
			'class' => 'select',
			'name' => 'type',
			'options' => array('items' => lang('items'), 'win_ratio' => lang('win_ratio'), 'special_items' => lang('special_items'), 'team_deathmatch' => lang('team_deathmatch'), 'deathmatch' => lang('deathmatch'), 'money' => lang('money'), 'level' => lang('level'), 'work' => lang('work'), 'finished_quests' => lang('finished_quests')),
			'value' => 'items'
		),	
		
	), 'add_badge', fw::route(0));

if($add_badge->submitted)
{		
	if(!$_POST['image']) $add_badge->error[] = 'e_image';
	
	if(empty($add_badge->error))
	{		
		db::insert('badges', array('count'=>$_POST['count'], 'period'=>''.@$_POST['period'].'', 'reputation'=>$_POST['reputation'], 'type' => $_POST['type'], '`title`'=>''.$_POST['name'].''));

		// Images
		if($_POST['image'])
		{
			db::query("UPDATE `image` SET user=? WHERE `upload_id`=?", array(user::data('id'), $_POST['image']));
			
			foreach(db::query("SELECT * FROM `image` WHERE `upload_id`=?", array($_POST['image'])) as $image)
			{
				if($image)
				{				
					$last_item = @db::query("SELECT * FROM badges ORDER BY id DESC LIMIT 1")->fetch();
					
					$size = getimagesize(CWEB.'upload/original/'.$image['id'].'.'.$image['extension']);
					$size = explode('x', $size);
					
					if($size[0] > 16 || $size[1] > 16)
					{
						create_thumbnail(CWEB.'upload/original/'.$image['id'].'.'.$image['extension'], CWEB.'images/badges/'.($last_item['id']).'.png', 16, 16);
					} else
					{
						rename(CWEB.'upload/original/'.$image['id'].'.'.$image['extension'], CWEB.'images/badges/'.($last_item['id']).'.png');
					}
				}
			}
		}		
		
		$add_badge->success = 'badge_has_been_added';
	}
}
