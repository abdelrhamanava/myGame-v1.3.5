<?php
// Configuration
fw::set_config(array(
	'title'	=>	TITLE.' / '.lang('edit_user'),
	'style' 	=>	'administration'
));

// Editing user
$user = db::query('SELECT * FROM users WHERE id = ?', fw::route(1))->fetch();

$edit_user = new form;

$referer = $edit_user->submitted?$_POST['referer']:(isset($_SERVER['HTTP_REFERER'])?$_SERVER['HTTP_REFERER']:'');

$edit_user->create(array(
			'referer' => array(
				'class'	=>	'input',
				'type'	=>	'hidden',
				'name'	=>	'referer',
				'value'	=>	$referer
			),
			
			'username' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'username',
				'value' => $user['username']
			),
			'mail' => array(
				'class' => 'input',
				'type' 	=> 'text',
				'name' 	=> 'mail',
				'value' => $user['email']
			),			
			
			'password'	=> array(
				'class'	=>	'input',
				'type'	=>	'password',
				'name'	=>	'password',
				'value'	=>	''
			),
			
			'password_confirm'	=> array(
				'class'	=>	'input',
				'type'	=>	'password',
				'name'	=>	'password_confirm',
				'value'	=>	''
			),
			
		), 'edit_user', fw::route(0).'/'.fw::route(1));
		
if($edit_user->submitted)
{
	if(db::count('users WHERE username=?', array($_POST['username'])) > 1) $edit_user->error[] = 'e_username_taken';
	
	if(strlen($_POST['username']) < 3 || strlen($_POST['username']) > 12) $edit_user->error[] = 'e_username_length';
	
	if($_POST['password'] != $_POST['password_confirm'] && $_POST['password']) $edit_user->error[] = 'e_repeat_password';
	
	if(!$_POST['username']) $edit_user->error[] = 'e_insert_username';
	
	if(!$edit_user->error)
	{						
		$password = md5($_POST['password'].SECRET1);
		if(!$_POST['password']) $password = $user['password'];
		
		// Execute
		db::query('UPDATE `users` SET username=?, email=?, password=? WHERE id=?', array($_POST['username'], $_POST['mail'], $password, fw::route(1)));
		
		if($_POST['referer'])
		{
			header('Location: '.$_POST['referer']);
			
			exit;
		} else
		{
			$edit_user->success = 'user_edited_successfully';
		}
	}
}
