<?php
// Configuration
fw::set_config(array(
	'title'	=>	TITLE.' / '.lang('view_services'),
	'style' 	=>	'administration'
));

// Service list
$search = "";
$search_url = '';

if(fw::route(4))
{
	$search = urldecode(fw::route(4));

	$clause = "WHERE";
	
	$search = " ".$clause." (`name` LIKE '%".$search."%')";
	
	$search_url = '/'.urlencode($search);
}

$total = db::count("services".$search);
$show = 30;

$begin = fw::route(1)*$show;

if(!isset($begin) 
	|| $begin == 'index' 
	|| !is_numeric($begin)
) $begin = 0;

$current = fw::route(1);

if(!isset($current) 
	|| $current == 'index'
	|| !is_numeric($begin)
) $current = 0;

switch(fw::route(2))
{	
	default:
		$order = 'price';
	break;
	
	case 'amount':
		$order = 'amount';
	break;
}

switch(fw::route(3))
{
	default:
		$order_type = 'DESC';
	break;
	
	case 'asc':
		$order_type = 'ASC';
	break;
}

if(is_numeric(fw::route(5)) && fw::route(5))
{
	db::query("DELETE FROM services WHERE id = ?", array(fw::route(5)));
}

$order_type_url = 'desc';
if(fw::route(3) == $order_type_url) $order_type_url = 'asc';
