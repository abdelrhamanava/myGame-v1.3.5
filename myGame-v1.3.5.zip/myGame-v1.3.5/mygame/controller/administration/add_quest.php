<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('add_quest'),
	'style' 	=>	'administration'
));

// Adding quests
$add_quest = new form;
$add_quest->create(array(
		'name'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'name',
		),

		'count'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'count',
			'value' => 1
		),				
		
		'experience_gained'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 3,
			'name'=>'experience',
			'voluntary'=>1
		),		

		'money_gained'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'money',
			'voluntary'=>1			
		),		
		
		'completion_time'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'time',
			'input' => 'numbers',
			'max_length' => 50,	
			'voluntary' => 1
		),

		'level_required'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'level',
			'input' => 'numbers',
			'max_length' => 50,	
			'voluntary' => 1
		),
		
		'required_resource' => array(
			'class' => 'select',
			'name' => 'resource',
			'options' => array('win_ratio' => lang('win_ratio'), 'attack' => lang('attack'), 'defense' => lang('defense'), 'endurance' => lang('endurance'), 'money' => lang('money'), 'reputation' => lang('reputation'), 'credit' => lang('credit'), 'points' => lang('free_points'), 'finished_quests' => lang('finished_quests')),
			'value' => 'win_ratio'
		),	
		
		'required_resource_amount'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'required_resources',
			'input' => 'numbers',
			'max_length' => 50,	
		),		
		
	), 'add_quest', fw::route(0));

if($add_quest->submitted)
{	
	if($_POST['money'] <= 0 && $_POST['experience'] <= 0) $add_quest->error[] = 'e_choose_reward';
	
	if(empty($add_quest->error))
	{		
		db::insert('quests', array('money_gained' => $_POST['money'], 'experience_gained' => $_POST['experience'], 'count'=>$_POST['count'], 'completion_time'=>''.@$_POST['time'].'', 'resource' => $_POST['resource'], 'resource_amount'=>$_POST['required_resources'], 'level_required' => $_POST['level'], '`title`'=>''.$_POST['name'].''));
		
		$add_quest->success = 'quest_has_been_added';
	}
}
