<?php
// Configuration
fw::set_config(array(
	'title'	=>	TITLE.' / '.lang('view_items'),
	'style' 	=>	'administration'
));

// User list
$search = "";
$search_url = '';

if(fw::route(5))
{
	$search = urldecode(fw::route(5));

	$clause = "WHERE";
	
	$search = " ".$clause." (`name` LIKE '%".$search."%')";
	
	$search_url = '/'.urlencode($search);
}

switch(fw::route(1))
{
	default:
		$type = 'weapons';
	break;
	
	case 'defense':
		$type = 'defense';
	break;
	
	case 'extra':
		$type = 'extra';
	break;

	case 'special':
		$type = 'special';
	break;
}

$total = db::count("items_".$type.$search);
$show = 30;

$begin = fw::route(2)*$show;

if(!isset($begin) 
	|| $begin == '0' 
	|| !is_numeric($begin)
) $begin = 0;

$current = fw::route(2);

if(!isset($current) 
	|| $current == '0'
	|| !is_numeric($begin)
) $current = 0;

switch(fw::route(3))
{
	default:
		$order = 'id';
	break;
	
	case 'price':
		$order = 'price';
	break;
	
	case 'level':
		$order = 'level';
	break;

	case 'level':
		$order = 'level';
	break;

	case 'effect':
		$order = 'effect';
	break;	
	
	case 'name':
		$order = 'name';
	break;		
}

switch(fw::route(4))
{
	default:
		$order_type = 'DESC';
		break;
	case 'asc':
		$order_type = 'ASC';
	break;
}

$order_type_url = 'desc';
if(fw::route(4) == $order_type_url) $order_type_url = 'asc';
