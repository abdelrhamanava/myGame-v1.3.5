<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('edit_badge'),
	'style' 	=>	'administration'
));

if(is_numeric(fw::route(1)))
{
	$badge = db::query("SELECT * FROM badges WHERE id = ?", array(fw::route(1)))->fetch();
}

if(!empty($badge))
{
	// Adding items
	$edit_badge = new form;
	$edit_badge->create(array(
		'name'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'name',
			'value' => $badge['title'],
		),

		'count'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'count',
			'value' => $badge['count']
		),				
		
		'reputation'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'reputation',
			'value' => $badge['reputation'],
		),		
		
		'period'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'period',
			'input' => 'numbers',
			'max_length' => 50,	
			'voluntary' => 1,
			'value' => $badge['period']
		),

		'delete' => array(
			'class' => 'select',
			'name' => 'delete',
			'options' => array(0=> lang('no'), 1 => lang('yes')),
			'value' => 0
		),					

		), 'edit_badge', fw::route(0).'/'.fw::route(1));

	if($edit_badge->submitted)
	{				
		if(empty($edit_badge->error))
		{			
			if($_POST['delete'])
			{
				db::query("DELETE FROM badges WHERE id = ?", array(fw::route(1)));
				
				$edit_badge->success = 'badge_has_been_deleted';
			} else
			{
				db::query('UPDATE badges SET reputation='.$_POST['reputation'].', title="'.$_POST['name'].'", period='.@$_POST['period'].', `count`='.$_POST['count'].' WHERE id = ?', array(fw::route(1)));
				
				$edit_badge->success = 'badge_has_been_edited';
			}
		}
	}
}
