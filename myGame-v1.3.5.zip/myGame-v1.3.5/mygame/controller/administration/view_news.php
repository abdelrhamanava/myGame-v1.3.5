<?php
// Configuration
fw::set_config(array(
	'title'	=>	TITLE.' / '.lang('view_news'),
	'style' 	=>	'administration'
));

// News list
$search = '';
if(fw::route(4))
{
	$search = urldecode(fw::route(4));
	$search = ' WHERE title LIKE "%'.$search.'%" OR content LIKE "%'.$search.'%"';
}

$total = db::count("news".$search);
$show = 30;

$begin = fw::route(1)*$show;

if(!isset($begin) 
	|| $begin == 'index' 
	|| !is_numeric($begin)
) $begin = 0;

$current = fw::route(1);

if(!isset($current) 
	|| $current == 0
	|| !is_numeric($begin)
) $current = 0;

switch(fw::route(2))
{
	default:
		$order = 'id';
	break;
}

switch(fw::route(3))
{
	default:
		$order_type = 'DESC';
		break;
	case 'asc':
		$order_type = 'ASC';
	break;
}

$order_type_url = 'desc';
if(fw::route(3) == $order_type_url) $order_type_url = 'asc';

// Delete news
if(is_numeric(fw::route(5)))
{
	db::query("DELETE FROM news WHERE id = ?", array(fw::route(5)));
}