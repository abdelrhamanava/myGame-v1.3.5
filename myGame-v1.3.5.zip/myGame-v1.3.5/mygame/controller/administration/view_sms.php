<?php
// Configuration
fw::set_config(array(
	'title'	=>	TITLE.' / '.lang('view_sms'),
	'style' 	=>	'administration'
));

// Sms list
$search = '';
if(fw::route(4))
{
	$search = urldecode(fw::route(4));
	$search = ' WHERE number LIKE "%'.$search.'%"';
}

$total = db::count("sms".$search);
$show = 30;

$begin = fw::route(1)*$show;

if(!isset($begin) 
	|| $begin == 'index' 
	|| !is_numeric($begin)
) $begin = 0;

$current = fw::route(1);

if(!isset($current) 
	|| $current == 0
	|| !is_numeric($begin)
) $current = 0;

switch(fw::route(2))
{
	default:
		$order = 'id';
	break;
}

switch(fw::route(3))
{
	default:
		$order_type = 'DESC';
		break;
	case 'asc':
		$order_type = 'ASC';
	break;
}

$order_type_url = 'desc';
if(fw::route(3) == $order_type_url) $order_type_url = 'asc';
