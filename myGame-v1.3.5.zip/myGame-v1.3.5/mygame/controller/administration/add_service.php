<?php
// Configuration
fw::set_config(array(
	'title'		=>	TITLE.' / '.lang('add_service'),
	'style' 	=>	'administration'
));

// Adding services
$add_service = new form;
$add_service->create(array(
		'name'	=> array(
			'class'=>'input',
			'type'=>'text',
			'name'=>'name',
		),

		'price'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'price',
		),				
		
		'amount'	=> array(
			'class'=>'input',
			'type'=>'text',
			'input' => 'numbers',
			'max_length' => 50,
			'name'=>'amount',
			'voluntary' => 1,
		),		
				
		'type' => array(
			'class' => 'select',
			'name' => 'type',
			'options' => array('money' => lang('money'), 'level' => lang('level'), 'health' => lang('health'), 'stamina' => lang('stamina')),
			'value' => 'money'
		),	
		
	), 'add_service', fw::route(0));

if($add_service->submitted)
{			
	if(($_POST['amount'] <= 0 && $_POST['type'] != 'stamina') && ($_POST['amount'] <= 0 && $_POST['type'] != 'health')) $add_service->error['amount'] = 'e_insert';

	if(empty($add_service->error))
	{		
		db::insert('services', array('price'=>$_POST['price'], 'amount'=>''.@$_POST['amount'].'', 'name'=>$_POST['name'], 'type' => $_POST['type']));
		
		$add_service->success = 'service_has_been_added';
	}
}
