<?php
$health_cost = user::max_health()-user::data('health');
$health_cost = round($health_cost*fw::config('health_cost'));

$stamina_cost = user::max_stamina()-user::data('stamina');
$stamina_cost = round($stamina_cost*fw::config('stamina_cost'));

if(!empty($_GET['heal']))
{
	if(user::data('health') >= user::max_health()) $error[] = 'e_max_health';
	if(user::data('money') < $health_cost) $error[] = 'e_insufficient_funds';

	if(empty($error))
	{
		user::money(-$health_cost);
		db::query("UPDATE users SET health = ? WHERE id = ?", array(user::max_health(), user::data('id')));
	}
}

if(!empty($_GET['rest']))
{
	if(user::data('stamina') >= user::max_stamina()) $error[] = 'e_max_stamina';
	if(user::data('money') < $stamina_cost) $error[] = 'e_insufficient_funds';

	if(empty($error))
	{
		user::money(-$stamina_cost);
		db::query("UPDATE users SET stamina = ? WHERE id = ?", array(user::max_stamina(), user::data('id')));
	}
}