<?php
// Item list
$show = 25;

$begin = fw::route(2)*$show;
if(!isset($begin) || $begin == 0 || !is_numeric($begin)) $begin = 0;

$current = fw::route(2);
if(!isset($current) || $current == 0|| !is_numeric($begin)) $current = 0;

$category = 'weapons';

switch(fw::route(1))
{
	case 'weapons':
		$category = 'weapons';
	break;
	
	case 'special':
		$category = 'special';
	break;
	
	case 'extra':
		$category = 'extra';
	break;
	
	case 'defense':
		$category = 'defense';
	break;
}

$total = db::count("items_".$category." WHERE special = 0");