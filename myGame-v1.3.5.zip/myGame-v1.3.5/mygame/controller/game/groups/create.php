<?php
// Content
$create = new form;
$create->create(array(
	'title' => array(
		'class' => 'input',
		'input' => 'long_text',
		'type' => 'text',
		'name' => 'title',
		'max_length' => '30',
	),
	
	'description' => array(
		'class' => 'textarea',
		'input' => 'long_text',
		'type' => 'bbcode',
		'name' => 'description',
		'max_length' => '1500', 
	)
), 'create', fw::route(0));
		
if($create->submitted)
{		
	if(fw::config('group_creating_level') && user::data('level') < fw::config('group_creating_level')) $create->error[] = 'e_level';
	if(db::count("groups WHERE `name` = ?", array($_POST['title']))) $create->error[] = 'e_group_name_exists';
	if(user::data('money') < fw::config('group_creating_tax')) $create->error[] = 'e_money';
	if(db::count("groups WHERE user = ?", array(user::data('id'))) || db::count("group_members WHERE user = ?", array(user::data('id')))) $create->error[] = 'e_in_group';
	
	if(empty($create->error))
	{
		db::query("DELETE FROM group_applicants WHERE user = ?", array(user::data('id')));
	
		user::money(-fw::config('group_creating_tax'));
		
		db::insert('groups', array('name' => $_POST['title'], 'description' => $_POST['description'], 'user' => user::data('id'), 'time' => time()));
		db::insert('group_members', array('`group`' => db::last_id(), 'user' => user::data('id'), 'time' => time()));
		
		$group = db::query("SELECT * FROM groups WHERE user = ?", array(user::data('id')))->fetch();
		
		go('group/'.$group['id']);
	}
}