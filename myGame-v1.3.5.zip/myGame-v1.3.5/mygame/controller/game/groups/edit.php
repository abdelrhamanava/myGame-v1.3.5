<?php
if(db::count("groups WHERE user = ?", array(user::data('id'))))
{
	require CWEB.'fw/group.php';

	$group = db::query("SELECT * FROM groups WHERE user = ?", array(user::data('id')))->fetch();
	$group = new group($group['id']);

	// Config
	fw::set_contents(array
	(
		'Uploader'	=>	array('location' => 'uploader', 'type' => 'js')
	));		

	$dimensions = explode('x', fw::config('dimensions'));

	fw::script_var('IMG', WEB.'style/'.fw::config('style').'/image/img.png');
	fw::script_var('UPLOADED', WEB.'style/'.fw::config('style').'/image/uploaded.png');
	fw::script_var('LOADING', WEB.'style/'.fw::config('style').'/image/loading.gif');
	fw::script_var('UPLOAD_ID', uniqid());
	fw::script_var('WEB', WEB);
	fw::script_var('FILE_LIMIT', (int) (fw::config('file_limit')));
	fw::script_var('CONST_AMOUNT', (int) (db::count("image WHERE upload_id = ?", array(@$_POST['image']))));
	fw::script_var('MAX_WIDTH', (int) $dimensions[0]);
	fw::script_var('MAX_HEIGHT', (int) $dimensions[1]);
	fw::script_var('UPLOAD_LIMIT', (int) fw::config('upload_limit'));
	fw::script_var('info', lang('notification', array('size'=>round(fw::config('file_limit')/1024/1024, 1))));
	fw::script_var('error', array
	(
		lang('error_url'),
		lang('error_type'),
		lang('error_size', array('size'=>round(fw::config('file_limit')/1024/1024, 1))),
		lang('error_amount', array('amount' => fw::config('upload_limit'))),
		lang('error_dim', array('dimensions'=>fw::config('dimensions')))
	));		

	fw::script_line('$(function(){ $("#upload").insertBefore( $("input[name=\'image\']") ); } );');

	// Edit form
	$edit = new form;
	$edit->create(array(
			'image' => array(
				'class' => 'input',
				'type' => 'hidden',
				'name' => 'image',
				'voluntary' => 1
			),
			
			'description' => array(
				'class' => 'textarea',
				'type' => 'bbcode',
				'input' => 'long_text',
				'name' => 'description',
				'max_length' => '1000',
				'value' => $group->data('description'),
				'voluntary' => 1,
			),
					
		), 'edit', fw::route(0));
		
	if($edit->submitted)
	{				
		if(!$edit->error)
		{						
			if(!empty($_POST['image']))
			{			
				foreach(db::query("SELECT * FROM `image` WHERE `upload_id`=?", array($_POST['image'])) as $image)
				{
					if($image)
					{
						create_thumbnail(CWEB.'upload/original/'.$image['id'].'.'.$image['extension'], CWEB.'upload/group_avatar/'.$group->data('id').'.png', 100, 100);
					}
				}			
			}
		
			db::query("UPDATE groups SET description = ? WHERE id = ?", array($_POST['description'], $group->data('id')));
			
			go('group/'.$group->data('id'));
		}
	}
	
	// Delete group
	if(!empty($_GET['delete']))
	{
		foreach(db::query("SELECT * FROM group_members WHERE `group` = ?", array($group->data('id'))) as $member)
		{
			$group->leave($member['user']);
			
			profile::log($member['user'], 'group_deleted|VALUES|group='.$group->data('name').';');			
		}
	
		db::query("DELETE FROM group_members WHERE `group` = ?", array($group->data('id')));
		db::query("DELETE FROM group_applicants WHERE `group` = ?", array($group->data('id')));		
		db::query("DELETE FROM groups WHERE id = ?", array($group->data('id')));		
	}
}