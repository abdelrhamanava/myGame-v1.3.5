<?php
require CWEB.'fw/group.php';

// Content
if(is_numeric(fw::route(1)))
{
	$group = new group(fw::route(1));
}

if(user::online())
{
	// Leave group
	if(!empty($_GET['leave_group']) && $group->is_member())
	{
		$group->leave();
	}

	// Join group
	if(!empty($_GET['join']) && !$group->is_member() && !db::count("group_applicants WHERE user = ? AND `group` = ?", array(user::data('id'), $group->data('id'))))
	{
		$group->apply();
	}
	
	// Cancel joining request
	if(!empty($_GET['cancel']) && !$group->is_member() && db::count("group_applicants WHERE user = ? AND `group` = ?", array(user::data('id'), $group->data('id'))))
	{
		$group->deny(user::data('id'));
	}	

	if($group->is_owner())
	{
		// Kick user
		if(!empty($_GET['kick']))
		{
			if(is_numeric($_GET['kick']) && db::count("group_members WHERE user = ? AND `group` = ?", array($_GET['kick'], $group->data('id'))))
			{
				$group->leave($_GET['kick']);
				
				profile::log($_GET['kick'], 'group_kick|VALUES|group='.$group->data('name').';');
			}
		}

		// Accept user
		if(!empty($_GET['accept']))
		{
			if(is_numeric($_GET['accept']) && db::count("group_members WHERE `group` = ?", array($group->data('id'))) <= 10 && db::count("group_applicants WHERE user = ? AND `group` = ?", array($_GET['accept'], $group->data('id'))))
			{
				$group->accept($_GET['accept']);
				
				profile::log($_GET['accept'], 'group_accepted|VALUES|group='.$group->data('name').';');
			}
		}
		
		// Decline user
		if(!empty($_GET['deny']))
		{
			if(is_numeric($_GET['deny']) && db::count("group_applicants WHERE user = ? AND `group` = ?", array($_GET['deny'], $group->data('id'))))
			{
				$group->deny($_GET['deny']);
				
				profile::log($_GET['deny'], 'group_denied|VALUES|group='.$group->data('name').';');
			}
		}		

		// Add point
		if(!empty($_GET['add']) && $group->data('points'))
		{
			if($_GET['add'] == 'attack') $group->point('attack');
			if($_GET['add'] == 'defense') $group->point('defense');
			if($_GET['add'] == 'endurance') $group->point('endurance');	
		}
	}
}