<?php
// Group list
$show = 25;

$begin = fw::route(1)*$show;
if(!isset($begin) || $begin == 0 || !is_numeric($begin)) $begin = 0;

$current = fw::route(1);
if(!isset($current) || $current == 0|| !is_numeric($begin)) $current = 0;

$total = db::count("groups");