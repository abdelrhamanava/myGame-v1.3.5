<?php
// Log list
$show = 15;

$begin = fw::route(1)*$show;
if(!isset($begin) || $begin == 0 || !is_numeric($begin)) $begin = 0;

$current = fw::route(1);
if(!isset($current) || $current == 0|| !is_numeric($begin)) $current = 0;

$total = db::count("logs WHERE user = ?", array(user::data('id')));

if(!empty($_GET['clean']))
{
	db::query("DELETE FROM logs WHERE user = ?", array(user::data('id')));
}
