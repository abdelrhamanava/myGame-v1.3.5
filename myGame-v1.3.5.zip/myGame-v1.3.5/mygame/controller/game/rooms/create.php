<?php
$players = array(2 => lang('2_players'), 3 => lang('3_players'), 4 => lang('4_players'));
$game_type = array('deathmatch' => lang('deathmatch'), 'team_deathmatch' => lang('team_deathmatch'));

$create = new form;
$create->create(array(
		'name' => array(
			'class' => 'input',
			'type' => 'text',
			'input' => 'long_text',
			'name' => 'name',
			'max_length' => '25',
			'value' => ''
		),

		'bet' => array(
			'class' => 'input',
			'type' => 'text',
			'input' => 'numbers',
			'name' => 'bet',
			'voluntary' => 1,
			'max_length' => '25',
		),

		'players' => array(
			'class' => 'select',
			'name' => 'players',
			'options' => $players
		),
		
		'game_type' => array(
			'class' => 'select',
			'name' => 'game_type',
			'options' => $game_type
		)		
		
		), 'create', fw::route(0));
		
if($create->submitted)
{		
	if($_POST['bet'] > user::data('money')) $create->error[] = 'e_insufficient_funds';
	if($_POST['bet'] < 0) $create->error[] = 'e_negative_number';

	if(!@array_key_exists($_POST['players'], $players)) $create->error['players'] = 'e_player_amount_doesnt_exist';
	if(!@array_key_exists($_POST['game_type'], $game_type)) $create->error['game_type'] = 'e_game_type_doesnt_exist';
	
	if(user::data('health') <= 0) $create->error[] = 'e_health';
	
	if($_POST['players'] == 3 && $_POST['game_type'] == 'team_deathmatch') $create->error[] = 'e_type';
	if($_POST['players'] == 2 && $_POST['game_type'] == 'team_deathmatch') $create->error[] = 'e_type';
		
	if(!$create->error)
	{		
		db::insert('rooms', array('name' => $_POST['name'], 'type' => $_POST['game_type'], 'bet' => $_POST['bet'], 'seats' => $_POST['players'], 'time' => time(), 'user' => user::data('id')));
		
		$id = db::query("SELECT * FROM rooms WHERE user = ? ORDER BY id DESC LIMIT 1", array(user::data('id')))->fetch();
		$id = $id['id'];
		
		if($_POST['bet'])
		{
			db::query("UPDATE users SET money = money - ? WHERE id = ?", array($_POST['bet'], user::data('id')));
		}
		
		// Room temp file		
		$data = array('time' => time(), 'finished' => 0, 'team_1' => 2, 'team_2' => 2, 'type' => $_POST['game_type'], 'user' => user::data('id'), 'id' => $id, 'name' => $_POST['name'], 'players' => $_POST['players'], 'current_players' => 0, 'active' => 0, 'bet' => $_POST['bet'], 'turn' => 0);
		file_put_contents(CWEB.'temp/rooms/'.$id.'.temp', json_encode($data));

		// Room log file		
		$log = '|NM|Game will start when everyone is ready.';
		file_put_contents(CWEB.'temp/logs/'.$id.'.temp', $log);

		// Room chat file
		$chat = '|NM|Use this box to communicate.';
		file_put_contents(CWEB.'temp/chat/'.$id.'.temp', $chat);		
		
		db::query("UPDATE users SET room = ? WHERE id = ?", array($id, user::data('id')));
		
		go('room/'.$id);
	}
}
