<?php
// Room list
$show = 25;

$begin = fw::route(1)*$show;
if(!isset($begin) || $begin == 0 || !is_numeric($begin)) $begin = 0;

$current = fw::route(1);
if(!isset($current) || $current == 0|| !is_numeric($begin)) $current = 0;

$total = db::count("rooms WHERE finished = 0 AND active = 0 AND ".time()."-time < 43200");