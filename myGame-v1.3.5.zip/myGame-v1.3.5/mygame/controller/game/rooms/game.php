<?php
if(fw::route(1))
{
	$room = @db::query("SELECT * FROM `rooms` WHERE id = ?", array(fw::route(1)))->fetch();
} else
{
	$room = db::query("SELECT * FROM `rooms` WHERE id = ?", array(user::data('room')))->fetch();
}

fw::script_var('countdown', fw::config('interval'));
fw::script_var('finished', $room['finished']);

fw::script_var('gametype', $room['type']);

$seats = $room['seats'];	
fw::script_var('seats', (int) $seats);	

// Create a temp file for player
if(!db::count('players WHERE user = ? AND room = ?', array(user::data('id'), $room['id'])) && user::data('health') > 0 && db::count('players WHERE room = ?', $room['id']) < $room['seats'] && isset($room['id']) && !$room['active'] && !$room['finished'])
{
	db::query("DELETE FROM players WHERE user = ?", array(user::data('id')));
	
	$total_seats = $room['seats'];
	for($i = 1; $i <= $total_seats; $i++)
	{
		if(!db::count("players WHERE room = ? AND seat = ?", array($room['id'], $i)))
		{
			$seat = $i;
			
			break;
		}
	}
	
	$team = 1;
	if($seat == 4 || $seat == 2) $team = 2;
		
	// Create the file
	$data = array('time' => 0, 'experience' => 0, 'team' => $team, 'seat' => $seat, 'special' => 0, 'extra' => 0, 'user' => user::data('id'), 'ready' => 0, 'finished' => 0, 'stamina' => user::data('stamina'), 'max_stamina' => user::data('max_stamina'), 'health' => user::data('health'), 'max_health' => user::data('max_health'), 'room' => $room['id'], 'turn' => 0);
	file_put_contents(CWEB.'temp/players/'.user::data('id').'.temp', json_encode($data));
					
	// Insert query
	db::insert('players', array('user' => user::data('id'), 'seat' => $seat, 'room' => $room['id'], 'time' => time()));
	
	db::query("UPDATE users SET room = ? WHERE id = ?", array($room['id'], user::data('id')));
	
	fw::script_var('turn', 0);	
	fw::script_var('active', 0);	
	fw::script_var('width_percent', 100);
	fw::script_var('time_passed', 0);	
	fw::script_var('player_seat', $seat);	
	
	// Update room file
	$game_file = fopen(CWEB.'temp/rooms/'.user::data('room').'.temp', 'r+');
	$game = fread($game_file, filesize(CWEB.'temp/rooms/'.user::data('room').'.temp'));

	$game = json_decode($game, true);	
	
	$game['current_players'] = db::count('players WHERE room = ?', array($room['id']));

	rewind($game_file);
	ftruncate($game_file, 0);
	
	fwrite($game_file, json_encode($game));
	fclose($game_file);			

	$default_player = json_decode(file_get_contents(CWEB.'temp/players/'.user::data('id').'.temp'), true);	
} else 
{
	if(user::data('room') == $room['id'])
	{
		$game = json_decode(file_get_contents(CWEB.'temp/rooms/'.user::data('room').'.temp'), true);

		fw::script_var('turn', $game['turn']);				
		
		if($game['turn'])
		{
			$player = json_decode(file_get_contents(CWEB.'temp/players/'.$game['turn'].'.temp'), true);
			fw::script_var('time_passed', time()-$player['time']);	
			fw::script_var('width_percent', 100-(time()-$player['time'])/fw::config('interval')*100);				
		} else 
		{
			fw::script_var('time_passed', 0);	
			fw::script_var('width_percent', 100);		
		}
		
		fw::script_var('active', $game['active']);	
		
		$default_player = json_decode(file_get_contents(CWEB.'temp/players/'.user::data('id').'.temp'), true);	
		fw::script_var('player_seat', $default_player['seat']);
	}
	
	if(user::data('health') <= 0)
	{
		$error[] = 'e_health';
	}
	
	if(db::count('players WHERE room = ?', $room['id']) >= $room['seats'])
	{
		$error[] = 'e_room_full';
	}
	
	if($room['active'])
	{
		$error[] = 'e_room_active';
	}
	
	if($room['finished'])
	{
		$error[] = 'e_room_finished';
	}
}

if(user::data('room') == $room['id'])
{
	fw::script_var('player', user::data('id'));	
	fw::script_var('current_players', db::count("players WHERE room = ?", array($room['id'])));	

	fw::script_line('
		$(function(){
			function loop()
			{			
				Chat.cache('.$room['id'].');
				Log.cache('.$room['id'].');			
				Update.cache('.$room['id'].');	

				setTimeout(loop, 1000);				
			}
			
			loop();
		
			$(".input[name=content]").focus();
			
			$("#sidebar").hide();
		});
	');

	// Leave room
	if(!empty($_GET['leave']) && !$game['active'] && !$game['finished'] && !$default_player['finished'])
	{
	
		// Update room file
		$game_file = fopen(CWEB.'temp/rooms/'.user::data('room').'.temp', 'r+');
		$game = fread($game_file, filesize(CWEB.'temp/rooms/'.user::data('room').'.temp'));

		$game = json_decode($game, true);	
		
		$game['current_players'] = db::count('players WHERE room = ?', array($room['id']))-1;

		rewind($game_file);
		ftruncate($game_file, 0);
		
		fwrite($game_file, json_encode($game));
		fclose($game_file);					
	
		db::query("DELETE FROM players WHERE user = ? AND room = ?", array(user::data('id'), $room['id']));
		db::query("UPDATE users SET room = 0 WHERE id = ?", array(user::data('id')));
		
		if(!db::count("players WHERE room = ?", array($room['id'])))
		{
			db::query("DELETE FROM rooms WHERE id = ?", array($room['id']));
		}
		
		go('rooms');
	}

	if(($game['finished'] || $default_player['finished']) && (db::count("players WHERE user = ? AND room = ?", array(user::data('id'), $room['id']))))
	{
		fw::script_line('
			$(function(){
				finish();
			});
		');
			
		if(!empty($_GET['finish']) && ($game['finished'] || $default_player['finished']) && !db::count("players WHERE room = ? AND user = ? AND game_over = 1", array($room['id'], user::data('id'))))
		{
			if($game['bet'])
			{
				if(!$default_player['finished'] && $default_player['health'])
				{
					if($game['type'] == 'deathmatch')
					{
						$amount = ($game['players']-1)*$game['bet'];
					} 
					
					if($game['type'] == 'team_deathmatch')
					{
						$amount = round((($game['players']-1)*$game['bet'])/2);
					}
					
					user::money($amount);
					
					user::exp(round($default_player['experience']*1.5));
					
				} else 
				{
					$amount = $game['bet'];
					
					user::money(-$amount);
					
					user::exp($default_player['experience']);
				}
			}	
			
			$win_ratio = 1;
			
			if($default_player['finished'] || $default_player['health'] <= 0)
			{
				$win_ratio = -1;
			} else
			{
				// Special items
				$percentage = mt_rand(0, 100);
				
				if($percentage <= fw::config('luck'))
				{
					$type = mt_rand(0, 3);
					$types = array('special', 'extra', 'weapons', 'defense');
					$type = $types[$type];
					
					$special_item = db::query("SELECT * FROM items_".$type." WHERE special = 1 AND level >= ".user::data('level')."-3 AND level <= ".user::data('level')."+3")->fetch();
					
					if(!empty($special_item))
					{
						db::insert("items", array('user' => user::data('id'), 'item' => $special_item['id'], 'category' => $type));

						user::badge('items', 1);												
						user::badge('special_items', 1);	

						profile::log(user::data('id'), 'special_item|VALUES|item='.$special_item['name'].';');
					}
				}
			}
			
			if(!$room['finished'])
			{
				db::query("UPDATE rooms SET finished = 1 WHERE id = ?", array($room['id']));
			}
			
			user::badge($game['type'], 1);
			
			user::badge('win_ratio', $win_ratio);
						
			db::query("UPDATE users SET health = ?, stamina = ?, room = 0, win_ratio = win_ratio + ? WHERE id = ?", array($default_player['health'], $default_player['stamina'], $win_ratio, user::data('id')));

			db::query("UPDATE players SET game_over = 1, room = ? WHERE user = ?", array(0, user::data('id')));
			
			go('rooms');
		}
	}
}
