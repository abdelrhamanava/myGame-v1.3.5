<?php
// Do a quest
if(is_numeric(fw::route(2)) && fw::route(1) == 'perform')
{
	$quest = db::query("SELECT * FROM quests WHERE id = ?", array(fw::route(2)))->fetch();
	
	if(empty($quest)) $error[] = 'e_quest';
	if(user::data($quest['resource']) < $quest['resource_amount']) $error[] = 'e_requirements';
	if(user::data('level') < $quest['level_required']) $error[] = 'e_level';
	if(user::data('quest') || user::data('quest_count')) $error[] = 'e_ongoing_quest';
	if(db::count("quest_log WHERE user = ? AND quest = ?", array(user::data('id'), $quest['id'])) >= $quest['count']) $error[] = 'e_quest_count';
	if(!user::data('stamina')) $error[] = 'e_stamina';
	if(!user::data('health')) $error[] = 'e_health';
	
	if(empty($error))
	{
		// Decrease stamina
		db::query("UPDATE users SET stamina = stamina - 1 WHERE id = ?", array(user::data('id')));
	
		// Quest where money is discounted and completion time is 0
		if($quest['resource'] == 'money' && !$quest['completion_time'])
		{
			// Check for resources
			user::money(-$quest['resource_amount']);
			
			// Add reward
			$exp = round(($quest['experience_gained']/100)*user::max_exp());
			
			user::exp($exp);
			user::money($quest['money_gained']);
			
			// Add badge
			user::badge('finished_quests', 1);
			
			// Add quest log
			db::insert('quest_log', array('user' => user::data('id'), 'time' => time(), 'quest' => $quest['id']));
			db::query("UPDATE users SET finished_quests = finished_quests + 1 WHERE id = ?", array(user::data('id')));
				
			// Display success message
			if($quest['money_gained'] && $quest['experience_gained'])
			{
				$success = lang('quest_done_money_exp', array('quest' => $quest['title'], 'money' => format_numbers($quest['money_gained']), 'experience' => format_numbers($quest['experience_gained']/100*user::max_exp())));	
			}
			
			if($quest['money_gained'] && !$quest['experience_gained'])
			{
				$success = lang('quest_done_money', array('quest' => $quest['title'], 'money' => format_numbers($quest['money_gained'])));			
			}
			
			if(!$quest['money_gained'] && $quest['experience_gained'])
			{
				$success = lang('quest_done_exp', array('quest' => $quest['title'], 'experience' => format_numbers($quest['experience_gained']/100*user::max_exp())));	
			}		
		}
		
		// Quest where credit is discounted and completion time is 0
		if($quest['resource'] == 'credit' && !$quest['completion_time'])
		{
			// Check for resources
			db::query("UPDATE users SET credit = credit - ? WHERE id = ?", array($quest['resource_amount'], user::data('id')));
			
			// Add reward
			$exp = round(($quest['experience_gained']/100)*user::max_exp());
			
			user::exp($exp);
			user::money($quest['money_gained']);
			
			// Add badge
			user::badge('finished_quests', 1);
			
			// Add quest log
			db::insert('quest_log', array('user' => user::data('id'), 'time' => time(), 'quest' => $quest['id']));
			db::query("UPDATE users SET finished_quests = finished_quests + 1 WHERE id = ?", array(user::data('id')));
			
			// Display success message
			if($quest['money_gained'] && $quest['experience_gained'])
			{
				$success = lang('quest_done_money_exp', array('quest' => $quest['title'], 'money' => format_numbers($quest['money_gained']), 'experience' => format_numbers($quest['experience_gained']/100*user::max_exp())));	
			}
			
			if($quest['money_gained'] && !$quest['experience_gained'])
			{
				$success = lang('quest_done_money', array('quest' => $quest['title'], 'money' => format_numbers($quest['money_gained'])));			
			}
			
			if(!$quest['money_gained'] && $quest['experience_gained'])
			{
				$success = lang('quest_done_exp', array('quest' => $quest['title'], 'experience' => format_numbers($quest['experience_gained']/100*user::max_exp())));	
			}		
		}
		
		// Quest where resource is only checked and completion time is 0
		if($quest['resource'] != 'credit' && $quest['resource'] != 'money' && !$quest['completion_time'])
		{
			// Add reward
			$exp = round(($quest['experience_gained']/100)*user::max_exp());
			
			user::exp($exp);
			user::money($quest['money_gained']);
			
			// Add badge
			user::badge('finished_quests', 1);
			
			// Add quest log
			db::insert('quest_log', array('user' => user::data('id'), 'time' => time(), 'quest' => $quest['id']));
			db::query("UPDATE users SET finished_quests = finished_quests + 1 WHERE id = ?", array(user::data('id')));
			
			// Display success message
			if($quest['money_gained'] && $quest['experience_gained'])
			{
				$success = lang('quest_done_money_exp', array('quest' => $quest['title'], 'money' => format_numbers($quest['money_gained']), 'experience' => format_numbers($quest['experience_gained']/100*user::max_exp())));	
			}
			
			if($quest['money_gained'] && !$quest['experience_gained'])
			{
				$success = lang('quest_done_money', array('quest' => $quest['title'], 'money' => format_numbers($quest['money_gained'])));			
			}
			
			if(!$quest['money_gained'] && $quest['experience_gained'])
			{
				$success = lang('quest_done_exp', array('quest' => $quest['title'], 'experience' => format_numbers($quest['experience_gained']/100*user::max_exp())));	
			}		
		}
		
		// Quest where resource is only checked but completion time exists
		if($quest['completion_time'])
		{
			if($quest['resource'] == 'money')
			{
				user::money(-$quest['resource_amount']);
			}
			
			if($quest['resource'] == 'credit')
			{
				db::query("UPDATE users SET credit = credit - ? WHERE id = ?", array($quest['resource_amount'], user::data('id')));
			}			
		
			// Add starting time and quest ID
			db::query("UPDATE users SET quest = ?, quest_count = ? WHERE id = ?", array($quest['id'], time()+$quest['completion_time']*60, user::data('id')));
			
			$success = lang('quest_started');
		}
	}
}

// Collect reward
if(fw::route(1) == 'collect' && user::data('quest') && user::data('quest_count') <= time())
{
	$quest = db::query("SELECT * FROM quests WHERE id = ?", array(user::data('quest')))->fetch();
	
	if(user::data('quest_count') <= time())
	{
		// Add reward
		$exp = round(($quest['experience_gained']/100)*user::max_exp());
		
		user::exp($exp);
		user::money($quest['money_gained']);
		
		// Add badge
		user::badge('finished_quests', 1);
		
		// Add quest log
		db::insert('quest_log', array('user' => user::data('id'), 'time' => time(), 'quest' => $quest['id']));
		
		// Clear cache
		db::query("UPDATE users SET finished_quests = finished_quests + 1, quest = 0, quest_count = 0 WHERE id = ?", array(user::data('id')));
		
		// Display success message
		if($quest['money_gained'] && $quest['experience_gained'])
		{
			$success = lang('quest_done_money_exp', array('quest' => $quest['title'], 'money' => format_numbers($quest['money_gained']), 'experience' => format_numbers($quest['experience_gained']/100*user::max_exp())));	
		}
		
		if($quest['money_gained'] && !$quest['experience_gained'])
		{
			$success = lang('quest_done_money', array('quest' => $quest['title'], 'money' => format_numbers($quest['money_gained'])));			
		}
		
		if(!$quest['money_gained'] && $quest['experience_gained'])
		{
			$success = lang('quest_done_exp', array('quest' => $quest['title'], 'experience' => format_numbers(round($quest['experience_gained']/100*user::max_exp()))));	
		}		
	}
}