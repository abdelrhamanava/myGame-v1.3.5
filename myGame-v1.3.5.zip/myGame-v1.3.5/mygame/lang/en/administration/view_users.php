<?php
fw::$lang = array_merge(fw::$lang, array
(
	'view_users' => 'View users',
	'ip' => 'IP',
	'date_added' => 'Date added',
	
	
));