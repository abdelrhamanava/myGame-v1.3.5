<?php
fw::$lang = array_merge(fw::$lang, array
(
	'title' => 'Title',
	'content' => 'Content',
	'date_added' => 'Date added',
));