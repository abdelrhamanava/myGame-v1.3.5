<?php
fw::$lang = array_merge(fw::$lang, array
(
	'name' => 'Name',
	'type' => 'Type',
	'price' => 'Price',
	'amount' => 'Amount',
	'delete' => 'Delete',
	
	'health' => 'Health refill',
	'stamina' => 'Stamina refill',
	'money' => 'Money',
	'level' => 'Level',
	
));