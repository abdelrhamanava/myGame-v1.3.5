<?php
fw::$lang = array_merge(fw::$lang, array
(
	'name' => 'Name',
	'type' => 'Type',
	'period' => 'Period (in hours)',
	'reputation' => 'Reputation',
	'count' => 'Amount required',
	
	'items' => 'Items',
	'win_ratio' => 'Win ratio',
	'special_items' => 'Special items',
	'team_deathmatch' => 'Team deathmatch',
	'deathmatch' => 'Deathmatch',
	'money' => 'Money',
	'level' => 'Level',
	'work' => 'Worked days',	
	'finished_quests' => 'Finished quests',
));