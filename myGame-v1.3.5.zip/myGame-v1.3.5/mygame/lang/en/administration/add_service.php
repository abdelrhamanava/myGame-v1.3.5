<?php
fw::$lang = array_merge(fw::$lang, array
(
	'name' => 'Title',
	'price' => 'Price (credits)',
	'amount' => 'Amount',
	'type' => 'Type',
	'money' => 'Money',
	'level' => 'Level',
	'health' => 'Health',
	'stamina' => 'Stamina',
	'e_insert' => 'You must choose an amount.',
	'service_has_been_added' => 'Service has been successfully added!',
	
));