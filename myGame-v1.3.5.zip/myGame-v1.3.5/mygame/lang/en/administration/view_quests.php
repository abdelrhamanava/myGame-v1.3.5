<?php
fw::$lang = array_merge(fw::$lang, array
(
	'required_resource' => 'Required resource',
	'completion_time' => 'Completion time',
	'level' => 'Level required',
	'money_gained' => 'Money gained',
	'experience_gained' => 'Experience gained',
	
));