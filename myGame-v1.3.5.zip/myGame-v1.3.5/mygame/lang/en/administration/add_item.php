<?php
fw::$lang = array_merge(fw::$lang, array
(
	'notification' => 'File size limit {size} MB.',
	'upload_images' => 'Upload images',
	'computer' => 'Computer',
	'web' => 'Web',
	'start' => 'Start',
	'cancel' => 'Cancel',
	'list_empty' => 'Upload queue empty',
	
	'error_url' => 'Invalid URL inserted',
	'error_type' => 'Invalid file type',
	'error_size' => 'File is too large, max size: {size} MB.',
	'error_amount' => '{amount} uploads at once allowed',
	'error_dim' => 'Image dimensions too large, max {dimensions}',	
	
	'weapons' => 'Weapons',
	'defense' => 'Defense items',
	'extra' => 'Extra items',
	'special' => 'Special items',
	'stamina' => 'Stamina',
	'health' => 'Health',
	'experience' => 'Experience',
	
	'name' => 'Title',
	'price' => 'Price',
	'effect' => 'Effect',
	'required_level' => 'Required level',
	'category' => 'Category',
	'type' => 'Type',
	'special' => 'Special',
	'e_image' => 'You must upload an image.',
	'e_type' => 'You must choose a type.',
	
	
	'item_has_been_added' => 'Item has been successfully added!',
	
	
));