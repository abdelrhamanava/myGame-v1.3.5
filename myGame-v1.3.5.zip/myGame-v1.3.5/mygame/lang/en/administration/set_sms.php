<?php
fw::$lang = array_merge(fw::$lang, array
(
	'sms_info' => 'Additional info to display before sending the SMS',
	'fortumo_api' => 'Fortumo service ID (for example: f389986c98v301ff196ie9309e8e871e)',
	'fortumo_secret' => 'Fortumo service secret (for example: 01g44339f21b668e6b4f365ac335416f)',
	'sms_service' => 'Set SMS service',
	'e_link_not_correct' => 'Inserted ID is incorrect.',
	'credit_amount' => 'Credit amount',
	'e_link_doesnt_exist' => 'File not found.',
	'Edited' => 'SMS service data has been successfully configured.',
	'configuration' => 'Configuration',
	
));