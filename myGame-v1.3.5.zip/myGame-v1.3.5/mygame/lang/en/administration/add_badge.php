<?php
fw::$lang = array_merge(fw::$lang, array
(
	'notification' => 'File size limit {size} MB.',
	'upload_images' => 'Upload images',
	'computer' => 'Computer',
	'web' => 'Web',
	'start' => 'Start',
	'cancel' => 'Cancel',
	'list_empty' => 'Upload queue empty',
	
	'error_url' => 'Invalid URL inserted',
	'error_type' => 'Invalid file type',
	'error_size' => 'File is too large, max size: {size} MB.',
	'error_amount' => '{amount} uploads at once allowed',
	'error_dim' => 'Image dimensions too large, max {dimensions}',	
	
	'items' => 'Items',
	'win_ratio' => 'Win ratio',
	'special_items' => 'Special items',
	'team_deathmatch' => 'Team deathmatch',
	'deathmatch' => 'Deathmatch',
	'money' => 'Money',
	'level' => 'Level',
	'work' => 'Worked days',
	'finished_quests' => 'Finished quests',
	
	'name' => 'Title',
	'count' => 'Amount required',
	'reputation' => 'Reputation gained',
	'period' => 'Period (in hours)',
	'type' => 'Type',
	'add_badge' => 'Add badge',
	'e_image' => 'You must upload an image.',
	'badge_has_been_added' => 'Badge has been successfully added!',
	
	
));