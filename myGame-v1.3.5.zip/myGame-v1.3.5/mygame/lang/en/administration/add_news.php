<?php
fw::$lang = array_merge(fw::$lang, array
(
	'content' => 'Content',
	'add' => 'Add',
	'added' => 'News article added!',
));