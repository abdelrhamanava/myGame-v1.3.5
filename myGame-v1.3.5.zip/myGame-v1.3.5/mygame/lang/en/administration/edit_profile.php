<?php
fw::$lang = array_merge(fw::$lang, array
(
	'edit_profile' => 'Edit profile',
	'user_edited_successfully' => 'User has been edited successfully.',
	'password_confirm' => 'Confirm password',
	
	'e_username_taken' => 'Username is already chosen.',
	'e_username_length' => 'Username length must be between 3 and 12 characters.',	
	'e_repeat_password' => 'Confirm your password.',
	'e_insert_username' => 'Please insert an username.',	
));