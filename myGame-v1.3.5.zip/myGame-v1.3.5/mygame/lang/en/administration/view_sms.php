<?php
fw::$lang = array_merge(fw::$lang, array
(
	'number' => 'Phone number',
	'ad' => 'Ad',
	'date_sent' => 'Date sent',
));