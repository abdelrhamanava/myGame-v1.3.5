<?php
fw::$lang = array_merge(fw::$lang, array
(	
	'add_quest' => 'Add quest',
	'quest_has_been_added' => 'Quest has been successfully added!',
	
	'name' => 'Title',
	'count' => 'Times to perform',
	'experience_gained' => 'Experience gained (0 - 100%)',
	'money_gained' => 'Money gained',
	'completion_time' => 'Completion time (minutes)',
	'level_required' => 'Level required',
	'required_resource' => 'Required resource',
	'credit' => 'Credit',
	'finished_quests' => 'Finished quests',
	'required_resource_amount' => 'Required resource amount',
	'e_choose_reward' => 'Choose a reward',
	
));