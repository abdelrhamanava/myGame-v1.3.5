<?php
fw::$lang = array_merge(fw::$lang, array
(
	'name' => 'Name',
	'special' => 'Special',
	'effect' => 'Effect',
	'price' => 'Price',
	'level' => 'Level',
	
	'stamina' => 'Stamina',
	'health' => 'Health',
	'experience' => 'Experience',
	'exp' => 'Experience',
	
));