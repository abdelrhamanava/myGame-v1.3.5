<?php
fw::$lang = array_merge(fw::$lang, array
(
	# Contact
	'contact'	=>	'Contact',
	'subject' => 'Subject',
	'mail' => 'Mail',
	'message' => 'Message',
	'send' => 'Send',
	
	'e_subject_length' => 'Subject length must be between 3 and 30 characters',
	'e_subject_alphanumberic' => 'Subject must consist of common characters only',
	'e_message_length' => 'Message length must be between 3 and 3 000 characters',
	'e_message_alphanumberic' => 'Message must consist of common characters only',
	'e_invalid_email' => 'Invalid email',
	'e_mail_spam' => 'To prevent spam, we only allow to send 1 email per day',
	'mail_sent' => 'Mail has been successfully sent!',
	
));