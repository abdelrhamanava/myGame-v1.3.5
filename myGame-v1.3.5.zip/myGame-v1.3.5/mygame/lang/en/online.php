<?php
fw::$lang = array_merge(fw::$lang, array
(
	'online_users' => 'Online users',
	'online_users_text' => 'Under this section are displayed active users.',
	
));