<?php
fw::$lang = array_merge(fw::$lang, array
(
	'change_pw' => 'Change password',
	'mail' => 'Mail',
	'code' => 'Code',
	'new_password' => 'New password',
	'repeat_new_password' => 'Repeat new password',
	
	'e_invalid_code' => 'The code you inserted is invalid.',
	'e_password_match' => 'Passwords do not match.',
	'e_password_length' => 'Password must atleast be 6 characters long.',
	'e_password_alpha' => 'Password must consist of letters and numbers.',
	'e_password_all_lowercase' => 'Password must contain at least one capital letter.',
	'password_set' => 'Password has been set!',
	
));