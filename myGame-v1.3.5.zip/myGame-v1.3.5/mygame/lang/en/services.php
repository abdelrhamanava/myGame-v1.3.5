<?php
fw::$lang = array_merge(fw::$lang, array
(
	'choose_country' => 'Choose country',
	'order_credit' => 'Order credit',
	'your_credit' => 'Your credit',
	'sms_content' => 'SMS content',
	'sms_number' => 'SMS number',
	'sms_price' => 'SMS price',
	'sms_country' => 'SMS country',
	'not_right_country' => 'Incorrect country?',
	'price' => 'Using this service costs {price} credit points.',
	'order' => 'Order',
	'e_service' => 'This service does not exist.',
	'e_credit' => 'You do not have enough credit to order this service.',
));