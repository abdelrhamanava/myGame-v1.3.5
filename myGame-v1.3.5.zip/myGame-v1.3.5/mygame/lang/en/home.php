<?php
fw::$lang = array_merge(fw::$lang, array
(
	
	
));