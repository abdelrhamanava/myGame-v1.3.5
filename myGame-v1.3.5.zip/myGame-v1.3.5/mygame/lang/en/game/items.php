<?php
fw::$lang = array_merge(fw::$lang, array
(
	'equipped' => 'Equipped',
	'equipped_help' => 'Here are shown your equipped items.',
	'unequip' => 'unequip',
	'equip' => 'equip',
	'sell' => 'Sell',
	
	'inventory' => 'Inventory',
	'inventory_help' => 'Here are shown your unequipped items.',
	'price' => 'Price',
	
));