<?php
fw::$lang = array_merge(fw::$lang, array
(
	'recover_help' => 'This is the place where you can refill your stamina and health.',
	'recover_health' => 'Recover health',
	'recover_stamina' => 'Recover stamina',
	'health_recovery' => 'Filling up your health will cost you {health_cost}.',
	'stamina_recovery' => 'Filling up your stamina will cost you {stamina_cost}.',
	'heal' => 'Heal',	
	'rest' => 'Rest',
	
	'e_max_health' => 'Your health is already at maximum.',
	'e_max_stamina' => 'Your stamina is already at maximum.',
	'e_insufficient_funds' => 'You do not have enough money.',
));