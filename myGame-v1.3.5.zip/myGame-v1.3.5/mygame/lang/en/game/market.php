<?php
fw::$lang = array_merge(fw::$lang, array
(
	'nothing_here' => 'No items are being sold.',
	'summary' => 'There are a total of {total_items} being sold.',
	'click_action' => 'Click on an item to buy or remove.',
	'required_level' => 'Required level',
	'effect' => 'Effect',
	'price' => 'Price {price}<br/>Original {initial_price}',	
));