<?php
fw::$lang = array_merge(fw::$lang, array
(
	'switch_category' => 'Choose a category',
	'weapons' => 'Weapons',
	'defense' => 'Defense',
	'special' => 'Special items',
	'extra' => 'Extra items',
	'click_to_buy' => 'Click on an item to buy.',	
	'rest' => 'Rest',
	
	'e_max_health' => 'Your health is already at maximum.',
	'e_max_stamina' => 'Your stamina is already at maximum.',
	'e_insufficient_funds' => 'You do not have enough money.',
));