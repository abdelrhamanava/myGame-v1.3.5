<?php
fw::$lang = array_merge(fw::$lang, array
(
	'rooms' => 'Rooms',
	'nothing_here' => 'No rooms found.',
	'summary' => 'We have {total_playing} playing in {active_rooms} rooms.',
	'average_level' => 'Average level',
	'player_count' => '{current_players} players out of {max_players}',
	'bet' => 'Bet',
	'team_deathmatch' => 'Team deathmatch',
	'deathmatch' => 'Deathmatch',
	
));