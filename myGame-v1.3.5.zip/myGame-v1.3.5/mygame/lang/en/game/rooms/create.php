<?php
fw::$lang = array_merge(fw::$lang, array
(
	'name' => 'Name',
	'bet' => 'Bet',
	'players' => 'Maximum players',
	'game_type' => 'Game type',
	'create' => 'Create',
	
	'e_insufficient_funds' => 'You do not have enough money to place a bet that high.',
	'e_negative_number' => 'Bet has to be a positive number.',
	'e_player_amount_doesnt_exist' => 'Player amount does not exist.',
	'e_game_type_doesnt_exist' => 'Game type does not exist.',
	'e_health' => 'You do not have enough health to open up a room.',
	'e_type' => 'Type and player amount mismatch.',
	'2_players' => '2 players',
	'3_players' => '3 players',
	'4_players' => '4 players',
	'deathmatch' => 'Deathmatch',
	'team_deathmatch' => 'Team deathmatch',
	'create_room' => 'Create a room',
	
));