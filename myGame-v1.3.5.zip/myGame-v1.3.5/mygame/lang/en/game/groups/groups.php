<?php
fw::$lang = array_merge(fw::$lang, array
(
	'group' => 'Group',
	'date' => 'Created on',
	'groups' => 'Groups',
	'summary' => 'There are a total of {total_groups} groups.',
	'create_group' => 'Create a group',
	
	
));