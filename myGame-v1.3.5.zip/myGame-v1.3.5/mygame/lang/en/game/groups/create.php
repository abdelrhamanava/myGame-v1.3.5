<?php
fw::$lang = array_merge(fw::$lang, array
(
	'creating_info' => 'Creating a group will cost {price} and requires your level to be at least {level} or higher.',
	'create_group' => 'Create a group',
	'title' => 'Title',
	'description' => 'Description',
	'create' => 'Create',
	
	'e_group_name_exists' => 'This exact group title already exists.',
	'e_money' => 'You do not have enough money.',
	'e_in_group' => 'You can not create a group while being a member of a group.',
	'e_level' => 'Your level is not high enough.',
	
));