<?php
fw::$lang = array_merge(fw::$lang, array
(
	'owner' => 'Owner',
	'created' => 'Created',
	'experience_earned' => 'Experience earned',
	'joined' => 'Joined on',
	'edit_group' => 'Edit group',
	'join_group' => 'Join group',
	'leave_group' => 'Leave group',
	'cancel_request' => 'Cancel request',
	
	'application_sent' => 'Application sent on',
	'accept' => 'Accept',
	'deny' => 'Deny',
	
));