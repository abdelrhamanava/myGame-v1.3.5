<?php
fw::$lang = array_merge(fw::$lang, array
(
	'last_login' => 'Last login',
	'last_login_ip' => 'Last login IP',
	'not_available' => 'Unavailable',
	'credit' => 'Credit',
	
	'log' => 'Log',
	'clean_log' => 'Clean log',
	'item_bought' => 'Your item {item} was bought by {user} for {price}.',
	'special_item' => 'You recieved a special item {item} for winning a fight.',
	'group_deleted' => 'Your group {group} has been deleted.',
	'group_accepted' => 'Group {group} accepted you as a member.',
	'group_denied' => 'Group {group} denied your application for becoming a member.',
	'group_kick' => "You have been kicked from the group {group}.",
));