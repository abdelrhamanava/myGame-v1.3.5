<?php
fw::$lang = array_merge(fw::$lang, array
(
	'work' => 'Work',
	'what_is' => 'What is',
	'working' => 'You are currently working, wait until work is done and collect your reward.',
	'work_done' => 'Work is done! You earned {amount} money.',
	'collect_reward' => 'Click here to collect your reward',
	'answer' => 'Answer',
));