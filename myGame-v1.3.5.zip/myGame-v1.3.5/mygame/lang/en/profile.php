<?php
fw::$lang = array_merge(fw::$lang, array
(
	'mute_user' => 'Mute user',
	'time' => 'period',
	'reason' => 'Reason',
	'ban_user' => 'Ban user',
	'ban' => 'Ban',
	'unban' => 'Unban',
	'unmute' => 'Unmute',
	'mute' => 'Mute',
	'e_admin_user' => 'You can not ban other administrators.',
	'user_banned' => 'User banned.',
	'user_muted' => 'User muted.',
	
	'registered' => 'Registered',
	'last_active' => 'Last active',
	'send_message' => 'Send a message',
	
	'market_items' => 'Market items',
	'nothing_here' => 'No items.',
	'summary' => 'Total of {total_items} items.',
	'click_action' => 'Click to buy or remove item.',
	
	
));