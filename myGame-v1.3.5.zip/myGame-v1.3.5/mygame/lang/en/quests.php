<?php
fw::$lang = array_merge(fw::$lang, array
(
	'quests' => 'Quests',
	'quests_info' => 'This is the place where you can perform quests. Quests will earn you money or experience.',
	'level_required' => 'You need to be at least level {level} to perform this quest.',
	'completion_time' => 'Performing this quest will take {time} minutes.',
	'experience_gained' => 'This quest will reward you with <strong>{experience}</strong>% of your maximum experience points.',
	'money_gained' => 'This quest will reward you with <strong>{money}</strong> money.', 
	'experience_money_gained' => 'This quest will reward you with <strong>{experience}</strong> % of your maximum experience points & <strong>{money}</strong> money.',
	'perform' => 'Perform',
	'resource_required' => 'Your <strong>{resource}</strong> has to be at least <strong>{amount}</strong> or higher to perform this quest.',
	'quest_done_money_exp' => 'Quest "{quest}" has been performed. You earned {experience} experience points & {money} money.',
	'quest_done_money' => 'Quest "{quest}" has been performed. You earned {money} money.',
	'quest_done_exp' => 'Quest "{quest}" has been performed. You earned {experience} experience points.',
	'quest_started' => 'Quest has been started.',
	
	'e_quest' => 'Quest does not exist.',
	'e_requirements' => 'All requirements to perform this quest have not been met.',
	'e_level' => 'Your level is not high enough.',
	'e_ongoing_quest' => 'You are already performing a quest.',
	'e_quest_count' => 'This quest has been completed.',
	'e_stamina' => 'You do not have enough stamina.',
	
	'collect_reward' => 'Collect reward',
	'e_health' => 'You do not have enough health.',
	
));