<?php
fw::$lang = array_merge(fw::$lang, array
(
	'mailbox' => 'Mailbox',
	'subject' => 'Subject',
	'sender' => 'Sender',
	'status' => 'Status',
	'unread' => 'Unread',
	'read' => 'Read',
	'date' => 'Sent',
	
));