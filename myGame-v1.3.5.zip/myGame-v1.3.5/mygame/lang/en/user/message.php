<?php
fw::$lang = array_merge(fw::$lang, array
(
	'info' => 'Info',
	'sender' => 'Sender',
	'recipient' => 'Recipient',
	'status' => 'Status',
	'unread' => 'Unread',
	'read' => 'Read',
	'date' => 'Sent',
	'reply' => 'Reply',
	
));