<?php
fw::$lang = array_merge(fw::$lang, array
(
	'send_message' => 'Send a message',
	'subject' => 'Subject',
	'message' => 'Message',
	'send' => 'Send',
	
	'e_sender' => 'You can not send a message to yourself.',
	'e_to' => 'Please choose who you want to send this message to.',

	'reply' => 'Reply',
));