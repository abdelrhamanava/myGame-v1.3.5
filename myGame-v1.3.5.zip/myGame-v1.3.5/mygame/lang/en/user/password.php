<?php
fw::$lang = array_merge(fw::$lang, array
(
	'change_password' => 'Change password',
	'current_password' => 'Current password',
	'new_password' => 'New password',
	'repeat_new_password' => 'Repeat new password',
	
	'e_password_match' => 'Passwords do not match.',
	'e_current_password' => 'Your current password is not correct.',	
));