<?php
// Configuration
foreach(db::query('SELECT `key`, `value` FROM configuration ORDER BY `key` DESC') as $element)
{
	$configuration[$element['key']] = $element['value'];
}

define('TITLE', $configuration['title']);

fw::set_config(array(
	'title'			=>	$configuration['title'],
	'url'			=>	$configuration['url'],
	'mail'			=>	$configuration['mail'],
	'tags'			=>	$configuration['tags'],
	'description'	=>	$configuration['description'],
	'style' 		=>	$configuration['style'],
	'ad' 			=> 	$configuration['ad'],
	'head'		 	=> 	$configuration['head'],
	'lang' 			=> 	$configuration['lang'],

	'dimensions'	=>	$configuration['dimensions'],
	'file_limit'	=>	$configuration['file_limit'],
	'upload_limit' 	=>	1,
	
	'failed_logins' 	=> 	$configuration['failed_logins'],
	'interval' 			=> 	$configuration['interval'],
	'starting_points' 	=>	$configuration['starting_points'],
	'earning_points' 	=> 	$configuration['earning_points'],
	'health_cost' 		=> 	$configuration['health_cost'],
	'stamina_cost' 		=> 	$configuration['stamina_cost'],
	'starting_money' 	=> 	$configuration['starting_money'],
	'health_increase' 	=> 	$configuration['health_increase'],
	
	'work' 				=> 	$configuration['work'],
	'working_time' 		=> 	$configuration['working_time'],
	'working_payment' 	=> 	$configuration['working_payment'],
	
	'luck' 				=> 	$configuration['luck'],
	
	'fortumo_api'		=> 	$configuration['fortumo_api'],	
	'fortumo_secret'	=> 	$configuration['fortumo_secret'],		
	'sms_info'			=>	$configuration['sms_info'],
	
	'quests' 			=> 	$configuration['quests'],	
	'allow_groups'		=>	$configuration['allow_groups'],
	'group_creating_tax'=>	$configuration['group_creating_tax'],
	'group_creating_level' => $configuration['group_creating_level'],
	'group_exp_interest' => $configuration['group_exp_interest'],	
));
