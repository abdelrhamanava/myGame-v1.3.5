<?php
require_once '../fw/main.php';
require_once CWEB.'/fw/mysql.php';
require_once CWEB.'config/db.php';

db::init('mysql', DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once CWEB.'config/main.php';

// Check that the request comes from Fortumo server
if(!in_array($_SERVER['REMOTE_ADDR'], array('81.20.151.38', '81.20.148.122', '79.125.125.1', '209.20.83.207')))
{
	die("Error: Unknown error, please contact support team.");
}
  
$secret = fw::config('fortumo_secret');

if(empty($secret) || !check_signature($_GET, $secret)) 
{
	header("HTTP/1.0 404 Not Found");
	die("Error: Invalid signature");
}

$sender = $_GET['sender'];	# Phone
$amount = $_GET['amount']; # Credit
$cuid = $_GET['cuid']; # User id
$payment_id = $_GET['payment_id']; # Unique ID

$user = db::query("SELECT * FROM users WHERE id = ?", array($cuid))->fetch();

if($user['id'] && !preg_match("/failed/i", $_GET['status']))
{
	db::query("UPDATE users SET credit = credit + ? WHERE id = ?", array($amount, $user['id']));
	
	db::insert("sms",
		array(
			'number'	=>	$sender,
			'user'		=>	$user['id'],
			'time'		=>	time(),
			'amount' 	=> $amount,
		)
	);
}

// Respond to user
if(!$user['id'] || preg_match("/failed/i", $_GET['status']))
{
	$reply = "Your request could not be completed. Please send a correct SMS.";
} else
{
	$reply = "We thank you for using our services. Your user's credit balance has been increased.";
}

echo($reply);

function check_signature($params_array, $secret) 
{
	ksort($params_array);

	$str = '';
	
	foreach ($params_array as $k=>$v) 
	{
		if($k != 'sig') 
		{
			$str .= "$k=$v";
		}
	}
	$str .= $secret;
	$signature = md5($str);

	return ($params_array['sig'] == $signature);
}