<?php
abstract class user
{
	public static function login($id)
	{
		$user = @db::query("SELECT * FROM users WHERE id=?", array($id))->fetch();
		
		if(isset($user['id']) && @$user['id'])
		{
			db::query("UPDATE users SET ip = ? WHERE id = ?", array($_SERVER['REMOTE_ADDR'], $user['id']));
			set_cookie('user', md5($user['password'].$user['id'].$_SERVER['REMOTE_ADDR'].SECRET2).$user['id'].md5(SECRET3), 1);
		}
	}
	
	public static function data($value)
	{
		if(isset($_COOKIE['user']))
		{
			$id = substr(get_cookie('user'), 32, -32);
			$user = @db::query("SELECT * FROM users WHERE id=?", array($id))->fetch();
			
			if(substr(get_cookie('user'), 0, 32) != md5($user['password'].$user['id'].$_SERVER['REMOTE_ADDR'].SECRET2))
			{
				self::leave();
			}
			
			$data = $user[$value];
			if(!isset($data)) $data = 'No_data';
			
			return $data;
		} else 
		{
			return 'No_data';
		}
	}
	
	public static function online()
	{
		$online = 0;
		if(is_numeric(self::data('id'))) $online = 1;
		
		return $online;
	}
	
	public static function leave()
	{
		if(isset($_COOKIE['user']))
		{	
			delete_cookie('user');
		}
	}
	
	public static function authentication()
	{
		if(isset($_COOKIE['user']))
		{
			db::query("UPDATE users SET last_active = ? WHERE id = ?", array(time(), self::data('id')));
		
			if(substr(get_cookie('user'), 0, 32) != md5(self::data('password').self::data('id').self::data('ip').SECRET2))
			{
				self::leave();
			}
		}
	}
	
	public static function max_exp()
	{
		$level = self::data('level');
		
		$return = $level * (150+(25*$level));
		$return = round($return);
		
		return $return;
	}
	
	public static function max_health()
	{
		$health = self::data('max_health');
		
		$return = round($health);
		
		return $return;	
	}
	
	public static function max_stamina()
	{
		$stamina = self::data('max_stamina');
		
		$return = round($stamina);
		
		return $return;	
	}	
	
	public static function money($amount)
	{
		db::query("UPDATE users SET money = money + ? WHERE id = ?", array($amount, self::data('id')));
		
		if($amount > 0)
		{
			self::badge('money', $amount);	
			
			db::query("UPDATE users SET money_gained_day = money_gained_day + ? WHERE id = ?", array($amount, self::data('id')));			
		}
	}
	
	public static function exp($amount)
	{
		if($amount+self::data('exp') < self::max_exp())
		{
			db::query("UPDATE users SET exp = exp + ?, exp_gained_day = exp_gained_day + ? WHERE id = ?", array($amount, $amount, self::data('id')));
		} else
		{
			self::badge('level', 1);
			
			db::query("UPDATE users SET exp = 0, level = level + 1, points = points + ?, exp_gained_day = 0, levels_gained_day = levels_gained_day + 1 WHERE id = ?", array(fw::config('earning_points'), self::data('id')));
		}
		
		if($amount > 0 && db::count("group_members WHERE user = ?", array(self::data('id'))))
		{
			$member = db::query("SELECT * FROM group_members WHERE user = ?", array(self::data('id')))->fetch();
			$group = db::query("SELECT * FROM groups WHERE id = ?", array($member['group']))->fetch();
			
			$exp = round($amount*fw::config('group_exp_interest'))+1;
			
			if($group['exp']+$exp < ($group['level'] * (150+(45*$group['level']))))
			{
				db::query("UPDATE groups SET exp = exp + ? WHERE id = ?", array($exp, $group['id']));
			} else
			{
				db::query("UPDATE groups SET exp = 0, level = level + 1, points = points + 1 WHERE id = ?", array($group['id']));
			}
			
			db::query("UPDATE group_members SET exp = exp + ? WHERE user = ?", array($exp, self::data('id')));
		}
	}
	
	public static function badge($type, $amount)
	{
		db::insert("badge_cache", array('user' => self::data('id'), 'amount' => $amount, 'time' => time(), 'type' => $type));
		
		$count = 0;
		$user_badge = db::query("SELECT * FROM user_badges WHERE user = ? AND type = ? ORDER BY `count` DESC LIMIT 1", array(self::data('id'), $type))->fetch();
		
		if(!empty($user_badge))
		{
			$count = $user_badge['count'];
		}
		
		$badge = db::query("SELECT * FROM badges WHERE type = ? AND `count` > ? ORDER BY `count` ASC LIMIT 1", array($type, $count))->fetch();
		
		if(!empty($badge))
		{		
			if($badge['count'] <= db::query("SELECT SUM(amount) FROM badge_cache WHERE user = ? AND type = ?", array(self::data('id'), $type))->fetchColumn() && !$badge['period'])
			{
				db::insert("user_badges", array('user' => self::data('id'), 'time' => time(), 'type' => $type, 'count' => $badge['count'], 'badge' => $badge['id']));
				db::query("UPDATE users SET reputation = reputation + ? WHERE id = ?", array($badge['reputation'], self::data('id')));
			}
			
			if($badge['count'] <= db::query("SELECT SUM(amount) FROM badge_cache WHERE user = ? AND type = ? AND ".time()."-time < ?", array(self::data('id'), $type, $badge['period']))->fetchColumn() && $badge['period'])
			{
				db::insert("user_badges", array('user' => self::data('id'), 'time' => time(), 'type' => $type, 'count' => $badge['count'], 'badge' => $badge['id']));
				db::query("UPDATE users SET reputation = reputation + ? WHERE id = ?", array($badge['reputation'], self::data('id')));
			}			
		}
	}
}