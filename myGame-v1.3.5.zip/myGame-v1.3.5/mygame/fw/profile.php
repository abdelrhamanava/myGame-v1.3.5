<?php
abstract class profile
{	
	public static function data($id, $value)
	{
		$user = @db::query("SELECT * FROM users WHERE id=?", array($id))->fetch();
				
		$data = $user[$value];
		if(!isset($data)) $data = 'No_data';
		
		return $data;
	}
	
	public static function link($id)
	{				
		$profile = '<a href="'.WEB.'profile/'.self::data($id, 'id').'">'.self::data($id, 'username').'</a>';
		
		return $profile;
	}
	
	public static function avatar($id)
	{
		if(file_exists(CWEB.'upload/avatar/'.self::data($id, 'id').'.png'))
		{
			$return = '<div class="avatar"><img src="'.WEB.'upload/avatar/'.self::data($id, 'id').'.png"></div>';
		} else
		{
			$return = '<div class="avatar"><img alt="avatar" src="'.WEB.'upload/avatar/0.png"></div>';
		}
		
		return $return;
	}	
	
	public static function log($id, $entry)
	{
		db::insert('logs', array('time' => time(), 'user' => $id, 'content' => $entry));
	}
}