<?php
abstract class db
{

	public static $handler;
	
	public static function init($driver, $host, $username, $password, $database)
	{
		try
		{
			self::$handler = new \PDO($driver.':host='.$host.';dbname='.$database, $username, $password);
			self::$handler->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
		} catch(\Exception $e)
		{
			return $e;
		}
	}
		
	public static function query($query, $data=array(), $manual=false)
	{
		try
		{
			$sth = @self::$handler->prepare($query);
			$sth->execute((array) $data);
		} catch(\Exception $e)
		{
			if($manual)
			{
				die('run manually');
			}
			
			$error = $sth->errorInfo();
			$debug = debug_backtrace();
			
			die('Database error:<br/>'.print_r($error));
		}
		
		return $sth;
	}
	
	public static function count($query, $data=array())
	{
		return self::query('SELECT COUNT(*) FROM '.$query, (array) $data)->fetchColumn();		
	}
	
	public static function insert($table, $data=array())
	{
		return self::query('INSERT INTO '.$table.' ('.implode(',', array_keys($data)).') VALUES ('.str_repeat('?,', count($data) - 1).'?)', array_values($data));
	}
	
	public static function last_id()
	{
		return self::$handler->lastInsertId();
	}
	
	public static function quote($string)
	{
		return self::$handler->quote($string);
	}
}