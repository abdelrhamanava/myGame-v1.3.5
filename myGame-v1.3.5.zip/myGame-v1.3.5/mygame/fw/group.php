<?php
class group
{
	public $id;
	
	public function __construct($id=0)
	{		
		if($id)
		{
			if(db::count("groups WHERE id = ?", array($id)))
			{
				$this->id = $id;
			} else
			{
				$this->id = 0;
			}
		} else
		{
			if(db::count("group_members WHERE user = ?", array(user::data('id'))))
			{
				$group = db::query("SELECT * FROM group_members WHERE user = ?", array(user::data('id')))->fetch();
				$id = $id['id'];
				
				$this->id = $id;		
			} else
			{
				$this->id = 0;
			}
		}
	}		

	public function data($value)
	{
		$data = db::query("SELECT * FROM groups WHERE id = ?", array($this->id))->fetch();
		
		if(empty($data))
		{
			$return = 0;
		} else
		{
			$return = $data[$value];
		}
		
		return $return;
	}
	
	public function avatar()
	{
		if(file_exists(CWEB.'upload/group_avatar/'.$this->id.'.png'))
		{
			$return = '<div class="avatar"><img src="'.WEB.'upload/group_avatar/'.$this->id.'.png"></div>';
		} else
		{
			$return = '<div class="avatar"><img alt="avatar" src="'.WEB.'upload/group_avatar/0.png"></div>';
		}
		
		return $return;
	}	

	public function is_member()
	{
		$return = 0;
		
		if(db::count("group_members WHERE user = ? AND `group` = ?", array(user::data('id'), $this->id)) && !db::count("groups WHERE user = ? AND `id` = ?", array(user::data('id'), $this->id)))
		{
			$return = 1;
		}
		
		return $return;
	}
	
	public function is_owner()
	{
		$return = 0;
		
		if(db::count('groups WHERE user = ? AND id = ?', array(user::data('id'), $this->id)) && !$this->is_member())
		{
			$return = 1;
		}
		
		return $return;	
	}
	
	public function leave($id=0)
	{
		if($id): $id = $id; else: $id = user::data('id'); endif; 
	
		db::query("DELETE FROM group_members WHERE user = ? AND `group` = ?", array($id, $this->id));
		
		db::query("UPDATE users SET attack = attack - group_attack, defense = defense - group_defense, endurance = endurance - group_endurance, max_health = max_health - (".(fw::config('health_increase'))." * group_endurance), group_attack = 0, group_defense = 0, group_endurance = 0 WHERE id = ?", array($id));
	}
	
	public function accept($id)
	{	
		db::insert('group_members', array('`group`' => $this->id, 'user' => $id, 'time' => time()));
		db::query('DELETE FROM group_applicants WHERE user = ?', array($id));
		
		db::query("UPDATE users SET attack = attack + ?, defense = defense + ?, endurance = endurance + ?, max_health = max_health + (".(fw::config('health_increase'))." * ?), group_attack = ?, group_defense = ?, group_endurance = ? WHERE id = ?", array($this->data('attack'), $this->data('defense'), $this->data('endurance'), $this->data('endurance'), $this->data('attack'), $this->data('defense'), $this->data('endurance'), $id));
	}
	
	public function deny($id)
	{	
		db::query('DELETE FROM group_applicants WHERE user = ? AND `group` = ?', array($id, $this->id));
	}	

	public function apply()
	{
		db::insert('group_applicants', array('user' => user::data('id'), '`group`' => $this->id, 'time' => time()));
	}
	
	public function point($type)
	{
		if($this->data('points'))
		{
			if($type == 'attack')
			{
				db::query("UPDATE groups SET attack = attack + 1, points = points - 1 WHERE id = ?", array($this->id));
				
				foreach(db::query("SELECT * FROM group_members WHERE `group` = ?", array($this->id)) as $member)
				{
					db::query("UPDATE users SET attack = attack + 1, group_attack = group_attack + 1 WHERE id = ?", array($member['user']));
				}
				
			} else if($type == 'defense')
			{
				db::query("UPDATE groups SET defense = defense + 1, points = points - 1 WHERE id = ?", array($this->id));	

				foreach(db::query("SELECT * FROM group_members WHERE `group` = ?", array($this->id)) as $member)
				{
					db::query("UPDATE users SET defense = defense + 1, group_defense = group_defense + 1 WHERE id = ?", array($member['user']));
				}
				
			} else if($type == 'endurance')
			{
				db::query("UPDATE groups SET endurance = endurance + 1, points = points - 1 WHERE id = ?", array($this->id));		

				foreach(db::query("SELECT * FROM group_members WHERE `group` = ?", array($this->id)) as $member)
				{
					db::query("UPDATE users SET endurance = endurance + 1, max_health = max_health + (".(fw::config('health_increase'))."), group_endurance = group_endurance + 1 WHERE id = ?", array($member['user']));
				}	
				
			}
		}
	}
}