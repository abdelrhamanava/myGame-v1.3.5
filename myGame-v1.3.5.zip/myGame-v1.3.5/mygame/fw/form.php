<?php
class form
{
	public $fields=array(), $name, $error, $submitted, $action, $success, $display_e=array(), $common_e=array();
	
	// Create form
	public function create($fields=array(), $name, $action)
	{		
		$this->fields = $fields;
		$this->action = $action;
		$this->name = $name;
		$this->submitted = false;
		
		if(@$_POST[$this->name])
		{		
			// Check for common errors
			foreach($this->fields as $field=>$value)
			{								
				if(@$value['type'] == 'text' && isset($value['max_length']))
				{
					if(@strlen($_POST[$value['name']]) > $value['max_length']) $this->error[$field] = 'e_max_length';
				}
				
				if(@$value['class'] == 'select')
				{
					if(@$_POST[$value['name']] == 'none' || (empty($_POST[$value['name']]) && !isset($_POST[$value['name']]))) $this->error[$field] = 'e_select_something';
				}
				
				if(@$value['input'] == 'numbers')
				{
					if(!strlen(@$_POST[$value['name']]) && !isset($value['voluntary'])) $this->error[$field] = 'e_length';
					
					if(!is_numeric(@$_POST[$value['name']]) && @strlen($_POST[$value['name']])) $this->error[$field] = 'e_numeric';
					
					if(@$_POST[$value['name']] <= 0 && !isset($value['voluntary'])) $this->error[$field] = 'e_negative_number';
					
					if(@$_POST[$value['name']]) $_POST[$value['name']] = htmlspecialchars($_POST[$value['name']], ENT_QUOTES);
				}
				
				if(@$value['input'] == 'small_text')
				{
					if(strlen($_POST[$value['name']]) < 3 && !isset($value['voluntary'])) $this->error[$field] = 'e_length';	
					
					if(!preg_match('/^([.a-z0-9]*)$/i', $_POST[$value['name']])) $this->error[$field] = 'e_alphanumberic';		
					
					if(@$_POST[$value['name']]) $_POST[$value['name']] = htmlspecialchars($_POST[$value['name']], ENT_QUOTES);
				}	
				
				if(@$value['input'] == 'long_text')
				{
					if(strlen($_POST[$value['name']]) < 3 && !isset($value['voluntary'])) $this->error[$field] = 'e_length';	
					
					if(@$_POST[$value['name']]) $_POST[$value['name']] = htmlspecialchars($_POST[$value['name']], ENT_QUOTES);
				}		
			}
		
			return $this->submitted = true;
		}
	}
	
	// Errors	
	public function error($errors=array())
	{
		$this->errors = $errors;
		$this->display_e = array();
				
		foreach($errors as $error=>$text)
		{
			if(!is_numeric($error) && array_key_exists($error, $this->fields))
			{
				$this->display_e[$error] = lang($text, array('field' => lang($error), 'length' => @$this->fields[$error]['max_length']));
			} else 
			{
				$this->common_e[] = lang($text);
			}
		}
	}
		
	// Successful message
	public function success($message)
	{
		echo '<div class="success">';
		
		echo lang($message);
		
		echo '</div>';
	}
		
	// Show form
	public function display()
	{		
		if(count($this->error) && $this->submitted)
		{
			self::error($this->error);
		}
		
		if(!count($this->error) && $this->submitted && $this->success)
		{
			self::success($this->success);
		}		
		
		// Show common errors
		if($this->common_e)
		{
			foreach($this->common_e as $error=>$text)
			{
				if(is_numeric($error))
				{
					echo '<div class="error">'.$text.'</div>';
				}
			}
		}
	
		$hidden = 1;
		if(isset($_POST[$this->name])) $hidden = $_POST[$this->name];
		
		$action = WEB.$this->action;
		if(strpos($this->action, 'javascript') !== false) $action = $this->action;
	
		echo '<form method="post" action="'.$action.'" enctype="multipart/form-data">';
		
		echo '<input type="hidden" name="'.$this->name.'" value="'.$hidden.'">';
		
		foreach($this->fields as $field=>$value)
		{
			// Choose default value
			$default = '';
			
			if(isset($value['value']) && !isset($_POST[$value['name']])) $default = $value['value'];
			
			if(@$_POST[$value['name']]) $default = $_POST[$value['name']];
			
			// Checkbox value
			$checked = '';
			
			if(isset($value['checked']) && $value['checked'] && !$this->submitted) $checked = 'checked="checked"';
			
			if((@$_POST[@str_replace('[]', '', $value['name'])] == @$value['value'] 
				|| @in_array($value['value'], @$_POST[@str_replace('[]', '', $value['name'])])) 
				&& $this->submitted
			) $checked = 'checked="checked"';
			
			$title = '';
			if(@$value['type'] != 'hidden') $title = lang($field);
			
			// Display title for administration panel
			if(fw::config('style') == 'administration')
			{
				if($value['class'] != 'hidden' & $value['class'] != 'header') echo '<p>'.$title.'</p>';
			}
			
			// Display specific errors
			if($value['class'] != 'header')
			{
				if(isset($this->display_e[$value['name']]))
				{
					echo '<div class="error">'.$this->display_e[$value['name']].'</div>';
				}
			}
			
			// Display form elements
			if($value['class'] == 'input')
			{
				echo '<input placeholder="'.$title.'" class="'.$value['class'].'" type="'.$value['type'].'" name="'.$value['name'].'"'.(isset($value['max_length'])?' maxlength="'.$value['max_length'].'"':'').' value="'.$default.'">';
			}
			
			if($value['class'] == 'checkbox')
			{
				echo '<input class="'.$value['class'].'" type="checkbox" name="'.$value['name'].'" value="'.$value['value'].'" '.$checked.'>';
			}
			
			if($value['class'] == 'header') echo '<h2>'.lang($field).'</h2>';
			
			if($value['class'] == 'textarea' && $value['type'] == 'text')
			{
				echo '<textarea placeholder="'.$title.'" class="'.$value['class'].'" name="'.$value['name'].'"'.(isset($value['max_length'])?' maxlength="'.$value['max_length'].'"':'').'>'.$default.'</textarea>';
			}
			
			if($value['class'] == 'textarea' && $value['type'] == 'bbcode')
			{
				echo '
					<div class="clear"></div>
					<div class="bbcode">
						<a href="javascript:insert(\'[center]'.lang('text').'[/center]\', \''.$value['name'].'\');">
							<img alt="center" src="'.WEB.'style/'.fw::config('style').'/icons/center.png">
						</a>
						<a href="javascript:insert(\'[b]'.lang('text').'[/b]\', \''.$value['name'].'\');">
							<img alt="bold" src="'.WEB.'style/'.fw::config('style').'/icons/b.png">
						</a>
						<a href="javascript:insert(\'[i]'.lang('text').'[/i]\', \''.$value['name'].'\');">
							<img alt="italic" src="'.WEB.'style/'.fw::config('style').'/icons/i.png">
						</a>
						<a href="javascript:insert(\'[u]'.lang('text').'[/u]\', \''.$value['name'].'\');">
							<img alt="underlined" src="'.WEB.'style/'.fw::config('style').'/icons/u.png">
						</a>
						<a href="javascript:insert(\'[color=green]'.lang('text').'[/color]\', \''.$value['name'].'\');">
							<img alt="colored" src="'.WEB.'style/'.fw::config('style').'/icons/color.png">
						</a>
						<a href="javascript:insert(\'[img]'.lang('address').'[/img]\', \''.$value['name'].'\');">
							<img alt="image" src="'.WEB.'style/'.fw::config('style').'/icons/img.png">
						</a>
						<a href="javascript:insert(\'[url=http://www.link.com]'.lang('text').'[/url]\', \''.$value['name'].'\');">
							<img alt="link" src="'.WEB.'style/'.fw::config('style').'/icons/url.png">
						</a>
						<a href="javascript:insert(\'[video]http://www.youtube.com?v=xn3cv1hXCgI[/video]\', \''.$value['name'].'\');">
							<img alt="video" src="'.WEB.'style/'.fw::config('style').'/icons/video.png">
						</a>
					</div>
					<textarea placeholder="'.$title.'" class="'.$value['class'].'" name="'.$value['name'].'"'.(isset($value['max_length'])?' maxlength="'.$value['max_length'].'"':'').'>'.$default.'</textarea>
				';
			}
			
			if($value['class'] == 'select' && $value['options'])
			{
				echo '<select name="'.$value['name'].'">';
				
				echo '<option disabled="disabled" value="none"'.(!isset($default)?' selected="selected"':'').'>'.$title.'</option>';
				
				foreach($value['options'] AS $option=>$key)
				{
					echo '<option value="'.$option.'"'.(($default==$option && $default)?' selected="selected"':'').'>'.$key.'</option>';
				}
				
				echo '</select>';
			}
		}
		
		echo '<input type="submit" class="button" value="'.lang($this->name).'">';
				
		echo '</form>';
	}
}