<?php
define('CWEB', str_replace(basename(dirname(__file__)), '', dirname(__file__)).'');
define('WEB', substr($_SERVER['SCRIPT_NAME'], 0, -15));
define('ROUTE', $_GET['request']);

// Framework
class fw
{	
	// Current page
	public static function route($depth=0)
	{
		$route = explode('/', ROUTE);
		$route = @$route[$depth];
		
		if(!$route) $route = '0';
		
		return $route;
	}
	
	// Menu
	public static $pages=array();
	
	public static function set_menu($additional_pages)
	{
		$pages = func_get_args();
		$pages = array_merge(self::$pages, $additional_pages);

		return self::$pages = $pages;
	}
	
	public static function check_menu()
	{		
		if(!self::$pages[fw::route(0)])
		{
			go('not_available');
		}
	}
	
	// Contents
	public static $files = array();
	public static $php=array(), $html=array(), $js=array(), $vars=array(), $scripts=array();
	
	public static function set_contents($contents=array())
	{
		$files = func_get_args();
		$files = array_merge(self::$files, $contents);
		
		foreach($files AS $file=>$value)
		{
			if($value['type'] == 'php')
			{
				$location = self::$pages;
				self::$php[] = CWEB.'controller/'.$location[$value['location']].'.php';
			} 
			
			if($value['type'] == 'html')
			{
				$location = self::$pages;			
				self::$html[] = CWEB.'view/'.$location[$value['location']].'.html';
			}
			
			if($value['type'] == 'js')
			{
				self::$js[] = WEB.'js/'.$value['location'].'.js';
			}
		}
	}

	public static function script_var($key, $value)
	{
		self::$vars[$key] = $value;
	}
	
	public static function script_line($value)
	{
		self::$scripts[] = $value;
	}	
	
	// Configuration
	public static $config=array();
	
	public static function set_config($values)
	{		
		$config = func_get_args();
		$config = array_merge(self::$config, $values);
								
		return self::$config = $config;
	}
	
	public static function config($data)
	{
		return self::$config[$data];
	}	
	
	// Language
	public static function current_lang()
	{
		if(isset($_COOKIE['lang']))
		{
			$language = $_COOKIE['lang'];
		} else 
		{
			$language = @self::config('lang');
		}
		
		if(empty($language))
		{
			$language = 'en';
		}
	
		return $language;
	}

	public static $lang = array();
	
	public static function lang($files)
	{
		$lang = func_get_args();
		$lang = array_merge(self::$lang, $files);
		
		foreach($lang as $file)
		{
			if(file_exists(CWEB.'lang/'.self::current_lang().'/'.$file.'.php'))
			{
				require_once CWEB.'lang/'.self::current_lang().'/'.$file.'.php';
			}
		}
	}	
}

// Various functions
function go($location)
{
	header('Location: '.WEB.$location);
	
	exit;
}

function golink($location)
{
	return WEB.$location;
}

function lang($key, $replace=null)
{
	$lang = @fw::$lang[$key];
	
	if($replace !== null)
	{
		if(is_array($replace))
		{
			foreach($replace as $tag=>$value) $lang = str_replace('{'.$tag.'}', $value, $lang);
		} 
	}
	
	if(!$lang) $lang = $key;
	
	return $lang;
}

function get_cookie($key)
{
	$cookie = @$_COOKIE[$key];
	if(!isset($_COOKIE[$key])) $cookie = 0;
	
	return $cookie;
}

function set_cookie($name, $value, $time)
{
	setcookie($name, $value, time()+$time*86400, WEB);
}

function delete_cookie($key)
{
	setcookie($key, null, -1, WEB);
}

function format_numbers($number)
{
	$number = number_format($number);
	$number = str_replace(',', ' ', $number);
	
	return $number;
}

function format_date($time)
{
	$time = date('d.m.Y', $time);
	
	return $time;
}

function create_thumbnail($src, $path, $width, $height)
{
	$d = getimagesize($src);

	$func = 'imagecreatefrom'.substr($d['mime'], 6);

	$src = $func($src);
	

	
	$size = array($d[0]*$height/$d[1], $d[1]*$width/$d[0]);

	if($size[0] == $size[1] || $size[0] >= $width)
	{

		$w = $size[0];

		$h = $d[1]*$w/$d[0];

	} else
	{

		$h = $size[1];

		$w = $d[0]*$h/$d[1];

	}

	

	$tmp = imagecreatetruecolor($w, $h);

	imagecopyresampled($tmp, $src, 0, 0, 0, 0, $w, $h, $d[0], $d[1]);

	$cut = array(ceil(($w - $width)/2), ceil(($h - $height)/2));
	

	$thumbnail = imagecreatetruecolor($width, $height);

	imagecopyresampled($thumbnail, $tmp, 0, 0, $cut[0], $cut[1], $width, $height, $w - $cut[0]*2, $h - $cut[1]*2);

	

	return imagepng($thumbnail, $path);
}

function url($url)
{
	$r = Array
	(
		'&' => '',
		' ' => '_',
		'/' => '',
		'<' => '',
		'>' => '',
		'"' => '',
		'(' => '',
		':' => '',
		')' => '',
		'\\' => '',
		'!' => '',
		'=' => '',
		"'" => ''
	);
	
	$url = str_replace(array_keys($r), $r, $url);
	$url = urlencode($url);
	
	return $url;
}

function pages($url, $current, $total, $show=7)
{
	$url = WEB.fw::route(0).'/'.$url;
	$pages = '';
	
	if(empty($current) || $current < 0) $current = 1; else $current++;
	
	$max = ceil($total/$show);
	
	if($current > $max) $current = $max;
	
	if($current > 6)
	{
		$pages .= '<a href="'.sprintf($url, 0).'">1</a><a href="'.sprintf($url, 1).'">2</a><a href="Javascript:void(0);">...</a>';
	} elseif($current > 5)
	{
		$pages .= '<a href="'.sprintf($url, 0).'">1</a><a href="Javascript:void(0);">...</a>';
	}
	
	$low = $current - 3;
	$high = $current + 3;
	
	if($low < 1)
	{
		$low = 1;
		$high = 7;
	}
	
	$num = range($low, $high);
	foreach($num as $p)
	{
		if($p < 1 || $p > $max) continue;
		if($p != $current) $pages .= '<a href="'.sprintf($url, $p-1).'">'.$p.'</a>'; else $pages .= '<a href="Javascript:void(0);" class="active">'.$p.'</a>';
	}
	
	if($current < $max - 7)
	{
		$pages .= '<a href="Javascript:void(0);">...</a><a href="'.sprintf($url, $max-2).'">'.($max-1).'</a><a href="'.sprintf($url, $max-1).'">'.$max.'</a>';
	} elseif($current < $max - 6)
	{
		$pages .= '<a href="Javascript:void(0);">...</a><a href="'.sprintf($url, $max-1).'">'.$max.'</a>';
	}
	
	if($current > 1)
	{
		$prev = '<a class="left_button" href="'.sprintf($url, $current-2).'">'.lang('Previous').'</a>';
	} else
	{
		$prev = '<span class="left_button">'.lang('Previous').'</span>';
	}
	
	if($current < $max)
	{ 
		$next = '<a class="right_button" href="'.sprintf($url, $current).'">'.lang('Following').'</a>';
	} else 
	{
		$next = '<span class="right_button">'.lang('Following').'</span>';
	}
	
	$return = '';
	
	if($total)
	{
		$return = '<table class="pages"><tr><td style="text-align: left;">'.$prev.'</td><td class="num" style="text-align: center;">'.$pages.'</td><td style="text-align: right;">'.$next.'</td></tr></table>';
	}
	
	return $return;
}

function bb_code($string, $hide=0) 
{ 
	$r = Array
	(
		'<' => '&lt;',
		'>' => '&gt;',
		'"' => '&quot;',
		'(' => '&#40;',
		')' => '&#41;',
		'õ' => '&otilde;',
		'ä' => '&auml;',
		'ö' => '&ouml;',
		'ü' => '&uuml;',
		'Õ' => '&Otilde;',
		'Ä' => '&Auml;',
		'Ö' => '&Ouml;',
		'Ü' => '&Uuml;',
		'\\' => '',
		'!' => '&#33;',
		"'" => '&#39;'
	);
	
	$string = str_replace(array_keys($r), $r, $string);

	$tags = 'b|i|u|color|center|url|img|video'; 
	while (preg_match_all('`\[('.$tags.')=?(.*?)\](.+?)\[/\1\]`', $string, $matches)) foreach ($matches[0] as $key => $match)
	{ 
		list($tag, $param, $innertext) = array($matches[1][$key], $matches[2][$key], $matches[3][$key]); 
		switch ($tag) 
		{ 
			case 'b': $replacement = '<span style="font-weight: bold;">'.$innertext.'</span>'; break; 
			case 'i': $replacement = '<span style="font-style: italic;">'.$innertext.'</span>'; break; 
			case 'u': $replacement = '<span style="text-decoration: underline;">'.$innertext.'</span>'; break; 
			case 'color': $replacement = '<span style="color: '.$param.';">'.$innertext.'</span>'; break; 
			case 'center': $replacement = '<div style="text-align: center;">'.$innertext.'</div>'; break; 
			case 'url': $replacement = '<a href="' . ($param? $param : $innertext) . "\">$innertext</a>"; break; 
			case 'img': 
				$replacement = '<img alt="Image" src="'.$innertext.'""/>'; 
				if(substr($innertext, -4) != '.jpg' && substr($innertext, -4) != '.gif' && substr($innertext, -4) != '.png') $replacement = '';				
			break; 
			case 'video': 
				$videourl = parse_url($innertext); 
				parse_str($videourl['query'], $videoquery); 
				if(strpos($videourl['host'], 'youtube.com') !== FALSE) $replacement = '<iframe width="610" height="315" src="http://www.youtube.com/embed/' . $videoquery['v'] . '?rel=0" frameborder="0" allowfullscreen></iframe>';
			break; 
		} 
		
		if($hide) $replacement = '';
		
		$string = str_replace($match, $replacement, $string); 
	} 
	
	if(!$hide) $string = nl2br($string);
	
	return $string; 
} 

function error($errors=array())
{	
	echo '<div class="errors">';
	
	foreach($errors as $error)
	{
		echo '<span>'.lang($error).'</span>';
	}
	
	echo '</div>';
}

function hash_password($password, $salt=null)
{
	$chars = './0123456789abcdefghjiklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$length = strlen($chars);
 
	if(is_null($salt))
	{
		$salt = '';

		for($i=0; $i<22; $i++)
		{
			$salt .= substr($chars, mt_rand(0, $length - 1), 1);
		}

		$salt .= '$';
	}

	return substr(crypt($password, '$2a$07$'.$salt), 7);
}