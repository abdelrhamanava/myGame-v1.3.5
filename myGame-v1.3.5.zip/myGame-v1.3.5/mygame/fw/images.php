<?php
abstract class image
{	
	public static function icon($name, $type='main')
	{
		$return = '<img class="icon" alt="'.$name.'" src="'.WEB.'style/'.fw::config('style').'/icons/'.$type.'/'.$name.'.png">';
		
		return $return;
	}
	
	public static function item($id, $type)
	{
		$item = db::query("SELECT * FROM items_".$type." WHERE id = ?", array($id))->fetch();
	
		$return = '<div class="item"><img alt="'.$item['name'].'" src="'.WEB.'images/items/'.$type.'/'.$id.'.jpg"></div>';

		return $return;
	}
}