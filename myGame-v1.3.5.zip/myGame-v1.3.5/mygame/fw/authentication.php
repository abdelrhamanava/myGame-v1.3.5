<?php
abstract class authentication
{
	public static $register, $login, $request_pw;

	// Register
	public static function register()
	{
		GLOBAL $register;
		
		$register = new form;
		$register->create(array(
			'username' => array(
				'class' => 'input',
				'type' => 'text',
				'input' => 'small_text',
				'name' => 'username',
				'max_length' => '20',
			),
			
			'email' => array(
				'class' => 'input',
				'type' => 'text',
				'input' => 'long_text',
				'name' => 'email',
				'max_length' => '100',
			),	
			
			'password'	=>	array(
				'class' => 'input',
				'type' => 'password',
				'name' => 'password',
			),
			
			'repeat_password'	=>	array(
				'class' => 'input',
				'type' => 'password',
				'name' => 'password_confirm',
			),
		), 'register', fw::route(0));
			
		if($register->submitted)
		{	
			fw::script_line('
				$(function(){
				
					$(".register").show();
					$(".login").hide();
					$(".reminder").hide();
					
				});
			');

			if(db::count('users WHERE username=?', array($_POST['username']))) $register->error[] = 'e_username_taken';
			if($_POST['password'] != $_POST['password_confirm']) $register->error[] = 'e_repeat_password';
			if(!$_POST['password']) $register->error[] = 'e_insert_password';
			
			if(!preg_match('/^\S+@\S+\.\S+$/', $_POST['email'])) $register->error[] = 'e_invalid_email';
			if(db::count('users WHERE email=?', array($_POST['email']))) $register->error[] = 'e_email_exists';
				
			if(db::count('logins WHERE ip = ? AND '.time().'-time < 86400*3', array($_SERVER['REMOTE_ADDR'])) || db::count('logins WHERE ip = ? AND '.time().'-time < 86400*3 AND browser = ? AND lang = ?', array($_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT'], $_SERVER['HTTP_ACCEPT_LANGUAGE']))) $register->error[] = 'e_user_done';
			
			if(!count($register->error))
			{
				$secret_ingredients = 'abcdefghijklmnopqrstuvxyABCDEFGHIJKLMNOPQRSTUVXY1234567890';
				$secret_ingredients = str_split($secret_ingredients);
				
				$code = uniqid();
				
				for($i = 0; $i <= 15; $i++)
				{
					$code .= $secret_ingredients[mt_rand(0, count($secret_ingredients))];
				}		
			
				$admin = 0;
				if(!db::count('users')) $admin = 1;
			
				db::insert('users', 
					array(
						'username'	=>	$_POST['username'],
						'email'		=>	$_POST['email'],
						'password'	=>	md5($_POST['password'].SECRET1),
						'time'		=>	time(),
						'ip'		=>	$_SERVER['REMOTE_ADDR'],
						'admin'		=>	$admin,
						'activation_code' => $code,
						
						'points' 	=>	fw::config('starting_points'),
						'money'		=>	fw::config('starting_money'),				
					)
				);

				$user = db::query("SELECT * FROM `users` WHERE `ip`=? AND `username`=? ORDER BY id DESC LIMIT 1", array($_SERVER['REMOTE_ADDR'], $_POST['username']))->fetch();

				db::insert("logins", array('user' => $user['id'], 'lang' => $_SERVER['HTTP_ACCEPT_LANGUAGE'], 'browser' => $_SERVER['HTTP_USER_AGENT'], 'ip' => $_SERVER['REMOTE_ADDR'], 'time' => time()));
				
				user::login($user['id']);		
						
				go('home');
			}
		}
		
		return $register;
	}
	
	// Login
	public static function login()
	{
		GLOBAL $login;
		
		$login = new form;
		$login->create(array(
				'username' => array('class' => 'input', 'type' => 'text', 'name' => 'user', 'max_length' => '20', 'value' => ''),
				'password'	=>	array('class' => 'input', 'type' => 'password', 'name' => 'pass', 'value' => '')
				), 'login', fw::route(0));
				
		if($login->submitted)
		{
			$user = db::query("SELECT * FROM `users` WHERE `username` = ? AND `password` = ?", array($_POST['user'], md5($_POST['pass'].SECRET1)))->fetch();
			
			if(!$user['id'])
			{
				$login->error[] = 'e_user';
				
				if(!empty($_POST['username']))
				{
					db::insert("logins", array('user' => 0, 'ip' => $_SERVER['REMOTE_ADDR'], 'time' => time()));		
				}
			}
			
			if($user['ban']) $login->error[] = 'e_banned';
			
			if(db::count("logins WHERE `ip` = ? AND ".time()."-time < 900 AND user = 0", array($_SERVER['REMOTE_ADDR'])) >= fw::config('failed_logins')) $login->error[] = 'e_failed_logins';
			
			if(!count($login->error))
			{
				if(time()-$user['cache_time'] > 86400)
				{
					db::query("UPDATE users SET levels_gained_day = 0, exp_gained_day = 0, money_gained_day = 0, cache_time = ? WHERE id = ?", array(time(), $user['id']));
				}
			
				db::query("UPDATE users SET `ip` = ? WHERE id = ?", array($_SERVER['REMOTE_ADDR'], $user['id']));
				
				db::insert("logins", array('user' => $user['id'], 'ip' => $_SERVER['REMOTE_ADDR'], 'browser' => $_SERVER['HTTP_USER_AGENT'], 'lang' => $_SERVER['HTTP_ACCEPT_LANGUAGE'], 'time' => time()));
				
				user::login($user['id']);
				go('home');
			}
		}
		
		return $login;
	}
	
	// Password recovery
	public static function password_recovery()
	{
		GLOBAL $request_pw;
		
		$request_pw = new form;
		$request_pw->create(array(
				'mail' => array('class' => 'input', 'type' => 'text', 'name' => 'mail', 'input' => 'long_text', 'max_length' => '100'),
			), 'request_pw', fw::route(0));

		if($request_pw->submitted)
		{
			fw::script_line('
				$(function(){
				
					$(".reminder").show();
					$(".login").hide();
					$(".register").hide();
					
				});
			');

			if(db::count("spam_control WHERE ip = ? AND ".time()."-time < 86400 AND type = 'password_request'", array($_SERVER['REMOTE_ADDR']))) $request_pw->error[] = 'e_request_count';

			if(empty($request_pw->error))
			{
				$user = db::query("SELECT * FROM users WHERE email = ?", array($_POST['mail']))->fetch();

				$code = '';
				
				$secret_ingredients = 'abcdefghijklmnopqrstuvxyABCDEFGHIJKLMNOPQRSTUVXY1234567890';
				$secret_ingredients = str_split($secret_ingredients);
				
				$code = uniqid();
				
				for($i = 0; $i <= 15; $i++)
				{
					$code .= $secret_ingredients[mt_rand(0, count($secret_ingredients)-1)];
				}	

				$header = "Reply-To:".fw::config('mail')." <".fw::config('mail').">\r\n"; 
				$header .= "Return-Path: ".fw::config('mail')." <".fw::config('mail').">\r\n"; 
				$header .= "From: ".fw::config('mail')." <".fw::config('mail').">\r\n"; 	  

				$link = fw::config('url').'/reminder/'.$code.'/'.$user['email'];
				$message = "Hi,\nyou have requested your password to be changed.\n\nTo change your current password, you must click on the link below:\n".$link."\n\n".fw::config('url')."\n\nYour username: ".$user['username'];
				
				mail($user['email'], 'New password', $message, $header);

				db::insert("spam_control", array('ip' => $_SERVER['REMOTE_ADDR'], 'time' => time(), 'type' => 'password_request'));
				
				db::query("UPDATE users SET password_request_time = ".time().", password_request = ? WHERE id = ?", array($code, $user['id']));
				
				$request_pw->success = 'mail_sent';
			}
		}
		
		return $request_pw;
	}
}
